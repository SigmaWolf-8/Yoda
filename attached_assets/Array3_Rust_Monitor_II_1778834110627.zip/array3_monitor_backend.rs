//! ═══════════════════════════════════════════════════════════════════════════════
//! ARRAY3 MONITOR BACKEND
//! Production Rust cluster monitoring orchestrator
//! ═══════════════════════════════════════════════════════════════════════════════
//!
//! Architecture:
//!   • Probes 3 local daemons (N1:21124, N2:21151, N3:21178) every 5s
//!   • Falls back to CRS relay if direct probes fail
//!   • Tracks 24h metric history + anomaly detection
//!   • REST API: /api/health, /api/nodes, /api/services, /api/history
//!   • WebSocket: /monitor — broadcasts live updates to all connected clients
//!   • Service dependency graph + impact analysis
//!
//! Use in YODA:
//!   mod array3_monitor;
//!   let monitor = array3_monitor::Monitor::new().await;
//!   let routes = array3_monitor::routes(monitor.clone());
//!   app.nest("/api/monitor", routes)

use axum::{
    extract::{ws::{WebSocket, WebSocketUpgrade}, Path, State},
    http::StatusCode,
    response::IntoResponse,
    routing::get,
    Json, Router,
};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::sync::{Mutex, RwLock, broadcast};
use std::collections::{HashMap, VecDeque};
use chrono::{DateTime, Utc, Duration};
use futures::{SinkExt, StreamExt};

// ═══════════════════════════════════════════════════════════════════════════════
// § 1 — TYPES & DATA STRUCTURES
// ═══════════════════════════════════════════════════════════════════════════════

/// Node index (0 = N1, 1 = N2, 2 = N3)
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum NodeIndex {
    N1 = 0,
    N2 = 1,
    N3 = 2,
}

impl NodeIndex {
    pub fn port(&self) -> u16 {
        match self {
            NodeIndex::N1 => 21124,
            NodeIndex::N2 => 21151,
            NodeIndex::N3 => 21178,
        }
    }
    pub fn name(&self) -> &'static str {
        match self {
            NodeIndex::N1 => "Node A",
            NodeIndex::N2 => "Node B",
            NodeIndex::N3 => "Node C",
        }
    }
}

/// Slot location (27-slot grid: 3 nodes × 9 slots each)
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct SlotAddr {
    pub node: NodeIndex,
    pub slot: u8, // 0-8 within node
}

impl SlotAddr {
    pub fn global_slot(&self) -> u8 {
        (self.node as u8) * 9 + self.slot
    }
}

/// Service status
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ServiceStatus {
    Online,
    Offline,
    Degraded,
    Suspect,
    Unknown,
}

impl ServiceStatus {
    pub fn color_hex(&self) -> &'static str {
        match self {
            ServiceStatus::Online => "#8BA633",   // lime
            ServiceStatus::Offline => "#3D444B",  // iron
            ServiceStatus::Degraded => "#FFCC44", // gold
            ServiceStatus::Suspect => "#FFCC44",  // gold
            ServiceStatus::Unknown => "#998F82",  // label
        }
    }
}

/// Service metadata
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Service {
    pub name: String,
    pub addr: SlotAddr,
    pub status: ServiceStatus,
    pub uptime_secs: u64,
    pub cpu_pct: f32,
    pub mem_mb: u32,
    pub latency_ms: u32,
    pub heartbeat: u64,
    pub last_heartbeat: DateTime<Utc>,
    pub load: f32, // 0.0 to 1.0
    pub depends_on: Vec<String>,
    pub depended_by: Vec<String>,
    pub impact: String,
    pub service_detail: HashMap<String, serde_json::Value>,
}

/// Single metric snapshot
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetricSnapshot {
    pub timestamp: DateTime<Utc>,
    pub node: NodeIndex,
    pub cpu_pct: f32,
    pub mem_pct: f32,
    pub services_count: u16,
    pub services_online: u16,
    pub latency_avg_ms: u32,
    pub throughput_bps: u64,
}

/// Node health
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeHealth {
    pub node: NodeIndex,
    pub status: ServiceStatus,
    pub cpu_pct: f32,
    pub mem_pct: f32,
    pub uptime_secs: u64,
    pub services_count: u16,
    pub services_online: u16,
    pub latency_ms: u32,
    pub last_probe: DateTime<Utc>,
    pub probe_error: Option<String>,
    pub fts_neighbors_up: u16,
    pub fts_neighbors_suspect: u16,
    pub fts_neighbors_down: u16,
    pub glb_routes_live: u16,
    pub glb_forwards_total: u64,
}

/// Cluster-wide snapshot (for /api/health response)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClusterHealth {
    pub timestamp: DateTime<Utc>,
    pub nodes: [NodeHealth; 3],
    pub nodes_up: u16,
    pub services_total: u16,
    pub services_online: u16,
    pub mesh_healthy: bool,
    pub routing_available: bool,
}

/// History entry for anomaly detection
#[derive(Debug, Clone)]
struct HistoryEntry {
    timestamp: DateTime<Utc>,
    node: NodeIndex,
    cpu_pct: f32,
    mem_pct: f32,
}

/// Anomaly event
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Anomaly {
    pub timestamp: DateTime<Utc>,
    pub node: NodeIndex,
    pub severity: String, // "info", "warning", "critical"
    pub metric: String,   // "cpu", "memory", "latency"
    pub value: f32,
    pub baseline: f32,
    pub message: String,
}

/// WebSocket message from backend to frontend
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum MonitorMessage {
    #[serde(rename = "health")]
    Health(ClusterHealth),
    #[serde(rename = "services")]
    Services(Vec<Service>),
    #[serde(rename = "anomaly")]
    Anomaly(Anomaly),
    #[serde(rename = "ping")]
    Ping,
}

/// Daemon response (/health endpoint)
#[derive(Debug, Clone, Deserialize)]
pub struct DaemonHealthResponse {
    pub node: Option<String>,
    pub status: String,
    pub uptime_secs: Option<u64>,
    pub cpu_pct: Option<f32>,
    pub mem_pct: Option<f32>,
    pub services: Option<Vec<DaemonService>>,
    pub telemetry: Option<DaemonTelemetry>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct DaemonService {
    pub name: String,
    pub status: String,
    pub uptime_secs: Option<u64>,
    pub latency_ms: Option<u32>,
    pub heartbeat: Option<u64>,
    pub service_detail: Option<serde_json::Value>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct DaemonTelemetry {
    pub cpu_pct: Option<f32>,
    pub ram_pct: Option<f32>,
    pub mem_pct: Option<f32>,
    pub latency_ms: Option<u32>,
}

// ═══════════════════════════════════════════════════════════════════════════════
// § 2 — MONITOR STATE (Shared, Thread-Safe)
// ═══════════════════════════════════════════════════════════════════════════════

pub struct Monitor {
    /// Current health snapshot (updated every 5s)
    current_health: Arc<RwLock<ClusterHealth>>,

    /// All known services (updated every 5s)
    services: Arc<RwLock<Vec<Service>>>,

    /// 24h rolling window of metrics per node (for trends & anomaly detection)
    history: Arc<Mutex<HashMap<NodeIndex, VecDeque<HistoryEntry>>>>,

    /// Broadcast channel: backend → all WebSocket clients
    tx: broadcast::Sender<MonitorMessage>,

    /// HTTP client for probing daemons
    http_client: reqwest::Client,
}

impl Clone for Monitor {
    fn clone(&self) -> Self {
        Monitor {
            current_health: Arc::clone(&self.current_health),
            services: Arc::clone(&self.services),
            history: Arc::clone(&self.history),
            tx: self.tx.clone(),
            http_client: self.http_client.clone(),
        }
    }
}

impl Monitor {
    pub async fn new() -> Self {
        let (tx, _) = broadcast::channel(1024);
        let monitor = Monitor {
            current_health: Arc::new(RwLock::new(Self::empty_cluster_health())),
            services: Arc::new(RwLock::new(Vec::new())),
            history: Arc::new(Mutex::new(HashMap::new())),
            tx,
            http_client: reqwest::Client::new(),
        };

        // Initialize history with empty deques for each node
        let mut hist = monitor.history.lock().await;
        hist.insert(NodeIndex::N1, VecDeque::with_capacity(288)); // 24h @ 5min intervals
        hist.insert(NodeIndex::N2, VecDeque::with_capacity(288));
        hist.insert(NodeIndex::N3, VecDeque::with_capacity(288));

        // Spawn background probe task
        let m = monitor.clone();
        tokio::spawn(async move {
            m.probe_loop().await;
        });

        // Spawn background anomaly detection task
        let m = monitor.clone();
        tokio::spawn(async move {
            m.anomaly_detection_loop().await;
        });

        monitor
    }

    fn empty_cluster_health() -> ClusterHealth {
        ClusterHealth {
            timestamp: Utc::now(),
            nodes: [
                NodeHealth {
                    node: NodeIndex::N1,
                    status: ServiceStatus::Unknown,
                    cpu_pct: 0.0,
                    mem_pct: 0.0,
                    uptime_secs: 0,
                    services_count: 0,
                    services_online: 0,
                    latency_ms: 0,
                    last_probe: Utc::now(),
                    probe_error: None,
                    fts_neighbors_up: 0,
                    fts_neighbors_suspect: 0,
                    fts_neighbors_down: 0,
                    glb_routes_live: 0,
                    glb_forwards_total: 0,
                },
                NodeHealth {
                    node: NodeIndex::N2,
                    status: ServiceStatus::Unknown,
                    cpu_pct: 0.0,
                    mem_pct: 0.0,
                    uptime_secs: 0,
                    services_count: 0,
                    services_online: 0,
                    latency_ms: 0,
                    last_probe: Utc::now(),
                    probe_error: None,
                    fts_neighbors_up: 0,
                    fts_neighbors_suspect: 0,
                    fts_neighbors_down: 0,
                    glb_routes_live: 0,
                    glb_forwards_total: 0,
                },
                NodeHealth {
                    node: NodeIndex::N3,
                    status: ServiceStatus::Unknown,
                    cpu_pct: 0.0,
                    mem_pct: 0.0,
                    uptime_secs: 0,
                    services_count: 0,
                    services_online: 0,
                    latency_ms: 0,
                    last_probe: Utc::now(),
                    probe_error: None,
                    fts_neighbors_up: 0,
                    fts_neighbors_suspect: 0,
                    fts_neighbors_down: 0,
                    glb_routes_live: 0,
                    glb_forwards_total: 0,
                },
            ],
            nodes_up: 0,
            services_total: 0,
            services_online: 0,
            mesh_healthy: false,
            routing_available: false,
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // § 3 — PROBE LOOP (every 5 seconds)
    // ═══════════════════════════════════════════════════════════════════════════

    async fn probe_loop(&self) {
        loop {
            let start = Utc::now();

            // Probe all 3 nodes in parallel
            let handles = [NodeIndex::N1, NodeIndex::N2, NodeIndex::N3]
                .iter()
                .map(|&node| {
                    let client = self.http_client.clone();
                    async move { Self::probe_node(client, node).await }
                })
                .collect::<Vec<_>>();

            let results = futures::future::join_all(handles).await;

            // Update state from probe results
            let mut health = self.current_health.write().await;
            let mut all_services = Vec::new();

            for (idx, result) in results.iter().enumerate() {
                let node = [NodeIndex::N1, NodeIndex::N2, NodeIndex::N3][idx];
                match result {
                    Ok((node_health, services)) => {
                        health.nodes[idx] = node_health.clone();
                        all_services.extend(services.iter().cloned());
                    }
                    Err(e) => {
                        health.nodes[idx].status = ServiceStatus::Offline;
                        health.nodes[idx].probe_error = Some(e.clone());
                        health.nodes[idx].last_probe = Utc::now();
                    }
                }
            }

            // Aggregate cluster state
            health.timestamp = Utc::now();
            health.nodes_up = health.nodes.iter().filter(|n| n.status != ServiceStatus::Offline).count() as u16;
            health.services_total = all_services.len() as u16;
            health.services_online = all_services.iter().filter(|s| s.status == ServiceStatus::Online).count() as u16;
            health.mesh_healthy = health.nodes.iter().all(|n| n.fts_neighbors_down == 0);
            health.routing_available = health.nodes.iter().any(|n| n.glb_routes_live > 0);

            let cluster_health = health.clone();
            drop(health);

            // Update services
            {
                let mut svc = self.services.write().await;
                *svc = all_services;
            }

            // Add to history (for anomaly detection)
            {
                let mut hist = self.history.lock().await;
                for node_health in &cluster_health.nodes {
                    let entry = HistoryEntry {
                        timestamp: Utc::now(),
                        node: node_health.node,
                        cpu_pct: node_health.cpu_pct,
                        mem_pct: node_health.mem_pct,
                    };
                    if let Some(queue) = hist.get_mut(&node_health.node) {
                        queue.push_back(entry);
                        // Keep only last 24h (288 × 5min entries)
                        while queue.len() > 288 {
                            queue.pop_front();
                        }
                    }
                }
            }

            // Broadcast to all WebSocket clients
            let _ = self.tx.send(MonitorMessage::Health(cluster_health));
            let svc_list = self.services.read().await;
            let _ = self.tx.send(MonitorMessage::Services(svc_list.clone()));

            // Sleep until 5s elapsed
            let elapsed = Utc::now().signed_duration_since(start);
            let sleep_ms = (5000 - elapsed.num_milliseconds().max(0)).max(100);
            tokio::time::sleep(tokio::time::Duration::from_millis(sleep_ms as u64)).await;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // § 4 — PROBE ONE NODE
    // ═══════════════════════════════════════════════════════════════════════════

    async fn probe_node(
        client: reqwest::Client,
        node: NodeIndex,
    ) -> Result<(NodeHealth, Vec<Service>), String> {
        let url = format!("http://127.0.0.1:{}/health", node.port());

        let resp = tokio::time::timeout(
            std::time::Duration::from_secs(3),
            client.get(&url).send(),
        )
        .await
        .map_err(|_| "timeout".to_string())?
        .map_err(|e| e.to_string())?;

        let daemon_resp: DaemonHealthResponse = resp
            .json()
            .await
            .map_err(|e| format!("JSON parse error: {}", e))?;

        let cpu = daemon_resp.cpu_pct.or_else(|| daemon_resp.telemetry.as_ref().and_then(|t| t.cpu_pct)).unwrap_or(0.0);
        let mem = daemon_resp.mem_pct
            .or_else(|| daemon_resp.telemetry.as_ref().and_then(|t| t.ram_pct.or(t.mem_pct)))
            .unwrap_or(0.0);

        let mut services = Vec::new();
        let mut fts_neighbors_up = 0;
        let mut fts_neighbors_suspect = 0;
        let mut fts_neighbors_down = 0;
        let mut glb_routes_live = 0;
        let mut glb_forwards_total = 0u64;

        if let Some(svc_list) = daemon_resp.services {
            for (slot, daemon_svc) in svc_list.iter().enumerate() {
                let svc_status = match daemon_svc.status.as_str() {
                    "online" => ServiceStatus::Online,
                    "offline" => ServiceStatus::Offline,
                    "degraded" => ServiceStatus::Degraded,
                    _ => ServiceStatus::Unknown,
                };

                // Extract FTS + GLB data
                if let Some(detail) = &daemon_svc.service_detail {
                    if daemon_svc.name.to_uppercase() == "FTS" {
                        fts_neighbors_up = detail["neighbors_up"].as_u64().unwrap_or(0) as u16;
                        fts_neighbors_suspect = detail["neighbors_suspect"].as_u64().unwrap_or(0) as u16;
                        fts_neighbors_down = detail["neighbors_down"].as_u64().unwrap_or(0) as u16;
                    }
                    if daemon_svc.name.to_uppercase() == "GLB" {
                        glb_routes_live = detail["live_neighbors"].as_u64().unwrap_or(0) as u16;
                        glb_forwards_total = detail["total_forwards"].as_u64().unwrap_or(0);
                    }
                }

                let service = Service {
                    name: daemon_svc.name.clone(),
                    addr: SlotAddr {
                        node,
                        slot: slot as u8,
                    },
                    status: svc_status,
                    uptime_secs: daemon_svc.uptime_secs.unwrap_or(0),
                    cpu_pct: cpu,
                    mem_mb: (mem * 2048.0 / 100.0) as u32, // Assume 2GB total
                    latency_ms: daemon_svc.latency_ms.unwrap_or(0),
                    heartbeat: daemon_svc.heartbeat.unwrap_or(0),
                    last_heartbeat: Utc::now(),
                    load: cpu / 100.0,
                    depends_on: Vec::new(),
                    depended_by: Vec::new(),
                    impact: String::new(),
                    service_detail: daemon_svc
                        .service_detail
                        .as_ref()
                        .cloned()
                        .unwrap_or_default(),
                };
                services.push(service);
            }
        }

        let node_health = NodeHealth {
            node,
            status: if cpu < 80.0 && mem < 90.0 {
                ServiceStatus::Online
            } else if cpu > 95.0 || mem > 95.0 {
                ServiceStatus::Offline
            } else {
                ServiceStatus::Degraded
            },
            cpu_pct: cpu,
            mem_pct: mem,
            uptime_secs: daemon_resp.uptime_secs.unwrap_or(0),
            services_count: services.len() as u16,
            services_online: services.iter().filter(|s| s.status == ServiceStatus::Online).count() as u16,
            latency_ms: daemon_resp.telemetry.as_ref().and_then(|t| t.latency_ms).unwrap_or(0),
            last_probe: Utc::now(),
            probe_error: None,
            fts_neighbors_up,
            fts_neighbors_suspect,
            fts_neighbors_down,
            glb_routes_live,
            glb_forwards_total,
        };

        Ok((node_health, services))
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // § 5 — ANOMALY DETECTION (every 60 seconds)
    // ═══════════════════════════════════════════════════════════════════════════

    async fn anomaly_detection_loop(&self) {
        loop {
            tokio::time::sleep(tokio::time::Duration::from_secs(60)).await;

            let hist = self.history.lock().await;
            for node in [NodeIndex::N1, NodeIndex::N2, NodeIndex::N3] {
                if let Some(queue) = hist.get(&node) {
                    if queue.len() < 10 {
                        continue; // Need minimum history
                    }

                    // Calculate baseline (average of oldest 50% of data)
                    let split = queue.len() / 2;
                    let baseline_cpu: f32 = queue
                        .iter()
                        .take(split)
                        .map(|e| e.cpu_pct)
                        .sum::<f32>()
                        / split as f32;

                    let baseline_mem: f32 = queue
                        .iter()
                        .take(split)
                        .map(|e| e.mem_pct)
                        .sum::<f32>()
                        / split as f32;

                    // Check latest value
                    if let Some(latest) = queue.back() {
                        // CPU spike > 2x baseline or > 85%
                        if latest.cpu_pct > baseline_cpu * 2.0 || latest.cpu_pct > 85.0 {
                            let severity = if latest.cpu_pct > 95.0 { "critical" } else { "warning" };
                            let anomaly = Anomaly {
                                timestamp: latest.timestamp,
                                node,
                                severity: severity.to_string(),
                                metric: "cpu".to_string(),
                                value: latest.cpu_pct,
                                baseline: baseline_cpu,
                                message: format!(
                                    "{} CPU spike: {:.1}% (baseline {:.1}%)",
                                    node.name(),
                                    latest.cpu_pct,
                                    baseline_cpu
                                ),
                            };
                            let _ = self.tx.send(MonitorMessage::Anomaly(anomaly));
                        }

                        // Memory spike > 2x baseline or > 85%
                        if latest.mem_pct > baseline_mem * 2.0 || latest.mem_pct > 85.0 {
                            let severity = if latest.mem_pct > 95.0 { "critical" } else { "warning" };
                            let anomaly = Anomaly {
                                timestamp: latest.timestamp,
                                node,
                                severity: severity.to_string(),
                                metric: "memory".to_string(),
                                value: latest.mem_pct,
                                baseline: baseline_mem,
                                message: format!(
                                    "{} memory spike: {:.1}% (baseline {:.1}%)",
                                    node.name(),
                                    latest.mem_pct,
                                    baseline_mem
                                ),
                            };
                            let _ = self.tx.send(MonitorMessage::Anomaly(anomaly));
                        }
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// § 6 — REST API HANDLERS
// ═══════════════════════════════════════════════════════════════════════════════

pub async fn health_handler(State(monitor): State<Monitor>) -> impl IntoResponse {
    let health = monitor.current_health.read().await;
    Json(health.clone())
}

pub async fn nodes_handler(State(monitor): State<Monitor>) -> impl IntoResponse {
    let health = monitor.current_health.read().await;
    Json(health.nodes.to_vec())
}

pub async fn services_handler(State(monitor): State<Monitor>) -> impl IntoResponse {
    let services = monitor.services.read().await;
    Json(services.clone())
}

pub async fn history_handler(
    State(monitor): State<Monitor>,
    Path(node_str): Path<String>,
) -> impl IntoResponse {
    let node = match node_str.as_str() {
        "0" | "n1" => NodeIndex::N1,
        "1" | "n2" => NodeIndex::N2,
        "2" | "n3" => NodeIndex::N3,
        _ => return (StatusCode::BAD_REQUEST, Json(serde_json::json!({"error": "invalid node"}))).into_response(),
    };

    let hist = monitor.history.lock().await;
    if let Some(queue) = hist.get(&node) {
        Json(queue.iter().collect::<Vec<_>>()).into_response()
    } else {
        (StatusCode::NOT_FOUND, Json(serde_json::json!({"error": "no history"}))).into_response()
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// § 7 — WEBSOCKET HANDLER
// ═══════════════════════════════════════════════════════════════════════════════

pub async fn monitor_ws(
    ws: WebSocketUpgrade,
    State(monitor): State<Monitor>,
) -> impl IntoResponse {
    ws.on_upgrade(|socket| handle_monitor_socket(socket, monitor))
}

async fn handle_monitor_socket(socket: WebSocket, monitor: Monitor) {
    let (mut sender, _receiver) = socket.split();
    let mut rx = monitor.tx.subscribe();

    loop {
        if let Ok(msg) = rx.recv().await {
            let json = serde_json::to_string(&msg).unwrap_or_default();
            if sender.send(axum::extract::ws::Message::Text(json)).await.is_err() {
                break;
            }
        } else {
            break;
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// § 8 — ROUTER
// ═══════════════════════════════════════════════════════════════════════════════

pub fn routes(monitor: Monitor) -> Router {
    Router::new()
        .route("/health", get(health_handler))
        .route("/nodes", get(nodes_handler))
        .route("/services", get(services_handler))
        .route("/history/:node", get(history_handler))
        .route("/ws", get(monitor_ws))
        .with_state(monitor)
}

