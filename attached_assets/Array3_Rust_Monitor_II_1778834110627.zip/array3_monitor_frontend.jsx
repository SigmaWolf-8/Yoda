/**
 * ═════════════════════════════════════════════════════════════════════════════════
 * ARRAY3 MONITOR FRONTEND
 * Lightweight React component — calls backend only, no redundant logic
 * ═════════════════════════════════════════════════════════════════════════════════
 *
 * Props: (none, self-contained)
 * 
 * Flow:
 *   1. On mount: fetch /api/monitor/health (page load)
 *   2. Open WebSocket: ws://localhost:3000/api/monitor/ws
 *   3. On message: render 3D cubes, update HUD, show anomalies
 *   4. User clicks cube: show detail panel (from current state)
 *   5. On unmount: close WebSocket
 *
 * Backend returns:
 *   • { type: "health", data: ClusterHealth }
 *   • { type: "services", data: [Service] }
 *   • { type: "anomaly", data: Anomaly }
 */

import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';

export default function Array3Monitor() {
  const canvasRef = useRef(null);
  const sceneRef = useRef(null);
  const wsRef = useRef(null);

  const [health, setHealth] = useState(null);
  const [services, setServices] = useState([]);
  const [anomalies, setAnomalies] = useState([]);
  const [selectedNode, setSelectedNode] = useState(null);
  const [panelOpen, setPanelOpen] = useState(false);

  // ═══════════════════════════════════════════════════════════════════════════════
  // INIT: Fetch initial health + open WebSocket
  // ═══════════════════════════════════════════════════════════════════════════════

  useEffect(() => {
    // Fetch initial state
    fetch('/api/monitor/health')
      .then(r => r.json())
      .then(data => setHealth(data))
      .catch(err => console.error('Health fetch failed:', err));

    // Open WebSocket for live updates
    const ws = new WebSocket(`ws://${window.location.host}/api/monitor/ws`);
    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      switch (msg.type) {
        case 'health':
          setHealth(msg.data);
          break;
        case 'services':
          setServices(msg.data);
          break;
        case 'anomaly':
          setAnomalies(prev => [...prev, msg.data].slice(-10)); // Keep last 10
          break;
        case 'ping':
          ws.send(JSON.stringify({ type: 'pong' }));
          break;
      }
    };
    ws.onerror = err => console.error('WebSocket error:', err);
    wsRef.current = ws;

    return () => {
      if (wsRef.current) wsRef.current.close();
    };
  }, []);

  // ═══════════════════════════════════════════════════════════════════════════════
  // THREE.JS SCENE
  // ═══════════════════════════════════════════════════════════════════════════════

  useEffect(() => {
    if (!canvasRef.current || !health) return;

    const width = canvasRef.current.clientWidth;
    const height = canvasRef.current.clientHeight;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f0c0a);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    camera.position.set(0, 0, 3);

    const renderer = new THREE.WebGLRenderer({ canvas: canvasRef.current, antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);

    // Lighting
    const light = new THREE.PointLight(0xffffff, 1);
    light.position.set(5, 5, 5);
    scene.add(light);
    scene.add(new THREE.AmbientLight(0xffffff, 0.4));

    // Create 3 cubes for the nodes
    const cubes = [0, 1, 2].map((i) => {
      const nodeHealth = health.nodes[i];
      const color = statusColor(nodeHealth.status);

      const geo = new THREE.BoxGeometry(0.5, 0.5, 0.5);
      const mat = new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.5,
      });
      const cube = new THREE.Mesh(geo, mat);
      cube.position.x = (i - 1) * 1.2;
      cube.userData.nodeIndex = i;
      scene.add(cube);

      return { mesh: cube, nodeHealth };
    });

    // Animation loop
    let animationId;
    const animate = () => {
      animationId = requestAnimationFrame(animate);

      cubes.forEach((cube, i) => {
        const nodeHealth = health.nodes[i];
        const color = statusColor(nodeHealth.status);

        // Update color
        cube.mesh.material.color.setHex(color);
        cube.mesh.material.emissive.setHex(color);

        // Breathing animation based on CPU load
        const breathAmp = nodeHealth.cpu_pct / 100;
        const scale = 1 + breathAmp * 0.2 * Math.sin(Date.now() / 1000);
        cube.mesh.scale.setScalar(scale);

        // Rotation if online
        if (nodeHealth.status === 'online') {
          cube.mesh.rotation.x += 0.005;
          cube.mesh.rotation.y += 0.005;
        }
      });

      renderer.render(scene, camera);
    };
    animate();

    // Handle resize
    const handleResize = () => {
      const newWidth = canvasRef.current?.clientWidth || width;
      const newHeight = canvasRef.current?.clientHeight || height;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
      renderer.dispose();
    };
  }, [health]);

  // ═══════════════════════════════════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════════════════════════════════

  const statusColor = (status) => {
    const colorMap = {
      online: 0x8ba633,   // lime
      offline: 0x3d444b,  // iron
      degraded: 0xffcc44, // gold
      suspect: 0xffcc44,
      unknown: 0x998f82,
    };
    return colorMap[status] || 0x998f82;
  };

  const formatUptime = (secs) => {
    const days = Math.floor(secs / 86400);
    const hrs = Math.floor((secs % 86400) / 3600);
    const mins = Math.floor((secs % 3600) / 60);
    if (days > 0) return `${days}d ${hrs}h`;
    if (hrs > 0) return `${hrs}h ${mins}m`;
    return `${mins}m`;
  };

  return (
    <div style={styles.root}>
      {/* TOP BAR */}
      <div style={styles.topbar}>
        <div style={styles.logo}>
          Plenum<span style={{ color: '#4A9EF5' }}>NET</span> Array3 Monitor
        </div>
        <div style={styles.pills}>
          {health && (
            <>
              <div style={styles.pill}>{health.services_total} services</div>
              <div style={styles.pill}>{health.nodes_up}/3 nodes</div>
            </>
          )}
        </div>
      </div>

      {/* CANVAS */}
      <canvas
        ref={canvasRef}
        style={{
          position: 'absolute',
          top: 48,
          left: 0,
          right: 0,
          bottom: 0,
          display: 'block',
        }}
        onClick={(e) => {
          // Cube picking logic would go here
          // For now, just toggle panel
          setPanelOpen(!panelOpen);
        }}
      />

      {/* LEFT PANEL — Node Details */}
      {panelOpen && selectedNode !== null && health && (
        <div style={styles.detailPanel}>
          <div style={styles.detailHeader}>
            {health.nodes[selectedNode].node}
          </div>
          <div style={styles.detailContent}>
            <div style={styles.detailRow}>
              <span>Status</span>
              <span style={{ color: '#4A9EF5' }}>
                {health.nodes[selectedNode].status.toUpperCase()}
              </span>
            </div>
            <div style={styles.detailRow}>
              <span>CPU</span>
              <span>{health.nodes[selectedNode].cpu_pct.toFixed(1)}%</span>
            </div>
            <div style={styles.detailRow}>
              <span>Memory</span>
              <span>{health.nodes[selectedNode].mem_pct.toFixed(1)}%</span>
            </div>
            <div style={styles.detailRow}>
              <span>Uptime</span>
              <span>{formatUptime(health.nodes[selectedNode].uptime_secs)}</span>
            </div>
            <div style={styles.detailRow}>
              <span>Services</span>
              <span>{health.nodes[selectedNode].services_online}/{health.nodes[selectedNode].services_count}</span>
            </div>
            <div style={styles.detailRow}>
              <span>Latency</span>
              <span>{health.nodes[selectedNode].latency_ms} ms</span>
            </div>
            {health.nodes[selectedNode].fts_neighbors_down > 0 && (
              <div style={{ ...styles.detailRow, color: '#E24B4A' }}>
                ⚠ {health.nodes[selectedNode].fts_neighbors_down} neighbors down
              </div>
            )}
          </div>
        </div>
      )}

      {/* RIGHT PANEL — Anomalies */}
      {anomalies.length > 0 && (
        <div style={styles.anomalyPanel}>
          <div style={styles.anomalyHeader}>⚠ Anomalies</div>
          {anomalies.map((anom, i) => (
            <div key={i} style={styles.anomalyItem}>
              <div style={{ fontSize: '11px', color: anom.severity === 'critical' ? '#E24B4A' : '#FFCC44' }}>
                {anom.severity.toUpperCase()}
              </div>
              <div style={{ fontSize: '12px' }}>{anom.message}</div>
            </div>
          ))}
        </div>
      )}

      {/* HUD — Cluster Summary (bottom-right) */}
      {health && (
        <div style={styles.hud}>
          <div style={styles.hudRow}>
            <span>Cluster</span>
            <span style={{ color: health.mesh_healthy ? '#8BA633' : '#FFCC44' }}>
              {health.mesh_healthy ? '✓' : '⚠'} {health.nodes_up}/3
            </span>
          </div>
          <div style={styles.hudRow}>
            <span>Services</span>
            <span>{health.services_online}/{health.services_total}</span>
          </div>
          <div style={styles.hudRow}>
            <span>Routes</span>
            <span>{health.routing_available ? '✓' : '✗'}</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// STYLES
// ═══════════════════════════════════════════════════════════════════════════════

const styles = {
  root: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: '#0F0C0A',
    color: '#E4DFD5',
    fontFamily: "'Inter', system-ui, sans-serif",
    overflow: 'hidden',
  },
  topbar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 48,
    background: 'rgba(15, 12, 10, 0.97)',
    borderBottom: '1px solid #272220',
    display: 'flex',
    alignItems: 'center',
    padding: '0 20px',
    zIndex: 100,
  },
  logo: {
    fontFamily: "'Orbitron', sans-serif",
    fontSize: 15,
    fontWeight: 800,
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
  },
  pills: {
    marginLeft: 'auto',
    display: 'flex',
    gap: 8,
  },
  pill: {
    fontSize: 11,
    padding: '4px 10px',
    borderRadius: 8,
    background: 'rgba(240, 237, 232, 0.04)',
    border: '1px solid #272220',
  },
  detailPanel: {
    position: 'absolute',
    left: 0,
    top: 48,
    width: 300,
    background: 'rgba(24, 20, 17, 0.98)',
    borderRight: '1px solid #272220',
    padding: 20,
    zIndex: 90,
    maxHeight: 'calc(100vh - 48px)',
    overflow: 'auto',
  },
  detailHeader: {
    fontSize: 18,
    fontWeight: 700,
    marginBottom: 16,
    color: '#F0EDE8',
  },
  detailContent: {
    fontSize: 13,
  },
  detailRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: 8,
    padding: '6px 0',
    borderBottom: '1px solid #272220',
  },
  anomalyPanel: {
    position: 'absolute',
    right: 20,
    bottom: 20,
    width: 280,
    background: 'rgba(24, 20, 17, 0.98)',
    border: '1px solid #272220',
    borderRadius: 8,
    padding: 14,
    zIndex: 90,
    maxHeight: 300,
    overflow: 'auto',
  },
  anomalyHeader: {
    fontSize: 12,
    fontWeight: 700,
    marginBottom: 10,
    color: '#FFCC44',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
  },
  anomalyItem: {
    marginBottom: 10,
    padding: 8,
    background: 'rgba(255, 204, 68, 0.1)',
    borderRadius: 4,
    borderLeft: '3px solid #FFCC44',
  },
  hud: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    background: 'rgba(24, 20, 17, 0.98)',
    border: '1px solid #272220',
    borderRadius: 8,
    padding: 12,
    zIndex: 90,
    fontSize: 12,
    fontFamily: "'JetBrains Mono', monospace",
  },
  hudRow: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: 16,
    marginBottom: 6,
  },
};
