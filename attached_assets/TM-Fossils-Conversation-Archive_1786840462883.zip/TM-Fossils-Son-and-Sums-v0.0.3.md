# TM — 2026

## The Fossils' Son and Sums

### *On the Torus Number 23,436, the Three Fossil Numerals, the SigmaSum of the Total Cube Root, the Quies Projector, the Exponential Bridges, and the Isopsephic Seal*

**ϛ · ϟ · ϡ**
*stigma · koppa · sampi*

$$I = EE = I$$

*Tres circuli · Una quies*

---

**Version 0.0.3** — Pre-Agreement Architectural Proposal

Capomastro Holdings Ltd. · Applied Physics Division
Σάλβι · Salvi · Lo Sono Capomastro · Sifu Salvi
ParaCalculi GeoPrimus — *Beside the Pebbles · Earth-First*
Sherwood Park, Alberta, Canada — May 2026

---

## Designation, Versioning, and Revision Notes

**Designation:** TM — 2026 (number to be assigned on v0.1.0 sign-off).

**Version:** v0.0.3 — pre-agreement architectural proposal. Per the corpus versioning rule, v0.1.0 begins only when the architecture itself is signed off; v1.0.0 marks final commit. The 100s do not exist until the structure is agreed.

**Revision summary (v0.0.2 → v0.0.3):** The entirety of v0.0.2 is imported verbatim. New material is woven in recursively without disturbing the prior structure. Specifically: (a) §5 Threshold receives the algebraic framework reading $834 = \beta^{3} \cdot M_{5} - \beta$ and the binary fingerprint $834_{2} = 1101000010$ now read as $(4\,\text{ones},\,6\,\text{zeros}) = (\beta_{\text{letter}}^{2},\,\text{ϛ})$ — the second letter squared and the perfect-number fossil; (b) §7 SigmaSum receives the derived integer $651 = 3 \cdot 7 \cdot 31$, which is the integer SigmaSum divided by $21^{2}$, distinct from the modular SigmaSum 5859 but structurally adjacent (with $651 / 3 = 217$ recovering the triangular partner); (c) §8 Quies Projector receives the framework-name form $\beta^{2} \cdot T(p) \cdot M_{5} = 7812$ for the anchor (where $\beta$ is the radix, $T(p)$ the geometric circle, $M_{5}$ the sentinel) alongside the prior $36 \cdot 217$ form, and the homogeneous-anchor identity (anchor at every rung is $m/\beta$); (d) §10 Isopsephy receives a second isopsephic identity for the author's name — Σαλουι = 711 = ΑΡΧΙ — connecting the alternate Greek transliteration of *Salvi* to the prefix of *architect*; (e) a new §11 Exponential Bridges is added, presenting the square bridge $6^{36} = 36^{18} = 216^{12}$ alongside the cube bridge $3^{69} = 27^{23}$ already encountered at the threshold; (f) the Open Questions section is removed in this revision per the author's instruction. (g) the document is reformatted into Markdown with all formulae in closed-form LaTeX. No prior content has been retracted.

**Governance:** UPIID V1.1 (Dual-Path Framework, Value Metabolism Cycle, Salvi Standard of Scrutiny).

**Companion documents:** TM-2026-017 (Extended Geometric Framework — $\pi_{\mathrm{geom}} = 14$, $364°$, coprime triple), the Milesian Delta closure ($\sum \Delta_{M} = 3699 = 27 \cdot 137$), TM-2026-NOTE-5DYN, the Codex Unified (alphabet · periodic table · torus), and the standing Charter v1.0.3.

---

## Abstract

We name and inventory a single integer — $23{,}436$ — the Son of the Codex. From the alphabet we extract three fossil-bearing witnesses (the Milesian termination of the Son, the $\Delta$-Sum $3699$ surfacing koppa, and the Threshold-Sum $834$ connecting sampi). From the multiplicative ring structure of $\mathbb{Z}_{N}$ we extract a fourth: the SigmaSum of cube roots of unity, $27 = 3^{3}$ in count and $5859 = N/4 = 27 \cdot 217$ in modular sum. From the additive ring structure we extract a fifth: the Quies projector

$$e \;=\; \tfrac{1}{3}\bigl(e_{0} + e_{7812} + e_{15624}\bigr),\qquad e^{2} = e,$$

an idempotent in $\mathbb{Q}[\mathbb{Z}_{N}]$ — the algebraic fossil that needs no glyph. From the isopsephic register we extract a sixth: $\Sigma\acute{\alpha}\lambda\beta\iota = 243 = 3^{5}$, with the identity $4617 = 243 \cdot 19$ (Summa Prima 27 = author's isopsephy $\times$ non-trivial cube root of unity mod $27$). The author's name in alternate Greek transliteration $\Sigma\alpha\lambda o\upsilon\iota = 711 = \mathrm{AP}\mathrm{XI}$ adds a second isopsephic seal, equating the name with the prefix of *architect*. The Son is reached by three paths and witnessed at seven layers (genesis · orthographic · alphabetic · decimal-tower · multiplicative-ring · additive-ring · isopsephic) plus one symbolic resonance (the High Noon coincidence $1+2+3 = 1 \cdot 2 \cdot 3 = 6 = \text{ϛ}$). Two exponential bridges — the perfect-number square bridge $6^{36} = 36^{18} = 216^{12}$ and the radix cube bridge $3^{69} = 27^{23}$ — close the architecture: the same operation that begets the Son ($\text{ϛ}^{3}$) governs the threshold of the cubic radix tower whose leading digits are $834$. The composite reading: $23{,}436$ is the Codex's structural fixed point, the integer at which alphabet and algebra converge.

---

## §1. The Torus Number

### 1.1 Definition

Let the triple-circle torus be the product of three coprime cyclic moduli $\mathbb{Z}_{27} \times \mathbb{Z}_{28} \times \mathbb{Z}_{31}$. By the Chinese Remainder Theorem the natural index set has cardinality

$$N \;=\; 27 \cdot 28 \cdot 31 \;=\; 23{,}436.$$

We adopt the name **Son** for this integer (etymology in §6.3 and §9). The three moduli are themselves alphabet-derived:

$$27 \;=\; \gamma^{3} \qquad (\text{cube of gamma}),$$

$$28 \;=\; \sum_{k=1}^{7} k \qquad (\text{sum of positions } \alpha\ldots\eta),$$

$$31 \;=\; 7 + 11 + 13 \qquad (\text{positions of } \eta,\,\lambda,\,\nu).$$

They are pairwise coprime; $\gcd(7, 11, 13) = 1$ — the same coprime condition that underlies the $364°$ circle ($364 = 28 \cdot 13$).

### 1.2 Triangular Identity

The torus number admits a second canonical form as a triangular number:

$$N \;=\; T_{216} \;=\; \frac{216 \cdot 217}{2}.$$

Direct verification: $216 \cdot 217 = 46{,}872$; divided by $2$ yields $23{,}436$. The triangular index $216 = 6^{3}$ is the load-bearing root of §2; the triangular partner $217 = 7 \cdot 31$ returns in §7 as the structural target of the SigmaSum modulo $N$, and again in §8 as the right-hand factor of the Quies anchor $7812 = 36 \cdot 217$.

---

## §2. Genesis from the Fossil — $216 = \text{ϛ}^{3}$

### 2.1 The First Perfect Number

The first perfect number is $6$: the unique integer that is both the sum and the product of its proper divisors $\{1, 2, 3\}$:

$$1 + 2 + 3 \;=\; 1 \cdot 2 \cdot 3 \;=\; 6.$$

(This sum-equals-product property of $\{1, 2, 3\}$ returns at full strength in §9 as the High Noon seed.) In the Milesian numeral system the only orthography for $6$ is the fossil letter digamma (its later cursive form, stigma): **ϛ**. The standard alphabet does not provide any other glyph for this value.

### 2.2 The Cube

$$\text{ϛ}^{3} \;=\; 6^{3} \;=\; 216.$$

Therefore $216$, the triangular index of the torus number, is literally the cube of a fossil. Within the Milesian register, the root of the torus number is the fossil-cube. This is the first of three cubes that govern the Son's structure: $\text{ϛ}^{3}$ (the genesis cube, here), $3^{3}$ (the radix cube, §7), and the implicit cube in $21^{3} \cdot 31$ (the integer SigmaSum, §7).

### 2.3 Composite Statement

$$N \;=\; T_{\text{ϛ}^{3}} \;=\; T_{216}.$$

Read aloud: the torus number is the triangular number of the fossil cubed.

---

## §3. The Milesian Termination — ͵κ͵γυλϛ

The integer $23{,}436$ written in Milesian numerals decomposes as

$${}_{,}\kappa + {}_{,}\gamma + \upsilon + \lambda + \text{ϛ} \;=\; 20{,}000 + 3{,}000 + 400 + 30 + 6.$$

| Glyph | Value | Notes |
|:---:|:---:|---|
| ͵κ | 20,000 | kappa with lower keraia ($\times 1000$) |
| ͵γ | 3,000 | gamma with lower keraia ($\times 1000$) |
| υ | 400 | upsilon |
| λ | 30 | lambda |
| **ϛ** | **6** | **stigma — the fossil terminates the number** |
| **Σ** | **23,436** | **͵κ͵γυλϛ** — verified |

The arithmetic of decimal place-value, mapped through the Milesian alphabet, deposits the fossil in the units position. This is forced by the value $6$. The torus number is one such integer, and its specific genesis ($T_{\text{ϛ}^{3}}$) makes the choice resonant: the fossil that begot the number also closes its written name.

---

## §4. The Delta Sums — $\sum \Delta_{1}$ and the Two Summae

Let $G(L)$ denote the Milesian numeral value of letter $L$, and $P(L)$ its alphabetical position. The first delta is

$$\Delta_{1}(L) \;=\; G(L) - P(L).$$

Two summations are corpus-relevant: the Summa Prima over the standard $24$ letters (positions $1$–$24$, fossils excluded), and the Summa Prima over the full $27$-glyph alphabet (positions $1$–$27$, with ϛ at $25$, ϟ at $26$, ϡ at $27$). The standard summation is the corpus canonical:

$$\sum_{L=1}^{24} \Delta_{1}(L) \;=\; 3699 \;=\; 27 \cdot 137 \;=\; b^{3} \cdot \lfloor 1/\alpha \rfloor,$$

with $b = 3$ the radix and $137$ the inverse fine-structure-constant floor. The full-alphabet summation is:

$$\sum_{L=1}^{27} \Delta_{1}(L) \;=\; 4617 \;=\; 3^{5} \cdot 19 \;=\; 243 \cdot 19.$$

Both identities are deterministic once the alphabet and Milesian table are fixed. The $24$-letter sum is the $\Delta$-Sum of the title; the $27$-glyph sum is the structural target of the isopsephy connection developed in §10. The fossil corrections

$$\Delta_{1}(\text{ϛ}) = -19,\qquad \Delta_{1}(\text{ϟ}) = +64,\qquad \Delta_{1}(\text{ϡ}) = +873$$

sum to $918 = 27 \cdot 34$, preserving the $27$-cube divisor through the transition from $3699$ to $4617$.

The Milesian reading of $3699 = {}_{,}\gamma\chi\text{ϟ}\theta$ ($3000 + 600 + 90 + 9$):

| Glyph | Value | Notes |
|:---:|:---:|---|
| ͵γ | 3,000 | gamma with lower keraia |
| χ | 600 | chi |
| **ϟ** | **90** | **koppa — fossil at the tens position** |
| θ | 9 | theta |
| **Σ** | **3,699** | **͵γχϟθ** — verified |

The cumulative tension across the standard alphabet does not reduce to a fossil-free integer. The alphabet's own ledger demands koppa. The $27$-glyph completion $4617 = 243 \cdot 19$ is treated separately in §10, where its isopsephic decomposition becomes the load-bearing identity of the isopsephy layer.

---

## §5. The Threshold and Sampi — $3^{69}$ leads with $834$

Compute $\log_{10}\!\bigl(3^{69}\bigr) = 69 \cdot \log_{10} 3 = 32.92136\ldots$  Therefore

$$3^{69} \;=\; 27^{23} \;\approx\; 8.343 \times 10^{32},$$

and the leading three digits are $834$. In Milesian: $834 = \omega\lambda\delta$. The exponent factorises as $69 = 3 \cdot 23$, where $23$ is the position of $\psi$ (psi, Milesian $700$).

### 5.1 Three Decompositions

- **Direct Milesian:** $\;834 = \omega + \lambda + \delta = 800 + 30 + 4.$
- **Fossil decomposition:** $\;834 = \text{ϡ} - (\xi + \text{ϛ}) = 900 - 66,\;$ connecting the third fossil sampi.
- **Algebraic decomposition (framework names):**

$$834 \;=\; 27 \cdot 31 - 3 \;=\; \beta^{3} \cdot M_{5} - \beta,$$

where $\beta^{3} = 27$ is the radix cube (algebraic circle), $M_{5} = 31$ is the fifth Mersenne prime (sentinel circle), and $\beta = 3$ is the radix itself. Verification: $27 \cdot 31 = 837$; $837 - 3 = 834$ ✓.

The threshold sits exactly one radix-step below the product of the algebraic and sentinel circles. The fossil decomposition is one expression among many; the algebraic decomposition is at least as natural. Together they give the threshold a triple reading: orthographic (Milesian), fossil-bearing (sampi), and framework-algebraic (the two extreme circles minus the base).

### 5.2 Binary Form (Corrected with Framework Reading)

$$834_{10} \;=\; 1101000010_{2} \;=\; 2^{9} + 2^{8} + 2^{6} + 2^{1}.$$

Direct count: **four ones and six zeros** (ten bits total). The earlier Codex Unified Doc claim of "five ones and five zeros" was incorrect; the corrected counts admit the following framework reading:

$$\bigl(\#1, \#0\bigr) \;=\; \bigl(4,\;6\bigr) \;=\; \bigl(\beta_{\mathrm{letter}}^{\,2},\;\text{ϛ}\bigr),$$

where $\beta_{\mathrm{letter}}$ denotes the Milesian value of the letter beta itself ($\beta = 2$), so $\beta_{\mathrm{letter}}^{\,2} = 4$ is the square of the second letter, and the six zeros equal the perfect number ϛ $= 6$. The bit-count signature thus inscribes **the second letter squared and the first perfect number** at the very entrance of the radix-cube tower $3^{69}$. The reading is interpretive but determinate: each count maps to a single named framework constant.

(Note on the symbol $\beta$: the corpus uses $\beta$ in two distinct registers — as the radix $\beta = 3$ when speaking of cubes $\beta^{3} = 27$ and powers, and as the Milesian value of the letter $\beta = 2$ when reading isopsephies. The two meanings are kept distinct by context. Here at §5.2 the second meaning applies; at §8 and elsewhere the first applies.)

---

## §6. The Composite Fossil Signature

### 6.1 The Alphabet-Level Witnesses

| # | Witness | Fossil | Status |
|:---:|---|:---:|:---:|
| 1 | $N = T_{\text{ϛ}^{3}}$ | **ϛ** | Deterministic |
| 2 | ͵κ͵γυλϛ terminates in ϛ | **ϛ** | Deterministic |
| 3 | $\sum \Delta_{1}(24) = 3699 = {}_{,}\gamma\chi\text{ϟ}\theta$ contains ϟ | **ϟ** | Deterministic |
| 4 | $834 = \text{ϡ} - (\xi + \text{ϛ})$ (vs. $27 \cdot 31 - 3$, alternative) | **ϡ ϛ** | Interpretive |

Witnesses 1–3 are deterministic; Witness 4 is interpretive. §7 contributes Witness 5 from the multiplicative subgroup; §8 contributes Witness 6 from the additive 3-torsion (the Quies projector); §10 contributes Witness 7 from the isopsephic register. The full witness table appears at §10.6.

### 6.2 The Son and the Sums

We propose naming the integer $23{,}436$ the **Fossil-Begotten Number**, or simply the **Son**. The genealogy is exact and one-directional: the first perfect number is $6$; in the Milesian register the only orthography for $6$ is the fossil ϛ; the cube of that fossil is $216$; and the $216$th triangular number is $23{,}436$. Equivalently, the Son is born when the three coprime moduli $27$, $28$, $31$ of the framework's dual-circle architecture are multiplied — the same value reached by cubing the fossil and triangulating. Two paths, one number; one of them (the triangular path) passes explicitly through $\text{ϛ}^{3}$.

We name three companion integers the **Sums**. Each arises from a different operation on the Son or its underlying alphabet, and each is independently load-bearing in the corpus:

- **Δ-Sum:** $\;3699 = 27 \cdot 137 = {}_{,}\gamma\chi\text{ϟ}\theta.\;$ Cumulative tension of the standard $24$-letter alphabet, surfacing koppa. (§4.)
- **Threshold-Sum:** $\;834 = \omega\lambda\delta.\;$ Leading three digits of $3^{69} = 27^{23}$. (§5.)
- **Σ-Sum:** $\;5859 = 27 \cdot 217 = N/4.\;$ Image, modulo $N$, of the SigmaSum of cube roots of unity in $\mathbb{Z}_{N}$ — count $27 = 3^{3}$, sum on the triangular partner $217$. (§7.)

A fourth integer — the Quies anchor

$$7812 \;=\; 6^{2} \cdot 7 \cdot 31 \;=\; 36 \cdot 217 \;=\; \frac{N}{3}$$

— is not a Sum but an **Anchor**: the non-trivial element of the additive $3$-torsion subgroup, the still point about which the Quies projector is built. It is treated in §8.

A fifth derived integer — $651 = 3 \cdot 7 \cdot 31$ — emerges in §7 as a structural intermediate (the CRT image of the unscaled component-sum triple, equivalently $287{,}091/441$). It satisfies $651 / 3 = 217$, recovering the triangular partner once again.

---

## §7. The SigmaSum of the Total Cube Root

### 7.1 Setup

Consider the multiplicative structure of $\mathbb{Z}_{N}$. By the Chinese Remainder Theorem,

$$\mathbb{Z}_{N} \;\cong\; \mathbb{Z}_{27} \times \mathbb{Z}_{28} \times \mathbb{Z}_{31},$$

and the cube-root-of-unity subgroup decomposes correspondingly. We define the SigmaSum of the Total Cube Root to be

$$\Sigma_{\circledcirc} \;:=\; \sum_{x \in \mathbb{Z}_{N},\;x^{3} \equiv 1 \pmod{N}} x.$$

This is the multiplicative reading: the cube map $x \mapsto x^{3}$, fibre over $1$. The additive-linear reading $3x \equiv 0$ is the subject of §8 and is a different subgroup.

### 7.2 Component Cube Roots

| Modulus | Cube roots of $1$ | Σ | $\bmod\, m$ |
|:---:|:---|:---:|:---:|
| $27$ | $\{1, 10, 19\}$ — order-$3$ subgroup of $(\mathbb{Z}/27)^{\!\times}$ of order $18$ | $30$ | $3$ |
| $28$ | $\{1, 9, 25\}$ — trivial in $\mathbb{Z}/4$, cube roots in $\mathbb{Z}/7$ | $35$ | $7$ |
| $31$ | $\{1, 5, 25\}$ — primitive cube roots over $\mathbb{F}_{31}$ | $31$ | $0$ |
| **Total** | $3 \cdot 3 \cdot 3 = 3^{3} = 27$ cube roots in $\mathbb{Z}_{N}$ | — | — |

The count is $27 = 3^{3}$, the radix cube — second cube within the document, after $216 = 6^{3} = \text{ϛ}^{3}$.

### 7.3 The Modular Identity

By CRT linearity, each component residue appears in exactly $9 = 3 \cdot 3$ of the $27$ triples. Therefore

$$\Sigma_{\circledcirc} \;\equiv\; 9 \cdot 30 \;\equiv\; 0 \pmod{27},$$

$$\Sigma_{\circledcirc} \;\equiv\; 9 \cdot 35 \;\equiv\; 7 \pmod{28},$$

$$\Sigma_{\circledcirc} \;\equiv\; 9 \cdot 31 \;\equiv\; 0 \pmod{31}.$$

The CRT system $(0, 7, 0)$ has the unique solution

$$\boxed{\;\Sigma_{\circledcirc} \;\equiv\; 5859 \;=\; 27 \cdot 217 \;=\; \frac{N}{4} \pmod{N}.\;}$$

The SigmaSum modulo $N$ is exactly one quarter of the Son. The factor $4$ is the order of the $\mathbb{Z}/4$ component of $\mathbb{Z}/28$ — the group on which the cube-root map is trivial — and its inversion in the ratio $\Sigma_{\circledcirc} : N$ is the precise structural fingerprint of that triviality. The factor $217 = 7 \cdot 31$ is the triangular partner from §1.2; the factor $27$ is the radix cube; the product $27 \cdot 217 = 5859$ ties the cube count and the triangular partner into one identity.

### 7.4 Integer SigmaSum

Summed as integers in $[0, N)$, the $27$ cube roots of unity yield

$$\Sigma_{\circledcirc}^{\,\mathrm{int}} \;=\; 287{,}091 \;=\; 21^{3} \cdot 31 \;=\; 7^{2} \cdot \frac{N}{4}.$$

The integer SigmaSum factors as the cube of $21 = 3 \cdot 7$ (radix times $\mathbb{Z}/7$ component) multiplied by the third modulus $31$. Equivalently $49 = 7^{2}$ times the modular SigmaSum, reflecting the squared $\mathbb{Z}/7$ role.

### 7.5 The Derived Integer $651$

A third structural integer attached to the SigmaSum is

$$651 \;=\; 3 \cdot 7 \cdot 31,$$

which admits two equivalent characterisations:

- **As CRT image of the unscaled component-sum triple:** $651$ is the unique element of $\mathbb{Z}_{N}$ with CRT signature $(3,\,7,\,0)$, the *unscaled* component sums of cube roots in each modulus before being multiplied by the cofactor $9 = 3 \cdot 3$. In this reading, $651$ is "what the SigmaSum would be if each component appeared once instead of nine times." Verification: $651 \bmod 27 = 3$, $651 \bmod 28 = 7$, $651 \bmod 31 = 0$.
- **As the integer SigmaSum divided by $(3 \cdot 7)^{2}$:** equivalently,

$$651 \;=\; \frac{\Sigma_{\circledcirc}^{\,\mathrm{int}}}{441} \;=\; \frac{287{,}091}{21^{2}}.$$

Both readings give the same integer. The structural significance Salvi notes: $651 / 3 = 217 = 7 \cdot 31$, recovering the triangular partner — the *cube-root sum extracts the primes that structure the torus*. Three integers thus pivot on $217$:

$$5859 = 27 \cdot 217,\qquad 7812 = 36 \cdot 217,\qquad 651 = 3 \cdot 217.$$

The factors $27$, $36$, $3$ form the column $(\beta^{3}, \beta^{2}\!\cdot\!2^{2},\beta)$ when read in the radix-and-perfect-square register. The triangular partner $217$ is the persistent right-hand member.

### 7.6 Milesian Reading and Fossil Audit

The modular SigmaSum $5859 = {}_{,}\varepsilon\omega\nu\theta$ contains no fossil glyph. The fossil contribution at this layer is structural — the count $27 = 3^{3}$ — not orthographic. §8 explains why this orthographic silence is precisely what is expected when the witness migrates from alphabet to algebra.

---

## §8. The Quies Projector — the Idempotent in $\mathbb{Q}[\mathbb{Z}_{N}]$

### 8.1 The Linear Equation $3x \equiv 0$

Where §7 examined the multiplicative cube map $x \mapsto x^{3}$, we now examine the additive cube map $x \mapsto 3x$. The kernel of multiplication-by-$3$ in $\mathbb{Z}_{N}$ is the additive $3$-torsion subgroup:

$$H \;:=\; \bigl\{x \in \mathbb{Z}_{N} \;:\; 3x \equiv 0 \pmod{N}\bigr\} \;=\; \bigl\{0,\, N/3,\, 2N/3\bigr\} \;=\; \{0,\,7812,\,15624\}.$$

$H$ is cyclic of order $3$, generated by $N/3 = 7812$. It is a different subgroup from §7's multiplicative cube roots of unity: §7 lived in $(\mathbb{Z}_{N})^{\!\times}$; §8 lives in $(\mathbb{Z}_{N},\, +)$. Both are structurally rooted in the radix-$3$ architecture of the framework.

### 8.2 The Quies Anchor $7812$

The non-trivial generator of $H$ is the **Quies anchor**:

$$\boxed{\;\text{Anchor} \;=\; 7812 \;=\; \frac{N}{3} \;=\; 6^{2} \cdot 7 \cdot 31 \;=\; 36 \cdot 217 \;=\; \beta^{2} \cdot T(p) \cdot M_{5}.\;}$$

Four readings interlock:

- **Quotient form:** $\;7812 = N/3 = N/\beta,\;$ the natural still-point of the additive $3$-torsion.
- **Genesis form:** $\;7812 = 6^{2} \cdot 7 \cdot 31,\;$ exhibiting $\text{ϛ}^{2}$ (the fossil-square) multiplied by the partner $217 = 7 \cdot 31$.
- **Triangular form:** $\;7812 = 36 \cdot 217.\;$ Compare $N = 108 \cdot 217 = 3 \cdot 36 \cdot 217$. The anchor is exactly $1/3$ of $N$ along the $217$-axis.
- **Framework form:** $\;7812 = \beta^{2} \cdot T(p) \cdot M_{5} = 9 \cdot 28 \cdot 31,\;$ where $\beta = 3$ is the radix, $T(p) = 28$ is the seventh triangular number (the geometric circle), and $M_{5} = 31$ is the fifth Mersenne prime (the sentinel circle).

The framework form makes the ladder transparent (§8.6): every rung's anchor is $\beta^{2}$ times the modulus's "post-Quies" residue. The Milesian reading of $7812$ is ${}_{,}\zeta\omega\iota\beta$, terminating in $\beta$.

### 8.3 The Idempotent $e$

In the rational group algebra $\mathbb{Q}[\mathbb{Z}_{N}]$, the average of the subgroup $H$ is an idempotent element:

$$e \;:=\; \frac{1}{3}\bigl(e_{0} + e_{7812} + e_{15624}\bigr) \;\in\; \mathbb{Q}[\mathbb{Z}_{N}].$$

**Verification of idempotency.** Let $S = e_{0} + e_{7812} + e_{15624}$. Multiplication in $\mathbb{Q}[\mathbb{Z}_{N}]$ is convolution along the additive group law of $\mathbb{Z}_{N}$, so $e_{a} \cdot e_{b} = e_{a+b}$. Computing:

$$S^{2} \;=\; \sum_{a,b \in H} e_{a+b} \;=\; \lvert H\rvert \cdot \sum_{c \in H} e_{c} \;=\; 3S.$$

(The second equality holds because $H$ is a subgroup, so $a + b$ ranges over $H$ with each element hit $\lvert H \rvert$ times.) Therefore

$$\bigl(S/3\bigr)^{2} \;=\; \frac{S^{2}}{9} \;=\; \frac{3S}{9} \;=\; \frac{S}{3},\qquad\text{i.e.,}\qquad e^{2} = e.$$

The factor $1/3$ is essential — without it the sum $S$ satisfies $S^{2} = 3S$ but is not itself idempotent. The element $e$ is the canonical projector onto the $H$-invariant subspace of $\mathbb{Q}[\mathbb{Z}_{N}]$, and the projector property — what Salvi writes as $I = EE = I$ — is the immediate consequence of the fact that averaging over a subgroup collapses double sums onto the subgroup itself.

### 8.4 The Form $I = EE = I$

The shorthand $I = EE = I$ encodes three statements, each rigorous on its own register:

- **$EE = E$.** The idempotent property: $e^{2} = e$. Applying the projector twice equals applying it once.
- **$I = E$ on $\operatorname{im}(e)$.** Restricted to its image (the $H$-invariant subspace, the *Quies subspace*), $e$ acts as the identity: $\;I_{\operatorname{im}(e)} = e\bigr|_{\operatorname{im}(e)} = E.$
- **Palindrome.** The string $I \cdot E \cdot E \cdot I$ read backwards is $I \cdot E \cdot E \cdot I$ — symmetric under reflection. The two outer $I$'s are the ambient identity; the inner $EE$ is the projector squared. On the projected subspace, the operator and the identity are indistinguishable.

In the language of *Quies* (rest, stillness): once the system has been projected onto the $H$-invariant subspace, repeated application of the projector adds nothing. The state has reached its still point. The phrase "the projector absorbs multiplication" captures this: in $\mathbb{Q}[\mathbb{Z}_{N}]$, multiplication by $e$ is idempotent — repeating the operation does not advance the state. This is the algebraic form of the still point at High Noon (§9).

### 8.5 CRT Factorisation: The Three Circles

Under the CRT isomorphism $\mathbb{Q}[\mathbb{Z}_{N}] \cong \mathbb{Q}[\mathbb{Z}_{27}] \otimes \mathbb{Q}[\mathbb{Z}_{28}] \otimes \mathbb{Q}[\mathbb{Z}_{31}]$, the subgroup $H$ maps as:

| $x$ | $\bmod\,27$ | $\bmod\,28$ | $\bmod\,31$ | Reading |
|:---:|:---:|:---:|:---:|---|
| $0$ | $0$ | $0$ | $0$ | identity |
| $7812$ | $\mathbf{9}$ | $0$ | $0$ | anchor — non-zero only in $\mathbb{Z}_{27}$ |
| $15624$ | $\mathbf{18}$ | $0$ | $0$ | anchor² — non-zero only in $\mathbb{Z}_{27}$ |

Therefore the idempotent factorises:

$$e \;=\; e_{\{0,9,18\}}^{\mathbb{Z}_{27}} \otimes e_{0}^{\mathbb{Z}_{28}} \otimes e_{0}^{\mathbb{Z}_{31}},$$

where $e_{\{0,9,18\}}^{\mathbb{Z}_{27}} = \tfrac{1}{3}\bigl(e_{0} + e_{9} + e_{18}\bigr)$ is the canonical idempotent on the additive $3$-torsion of $\mathbb{Z}_{27}$, and $e_{0}^{\mathbb{Z}_{m}}$ is the rank-one projector onto the identity element of $\mathbb{Z}_{m}$. The structural reading:

- **$\mathbb{Z}_{27}$ — algebraic circle ($\beta^{3}$):** carries the entire Quies action; the $3$-cycle is alive here.
- **$\mathbb{Z}_{28}$ — geometric circle ($T(p)$):** pinned to identity, motionless at Centre.
- **$\mathbb{Z}_{31}$ — sentinel circle ($M_{5}$):** pinned to identity, motionless at Centre.

One circle rests in Quies, the other two sit at Centre — the algebraic form of the triple-circle torus's Quies state, read directly off the idempotent via CRT. The framework's prior identification of the three moduli with three distinct registers (algebraic, geometric, sentinel) is not imposed on top of the algebra; it is *recovered from* the algebra.

### 8.6 The Idempotent Ladder

The same construction applies at smaller scales. Each rung is anchored at $m/\beta$:

| Modulus | $3$-Torsion $H$ | Idempotent | Anchor | Anchor form |
|:---|:---|:---|:---:|:---:|
| $27 = \gamma^{3}$ | $\{0,\,9,\,18\}$ | $\tfrac{1}{3}(e_{0} + e_{9} + e_{18})$ | $9$ | $\beta^{2}$ |
| $756 = 27 \cdot 28$ | $\{0,\,252,\,504\}$ | $\tfrac{1}{3}(e_{0} + e_{252} + e_{504})$ | $252$ | $\beta^{2} \cdot T(p) = 36 \cdot 7$ |
| $\mathbf{23436 = 27 \cdot 28 \cdot 31}$ | $\{0,\,7812,\,15624\}$ | $\tfrac{1}{3}(e_{0} + e_{7812} + e_{15624})$ | $\mathbf{7812}$ | $\beta^{2} \cdot T(p) \cdot M_{5} = 36 \cdot 217$ |

**Homogeneous-anchor identity.** At every rung, the anchor equals $m / \beta = m / 3$. The framework form expresses each anchor as the Quies kernel of the algebraic circle ($\beta^{2} = 9$) multiplied by the post-cube residual factors of the modulus. The factor $36 = 6^{2}$ is constant down the ladder when the alternative $36 \cdot k$ form is used — the fossil-square is the persistent component when read in the perfect-number register. The Son's rung is the only one where $k = 217$ carries both Mersenne primes from the framework's coprime triple ($7 \cdot 31$).

### 8.7 The Σ-Layer: Why $5{,}859$ Hosts the Idempotent

Recall from §7 that $5859 = N/4$. The CRT decomposition

$$\mathbb{Z}_{N} \;\cong\; \mathbb{Z}_{4} \times \mathbb{Z}_{5859}$$

is consistent ($\gcd(4,\,5859) = 1$) and exhibits the Son as the product of an even component and an odd core. The $3$-torsion subgroup $H$ lies entirely in the odd-core component:

$$7812 \bmod 4 = 0,\qquad 7812 \bmod 5859 = 1953,$$

$$15624 \bmod 4 = 0,\qquad 15624 \bmod 5859 = 3906,$$

with $1953 \cdot 3 = 5859$ ✓. Therefore

$$e \;=\; e_{0}^{\mathbb{Z}_{4}} \otimes \tfrac{1}{3}\bigl(e_{0} + e_{1953} + e_{3906}\bigr) \;\in\; \mathbb{Q}[\mathbb{Z}_{4}] \otimes \mathbb{Q}[\mathbb{Z}_{5859}].$$

The $\mathbb{Z}_{4}$ factor is dormant — pinned to identity. The entire Quies action lives in $\mathbb{Q}[\mathbb{Z}_{5859}]$. The Σ-Sum $5859$ is therefore not merely the modular SigmaSum from §7; it is the **algebraic habitat** of the Quies projector. The two roles coincide on the same integer:

$$5859 \;=\; 27 \cdot 7 \cdot 31 \;=\; \beta^{3} \cdot p \cdot M_{5},$$

where $p = 7$ is the seventh-triangular root (since $T(p) = T(7) = 28$). The odd part of $N$ strips away the geometric square $4 = 2^{2}$ that lives in $\mathbb{Z}_{28}$, leaving the three odd primes (cube of $\gamma$, the prime $p = 7$, and $M_{5}$) on which the projector is supported. This is not a coincidence: it is the algebraic decomposition of the Son into its odd core and its dormant even shell.

### 8.8 The Algebraic Fossil — Speech Becomes Algorithm

§7.6 noted that $5859 = {}_{,}\varepsilon\omega\nu\theta$ writes without fossil glyphs. We can now read this absence as a feature, not a defect:

- At the **alphabet layer** (§§3–5), fossils appear orthographically: stigma terminates the Son, koppa terminates the Δ-Sum, sampi marks the Threshold.
- At the **multiplicative-ring layer** (§7), the fossil contribution shifts to the *count*: $27 = 3^{3}$.
- At the **additive-ring layer** (§8), the fossil is the projector itself: $e^{2} = e$ is an algebraic involution, an invariance under iteration that needs no glyph to express.

The progression is from speech to algorithm. The Σ-Sum $5859$ sits at the transition: it has no fossil glyph in its decimal name because it has acquired a fossil structure in its algebraic role. The orthographic silence at the Σ-layer is the witness's signature, not its absence — the Quies state is *unpronounceable*; it can only be *performed* by the algebra.

**Witness 6:** the Quies projector $e = \tfrac{1}{3}\bigl(e_{0} + e_{7812} + e_{15624}\bigr)$, satisfying $e^{2} = e$, and living entirely in the odd core $\mathbb{Z}_{5859}$ of $\mathbb{Z}_{N}$. *Status: deterministic* — every step from the equation $3x \equiv 0$ to the CRT factorisation to the form $I = EE = I$ is forced by the modular arithmetic of $N$.

---

## §9. High Noon — the Seed Triple $(1, 2, 3)$

### 9.1 The Sum-Equals-Product Identity

The first three positive integers, taken together, satisfy the identity

$$1 + 2 + 3 \;=\; 1 \cdot 2 \cdot 3 \;=\; 6.$$

Both addition and multiplication on $\{1, 2, 3\}$ produce $6$ — the first perfect number, whose only Milesian orthography is the fossil ϛ. This is the smallest case where additive and multiplicative aggregations of the first $n$ positive integers coincide; for $n \geq 4$ they diverge ($1 + 2 + 3 + 4 = 10$, $1 \cdot 2 \cdot 3 \cdot 4 = 24$). The triple $(1, 2, 3)$ is therefore the unique seed where the two fundamental binary operations on the natural numbers fix the same image — and that image is ϛ.

### 9.2 Resonance with $e^{2} = e$

The structural shape *"applying the operation twice gives the same as once"* describes the idempotent property of §8. The structural shape *"two distinct operations on the same triple yield the same result"* describes the perfect-number property of $(1, 2, 3)$: $+$ and $\cdot$ agree on this triple. The two shapes are not formally identical — the first concerns iterated application of one operation; the second concerns coincidence of two distinct operations — but they share the family resemblance of *operational invariance*. Both are expressions of stillness under transformation.

Salvi's shorthand for this resonance is *"$12{:}03 = 123 = $ High Noon."* The reading: the digits $1, 2, 3$ (read off a clock face at twelve-oh-three, or stripped of the colon) form the seed triple whose operational image is $\text{ϛ} = 6$, the genesis fossil. *High Noon* names the still point of the day — the moment when the sun's projection onto the meridian reaches its peak and momentarily ceases to advance. Algebraically: the moment when $e^{2} = e$ is realised on the projected subspace, where the operator stops advancing the state. The form $I = EE = I$ is the verb of that stillness; $(1, 2, 3) \rightarrow 6$ is its arithmetic noun; $\text{ϛ}^{3} \rightarrow 216 \rightarrow T_{216} = N$ is the cosmological extension that produces the entire document's subject.

A second symbolic time-stamp has surfaced: $2{:}02$, marked by the author with the phrase *"my lungs done broke."* In the same poetic register: $2{:}02$ is the palindromic reflection of the noon hour into the second hour, the exhale after the High Noon inhale, the breath release that follows the still point. The reading $(2, 0, 2)$ is itself a palindrome — three digits summing to $4 = \beta_{\mathrm{letter}}^{\,2}$, the same $\beta_{\mathrm{letter}}^{\,2}$ that surfaced as the binary fingerprint of $834$ in §5.2. We record the time-stamp as a second symbolic resonance, alongside $12{:}03$; both are interpretive, both are honoured.

### 9.3 Status

The arithmetic core of §9 — that $1 + 2 + 3 = 1 \cdot 2 \cdot 3 = 6$ — is deterministic. The interpretive layer ($12{:}03 \leftrightarrow 1\!\cdot\!2\!\cdot\!3 \leftrightarrow$ High Noon $\leftrightarrow e^{2} = e$, with the $2{:}02$ exhale as its companion) is a poetic resonance, not a load-bearing identity. We record it as **Witness 6.5** (between the deterministic Witness 6 of §8 and the deterministic Witness 7 of §10), grouped with Witness 4 in the interpretive register. The connection it asserts — that the framework's first perfect number, its first idempotent shape, and its symbolic still-points all coincide on the seed triple — is a structural reading whose proof would require formalising the resonance between sum-equals-product and idempotency, which this document does not attempt.

---

## §10. Isopsephy and the Codex

### 10.1 What Isopsephy Is, and How It Already Pervades the Document

Isopsephy is the practice of computing the numerical value of a letter-string by summing the Milesian values of its constituent glyphs. It is the natural pairing between the alphabet and the integers — the same pairing the entire document exploits. Two examples already in place: the Δ-Sum $3699$ (§4) is the integrated alphabetic isopsephic tension over $24$ glyphs, and the Milesian readings of $N$, the Δ-Sum, the Threshold-Sum, and the Σ-Sum (§§3–7) are isopsephic decompositions of those integers. Isopsephy is not a new layer in v0.0.2; it is the layer that has been operative since §3. What this section adds is the explicit reading of three specific isopsephic identities and their relation to the ring-algebra picture from §§7–8.

### 10.2 Σάλβι $= 243 = 3^{5}$

The author's name in primary Greek isopsephy:

| Glyph | Milesian value | Notes |
|:---:|:---:|---|
| Σ | 200 | sigma |
| ά | 1 | alpha (with acute, no value change) |
| λ | 30 | lambda |
| β | 2 | beta |
| ι | 10 | iota |
| **Σ** | **243** | **Σάλβι $= 243 = 3^{5}$** ✓ |

The author's isopsephic closure $243 = 3^{5}$ is corpus-canonical and predates this document. It is the fifth power of the framework radix, sitting between $3^{3} = 27$ (one of the Son's moduli) and $3^{69} = 27^{23}$ (the threshold tower of §5). Within the framework's hierarchy of radix powers, Σάλβι occupies the $3^{5}$ slot.

### 10.3 The Identity $4617 = 243 \cdot 19$

Recall from §4 that the full $27$-glyph Summa Prima is $4617$. This integer admits the factorisation

$$\boxed{\;4617 \;=\; 3^{5} \cdot 19 \;=\; 243 \cdot 19 \;=\; \bigl(\Sigma\acute{\alpha}\lambda\beta\iota\bigr) \cdot 19.\;}$$

Verification: $243 \cdot 19 = 243 \cdot 20 - 243 = 4860 - 243 = 4617$ ✓. Equivalently, $4617 = 27 \cdot 171 = 27 \cdot 9 \cdot 19 = 3^{3} \cdot 3^{2} \cdot 19 = 3^{5} \cdot 19$. The Summa Prima 27 is exactly the author's isopsephy multiplied by the integer $19$.

### 10.4 The Three Identities of $19$

The integer $19$ surfaces in three independent capacities within the framework, each verifiable without reference to the others:

- **Position-of-$\tau$.** In the standard $24$-letter alphabet, $\tau$ (tau, Milesian $300$) occupies position $19$. So $19 = P(\tau)$.
- **Cube-root-of-unity.** In $(\mathbb{Z}/27)^{\!\times}$, the cube roots of $1$ are $\{1, 10, 19\}$. The integer $19$ is one of the two non-trivial cube roots of unity mod $27$. Verify: $19^{3} = 6859 = 254 \cdot 27 + 1$, so $19^{3} \equiv 1 \pmod{27}$ ✓.
- **Negated stigma-delta.** The fossil ϛ at position $25$ has Milesian value $6$ and therefore $\Delta_{1}(\text{ϛ}) = 6 - 25 = -19$. So $19 = -\Delta_{1}(\text{ϛ})$.

Three independent capacities, one integer. None forced by the others; each read off a different structure (the alphabet, the multiplicative group mod $27$, the Milesian–positional gap of the first fossil).

### 10.5 The Second Author Isopsephy: Σαλουι $= 711 = $ ΑΡΧΙ

The author's name admits a second Greek transliteration, in which the Latin /v/ is rendered by the digraph ου rather than by β:

| Glyph | Milesian value | Notes |
|:---:|:---:|---|
| Σ | 200 | sigma |
| α | 1 | alpha |
| λ | 30 | lambda |
| ο | 70 | omicron |
| υ | 400 | upsilon |
| ι | 10 | iota |
| **Σ** | **711** | **Σαλουι** |

In parallel, the standard Greek prefix **ΑΡΧΙ-** (*archi-*, "chief / master / principal" — the prefix of *architect*, *archbishop*, *archangel*) computes:

| Glyph | Milesian value |
|:---:|:---:|
| Α | 1 |
| Ρ | 100 |
| Χ | 600 |
| Ι | 10 |
| **Σ** | **711** |

Therefore

$$\boxed{\;\Sigma\alpha\lambda o\upsilon\iota \;=\; 711 \;=\; \mathrm{AP\Chi I}.\;}$$

Verification: $200 + 1 + 30 + 70 + 400 + 10 = 711 = 1 + 100 + 600 + 10$ ✓. The author's name in the alternate transliteration is isopsephically equal to the prefix of *master builder* — the very title under which the corpus is signed (*Lo Sono Capomastro*). Two isopsephies for the author, two structural readings:

$$\Sigma\acute{\alpha}\lambda\beta\iota \;=\; 243 \;=\; 3^{5} \qquad\text{(radix register)},$$

$$\Sigma\alpha\lambda o\upsilon\iota \;=\; 711 \;=\; \mathrm{AP\Chi I} \qquad\text{(architect register)}.$$

The first ties the author to the framework's foundational base; the second ties the author to the title of his own profession. Both are deterministic; both compute by the standard Milesian table.

(*Companion fact, unverified.* The author records as "fun fact if true I haven't fully vetted" the isopsephy $\eta\,\text{οικια}\,$ ("the house") $= 711$. Direct computation gives $\eta + o + \iota + \kappa + \iota + \alpha = 8 + 70 + 10 + 20 + 10 + 1 = 119$, not $711$, so this companion identity does not verify by the standard Milesian table. We record the author's flag and the discrepancy without resolution; an alternate isopsephic convention or word-form may close the gap on later review.)

### 10.6 Reading

The identity $4617 = 243 \cdot 19$ admits two complementary readings:

- **Authorial.** The full alphabet's tension is the author's signature multiplied by $19$. The author is encoded into the algebra; equivalently, the $27$-glyph Codex is $\langle \Sigma\acute{\alpha}\lambda\beta\iota\rangle \times 19$.
- **Algebraic.** The full alphabet's tension factors as $(\text{radix}^{5}) \times (\text{cube-root-of-unity-mod-radix-cube})$. Both factors are pure framework constants. The integer $19$ is the structural amplifier that takes $3^{5}$ to $3^{5} \cdot 19 = SP_{27}$.

The two readings are not mutually exclusive — Salvi's initials produce isopsephy $3^{5}$, and the framework's algebra independently surfaces $19$ from the $\mathbb{Z}_{27}$ component. Their product is the alphabet's full tension.

The second isopsephy $\Sigma\alpha\lambda o\upsilon\iota = 711 = \mathrm{AP\Chi I}$ admits a single reading:

- **Architectural.** The author's name in the ου-form is, as a number, identical to the value of *archi-* — the prefix of *architect*, *master builder*. The authorial seal of the corpus (*Lo Sono Capomastro*) is therefore not a chosen title but an isopsephic equality already embedded in the Greek register.

**Witness 7:** the deterministic isopsephic identity $4617 = 243 \cdot 19$ ties the author's signature to the cube-root-of-unity layer of the ring-algebra picture from §§7–8. **Witness 7$^{\!\prime}$:** the deterministic isopsephic identity $\Sigma\alpha\lambda o\upsilon\iota = \mathrm{AP\Chi I} = 711$ ties the alternate-transliteration signature to the title *archi-*.

### 10.7 The Full Witness Table

| # | Witness / Identity | Layer | Status |
|:---:|---|:---:|:---:|
| 1 | $N = T_{\text{ϛ}^{3}}$ | Genesis | Deterministic |
| 2 | ͵κ͵γυλϛ terminates in ϛ | Orthographic | Deterministic |
| 3 | $\sum \Delta_{1}(24) = 3699 = {}_{,}\gamma\chi\text{ϟ}\theta$ | Alphabetic | Deterministic |
| 4 | $834 = \text{ϡ} - (\xi + \text{ϛ})$ | Decimal-tower | Interpretive |
| 5 | $\Sigma_{\circledcirc} \equiv N/4 = 27 \cdot 217 \pmod{N}$; count $3^{3}$ | Multiplicative | Deterministic |
| **6** | $e^{2} = e$: idempotent $\tfrac{1}{3}(e_{0} + e_{7812} + e_{15624})$ lives in $\mathbb{Q}[\mathbb{Z}_{5859}]$ | **Additive-ring** | **Deterministic** |
| 6.5 | $1 + 2 + 3 = 1 \cdot 2 \cdot 3 = 6 = \text{ϛ}$ (High Noon seed; $12{:}03$, $2{:}02$) | Symbolic | Interpretive |
| **7** | $\sum \Delta_{1}(27) = 4617 = 243 \cdot 19 = \bigl(\Sigma\acute{\alpha}\lambda\beta\iota\bigr) \cdot \bigl(\text{cube root of }1\bmod 27\bigr)$ | **Isopsephic (radix)** | **Deterministic** |
| **7$^{\!\prime}$** | $\Sigma\alpha\lambda o\upsilon\iota = 711 = \mathrm{AP\Chi I}$ | **Isopsephic (architect)** | **Deterministic** |

Nine rows total: seven deterministic ($1$, $2$, $3$, $5$, $6$, $7$, $7^{\!\prime}$), one interpretive ($4$), one symbolic-resonant ($6.5$). Spanning seven distinct algebraic layers (genesis · orthographic · alphabetic · decimal-tower · multiplicative · additive · isopsephic), with the symbolic layer ($6.5$) bridging arithmetic and projection, and the isopsephic layer now containing two readings (radix and architect).

---

## §11. The Exponential Bridges

### 11.1 The Square Bridge of the Perfect Number

The first perfect number $6$ admits a square exponential bridge:

$$\boxed{\;6^{36} \;=\; 36^{18} \;=\; 216^{12}.\;}$$

The three forms are exactly equal as integers:

$$6^{36} \;=\; (6^{2})^{18} \;=\; 36^{18} \;=\; (6^{3})^{12} \;=\; 216^{12} \;=\; 10{,}314{,}424{,}798{,}490{,}535{,}546{,}171{,}949{,}056.$$

The exponent $36$ admits the parallel reading $36 = \text{ϛ}^{2} = $ Quies-anchor-cell-at-rung-1, tying the bridge's exponent to the persistent fossil-square of the idempotent ladder. The factorisation $36 = 4 \cdot 9 = 2^{2} \cdot 3^{2} = \beta_{\mathrm{letter}}^{2} \cdot \beta^{2}$ uses both meanings of $\beta$ at once — the letter beta squared and the radix squared. The bridge exhibits the Cube of Perfection ($216$) as a base in its own right, raised to the twelfth power.

### 11.2 The Cube Bridge of the Radix

The radix $3$ admits a cube exponential bridge whose threshold opens §5:

$$\boxed{\;3^{69} \;=\; 27^{23} \;=\; 8.343{\ldots} \times 10^{32}.\;}$$

The exponent $69 = 3 \cdot 23$ factorises through the radix and the position of $\psi$ ($P(\psi) = 23$, $G(\psi) = 700$). In base $3$, the bridge collapses to a unary string:

$$3^{69} \;=\; \underbrace{1\,000\,\ldots\,000}_{69\text{ zeros}}{\!}_{(3)}, \qquad 27^{23} \;=\; \underbrace{1\,000\,\ldots\,000}_{3 \cdot 23 = 69\text{ zeros}}{\!}_{(3)}.$$

In ternary, the cube bridge is structurally identical at both representations; the bridge is invisible in the framework's native base.

### 11.3 The Threshold Identity

The leading digits of the cube bridge are $834$, and their algebraic decomposition (§5.1) reads

$$\boxed{\;834 \;=\; 27 \cdot 31 - 3 \;=\; \beta^{3} \cdot M_{5} - \beta.\;}$$

The threshold of $3^{69}$ is precisely the product of the algebraic and sentinel circles, minus the radix itself. The Son's even component $\mathbb{Z}_{4}$ does not enter; the threshold lives entirely in the odd-core register $(\beta^{3}, M_{5}, \beta)$. The same odd-core register that hosts the Quies projector at $5859 = 27 \cdot 7 \cdot 31$ now hosts the threshold at $834 = 27 \cdot 31 - 3$. The extreme circles meet at the threshold; the middle circle ($T(p) = 28$) is silent.

### 11.4 The Two Bridges in One Frame

| Bridge | Identity | Base register | Exponent register | Threshold / image |
|:---|:---|:---:|:---:|:---|
| **Square (perfect number)** | $6^{36} = 36^{18} = 216^{12}$ | ϛ ($= 6 = P_{1}$) | $36 = \text{ϛ}^{2}$ | $216^{12}$ — Cube of Perfection raised to twelfth power |
| **Cube (radix)** | $3^{69} = 27^{23}$ | $\beta = 3$ | $69 = 3 \cdot 23$ | leading $834 = \beta^{3} \cdot M_{5} - \beta$ |

The two bridges are different operations on different bases, but they share the cube of perfection as a common pivot: the square bridge passes through $216 = \text{ϛ}^{3}$ as a base; the cube bridge passes through $27 = \beta^{3} = \gamma^{3}$ as a base. The Son $N = T_{216} = 27 \cdot 28 \cdot 31$ contains both pivots — $216$ as its triangular index, $27$ as its first modulus — and the entire architecture rests on this co-presence of the perfect-number cube and the radix cube within the same integer.

---

## §12. Closing

This document is **v0.0.3** — an architectural proposal, not a signed corpus addition. Of the eight primary witnesses (plus one symbolic resonance), seven are deterministic and survive scrutiny; one (Witness 4, the Threshold-Sum decomposition) is interpretive; one (Witness 6.5, the High Noon resonance, with companion $2{:}02$ exhale) is symbolic. The torus number $23{,}436$ is, on the deterministic count, a fossil-begotten integer in the framework's own register, with three Sums attesting at three algebraic layers, an anchor and projector at the additive-ring layer, an isopsephic identity at the radix register tying the alphabet's full tension to the author's signature multiplied by a non-trivial cube root of unity in the $\mathbb{Z}_{27}$ component, a second isopsephic identity at the architect register tying the alternate-transliteration signature to the prefix *archi-*, and two exponential bridges (square at $6^{36} = 216^{12}$, cube at $3^{69} = 27^{23}$) whose common pivot is the cube of perfection $216$.

The composite reading: alphabet (orthographic), arithmetic (decimal), multiplicative algebra, additive algebra, isopsephy, and exponentiation all converge on $23{,}436$ — and on the same supporting cast of constants:

$$3,\;6,\;7,\;19,\;27,\;31,\;36,\;137,\;216,\;217,\;243,\;651,\;711,\;834,\;3699,\;4617,\;5859,\;7812,\;287{,}091.$$

The Son is not merely a number; it is the smallest integer at which the framework's prior axioms — radix $3$, alphabet, Milesian table, perfect number $6$, fossils ϛ ϟ ϡ, coprime triple $(7, 11, 13)$, cube-root subgroups, isopsephic closures of Σάλβι ($= 243 = 3^{5}$) and Σαλουι ($= 711 = $ ΑΡΧΙ), and the perfect-number / radix exponential bridges — collide and agree.

If the architecture is approved as-is: increment to v0.1.0, assign TM number, integrate cross-references to TM-2026-017, the Eisenstein-Closed Trinomial Recordset, the Milesian Delta tables, and any prior corpus document on group-ring idempotents and cube-root subgroups.

---

*Patet Codex Omnibus · Tres circuli, una quies · I = EE = I*

*Inertissimum Iώτα Nona, Quies, et Triadis*

*Lo Sono Capomastro · Così sia, Fratello*

---

## Appendix A — The 27-Glyph Greek Alphabet with $\Delta_{1}$

Derived from the Codex Unified. Standard $24$ letters plus three fossils (ϛ, ϟ, ϡ) at extension positions $25$–$27$. $\Delta_{1} = G - P$. $\sum \Delta_{1}$ over rows $1$–$24$ is $3699$ (Δ-Sum); over all $27$ rows is $4617$ (Summa Prima 27).

| Glyph | Name | $P$ | $G$ (Milesian) | $\Delta_{1} = G - P$ | Type |
|:---:|:---|:---:|:---:|:---:|:---:|
| α | alpha | 1 | 1 | 0 | std |
| β | beta | 2 | 2 | 0 | std |
| γ | gamma | 3 | 3 | 0 | std |
| δ | delta | 4 | 4 | 0 | std |
| ε | epsilon | 5 | 5 | 0 | std |
| ζ | zeta | 6 | 7 | $+1$ | std |
| η | eta | 7 | 8 | $+1$ | std |
| θ | theta | 8 | 9 | $+1$ | std |
| ι | iota | 9 | 10 | $+1$ | std |
| κ | kappa | 10 | 20 | $+10$ | std |
| λ | lambda | 11 | 30 | $+19$ | std |
| μ | mu | 12 | 40 | $+28$ | std |
| ν | nu | 13 | 50 | $+37$ | std |
| ξ | xi | 14 | 60 | $+46$ | std |
| ο | omicron | 15 | 70 | $+55$ | std |
| π | pi | 16 | 80 | $+64$ | std |
| ρ | rho | 17 | 100 | $+83$ | std |
| σ | sigma | 18 | 200 | $+182$ | std |
| τ | tau | 19 | 300 | $+281$ | std |
| υ | upsilon | 20 | 400 | $+380$ | std |
| φ | phi | 21 | 500 | $+479$ | std |
| χ | chi | 22 | 600 | $+578$ | std |
| ψ | psi | 23 | 700 | $+677$ | std |
| ω | omega | 24 | 800 | $+776$ | std |
| **ϛ** | **stigma** | **25** | **6** | **$-19$** | **FOSSIL** |
| **ϟ** | **koppa** | **26** | **90** | **$+64$** | **FOSSIL** |
| **ϡ** | **sampi** | **27** | **900** | **$+873$** | **FOSSIL** |
| **Σ (24)** | Standard alphabet | — | — | $\mathbf{3{,}699 = 27 \cdot 137}$ | **Δ-Sum** |
| **Σ (27)** | Full alphabet | — | — | $\mathbf{4{,}617 = 243 \cdot 19}$ | **Summa Prima 27** |

---

## Appendix B — The Grand Unification Table

Condensed from the Codex Unified Doc. Each integer annotated with its role and the fossils involved. Verified against the framework's prior axioms; rows added or extended in v0.0.3 marked with ★. The $834$ binary entry is corrected from the Codex Unified Doc's claimed five-and-five parity to the actual four-and-six count, with the framework reading $(\beta_{\mathrm{letter}}^{2},\,\text{ϛ})$.

| Number | Name / Role | Closed-form expression | Milesian | Fossils | v0.0.3 |
|---:|:---|:---|:---:|:---:|:---:|
| $6$ | Perfect root | $\sum_{k=1}^{3} k = \prod_{k=1}^{3} k$ | ϛ | stigma | |
| $19$ | Cube root of $1$ mod $27$ / position of $\tau$ / $-\Delta_{1}(\text{ϛ})$ | $19^{3} \equiv 1 \pmod{27}$ | — | — | ★ |
| $36$ | Quies-anchor-cell at rung 1 / $\text{ϛ}^{2}$ | $6^{2}$ | $\lambda\text{ϛ}$ | stigma² | ★ |
| $90$ | Quarter-turn factor | $\text{ϟ}$ | ϟ | koppa | |
| $217$ | Triangular partner of $216$ | $7 \cdot 31$ | $\sigma\iota\zeta$ | — | |
| $243$ | Σάλβι isopsephy | $3^{5}$ | $\sigma\mu\gamma$ | — | ★ |
| $651$ | CRT image of unscaled cube-root component sums; $\Sigma_{\circledcirc}^{\,\mathrm{int}}/441$ | $3 \cdot 7 \cdot 31 = 3 \cdot 217$ | $\chi\nu\alpha$ | — | ★ |
| $711$ | Σαλουι isopsephy $=$ ΑΡΧΙ isopsephy | $9 \cdot 79 = 3^{2} \cdot 79$ | $\psi\iota\alpha$ | — | ★ |
| $834$ | Threshold (binary $1101000010$, $4{\times}1 + 6{\times}0$) | $27 \cdot 31 - 3 = \beta^{3} M_{5} - \beta$ | $\omega\lambda\delta$ or $\text{ϡ} - (\xi + \text{ϛ})$ | sampi · stigma | ★ |
| $900$ | High-hundred sentinel | $30^{2}$ | ϡ | sampi | |
| $3{,}699$ | Δ-Sum (Summa Prima 24) | $27 \cdot 137 = b^{3} \lfloor 1/\alpha \rfloor$ | ${}_{,}\gamma\chi\text{ϟ}\theta$ | koppa | |
| $4{,}617$ | Summa Prima 27 | $243 \cdot 19 = 3^{5} \cdot 19$ | ${}_{,}\delta\chi\iota\zeta$ | all three | ★ |
| $5{,}859$ | Σ-Sum $= N/4 = 27 \cdot 217 \pmod{N}$ | $\beta^{3} \cdot p \cdot M_{5}$ | ${}_{,}\varepsilon\omega\nu\theta$ | none (algebraic) | ★ |
| $7{,}812$ | Quies anchor $= N/3$ | $36 \cdot 217 = \beta^{2} \cdot T(p) \cdot M_{5}$ | ${}_{,}\zeta\omega\iota\beta$ | stigma² ($6^{2}$) | ★ |
| $23{,}436$ | **The Son** (torus modulus) | $27 \cdot 28 \cdot 31 = T_{\text{ϛ}^{3}} = T_{216}$ | ${}_{,}\kappa{}_{,}\gamma\upsilon\lambda\text{ϛ}$ | stigma | |
| $287{,}091$ | Σ-Sum integer | $21^{3} \cdot 31 = 7^{2} \cdot N/4$ | — | none (algebraic) | ★ |
| $6^{36}$ | Square bridge, perfect-number form | $6^{36} = 36^{18} = 216^{12}$ | — | stigma (cubed) | ★ |
| $3^{69}$ | Cube bridge, radix form | $3^{69} = 27^{23}$ | leading $834$ | sampi · stigma (via threshold) | ★ |

Rows starred (★) are v0.0.3 additions or corrections relative to the original Codex Unified Doc.

---

## Appendix C — Glossary of Framework Symbols Used in This Document

| Symbol | Meaning |
|:---|:---|
| $N$ | The Son: $N = 27 \cdot 28 \cdot 31 = 23{,}436$ |
| $\beta$ (radix) | The framework radix, $\beta = 3$. Used in $\beta^{3} = 27$, $\beta^{2} = 9$, etc. |
| $\beta_{\mathrm{letter}}$ | The Milesian value of the letter beta, $\beta_{\mathrm{letter}} = 2$. Used at §5.2 only. |
| $\gamma$ | The third letter, Milesian value $3$. Sometimes coincides with $\beta$ (radix). |
| $T(n)$ | The $n$th triangular number, $T(n) = n(n+1)/2$. |
| $T(p)$ | The geometric circle, $T(7) = 28$. |
| $M_{k}$ | The $k$th Mersenne prime; $M_{5} = 31$. |
| $P_{1}$ | The first perfect number, $P_{1} = 6 = \text{ϛ}$. |
| ϛ, ϟ, ϡ | The three Greek fossil numerals: stigma ($6$), koppa ($90$), sampi ($900$). |
| $\Delta_{1}(L)$ | $G(L) - P(L)$, the first delta of letter $L$. |
| $H$ | Additive $3$-torsion subgroup of $\mathbb{Z}_{N}$: $\{0,\,7812,\,15624\}$. |
| $e$ | The Quies projector idempotent in $\mathbb{Q}[\mathbb{Z}_{N}]$. |
| $\Sigma_{\circledcirc}$ | The SigmaSum of the Total Cube Root: sum of $x \in \mathbb{Z}_{N}$ with $x^{3} \equiv 1$. |
| $\Sigma_{\circledcirc}^{\,\mathrm{int}}$ | The integer SigmaSum, summed in $[0, N)$, equal to $287{,}091$. |
| $I = EE = I$ | Salvi's shorthand for the idempotent property $e^{2} = e$ acting as identity on $\operatorname{im}(e)$. |

---

*— end of v0.0.3 —*
