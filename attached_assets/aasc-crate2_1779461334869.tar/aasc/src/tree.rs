use std::rc::Rc;
use std::cmp::Ordering;

#[derive(Clone, PartialEq, Eq)]
pub enum Tree<K: Ord + Clone, V: Clone> {
    Nil,
    Node {
        key: K,
        value: V,
        left: Rc<Tree<K, V>>,
        right: Rc<Tree<K, V>>,
        height: usize,
    },
}

impl<K: Ord + Clone, V: Clone> Tree<K, V> {
    fn height(&self) -> usize {
        match self { Tree::Nil => 0, Tree::Node { height, .. } => *height }
    }

    fn new_node(key: K, value: V, left: Rc<Self>, right: Rc<Self>) -> Rc<Self> {
        let h = 1 + left.height().max(right.height());
        Rc::new(Tree::Node { key, value, left, right, height: h })
    }

    pub fn find<'a>(self: &'a Rc<Self>, key: &K) -> Option<&'a V> {
        match self.as_ref() {
            Tree::Nil => None,
            Tree::Node { key: k, value: v, left, right, .. } => match key.cmp(k) {
                Ordering::Less    => left.find(key),
                Ordering::Greater => right.find(key),
                Ordering::Equal   => Some(v),
            },
        }
    }

    pub fn insert(self: &Rc<Self>, key: K, value: V) -> Rc<Self> {
        match self.as_ref() {
            Tree::Nil => Tree::new_node(key, value, Rc::new(Tree::Nil), Rc::new(Tree::Nil)),
            Tree::Node { key: k, value: v, left, right, .. } => {
                match key.cmp(k) {
                    Ordering::Less => {
                        let new_left = left.insert(key, value);
                        Self::rebalance(k.clone(), v.clone(), new_left, Rc::clone(right))
                    }
                    Ordering::Greater => {
                        let new_right = right.insert(key, value);
                        Self::rebalance(k.clone(), v.clone(), Rc::clone(left), new_right)
                    }
                    Ordering::Equal => Tree::new_node(key, value, Rc::clone(left), Rc::clone(right)),
                }
            }
        }
    }

    fn rebalance(key: K, value: V, left: Rc<Self>, right: Rc<Self>) -> Rc<Self> {
        let node = Tree::new_node(key, value, left, right);
        let bf = node.balance_factor();
        if bf == 2 {
            match node.as_ref() {
                Tree::Node { left, .. } if left.balance_factor() >= 0 => {
                    Self::rotate_right(&node)
                }
                Tree::Node { key, value, left, right, .. } => {
                    let left_rot = Self::rotate_left(left);
                    let nn = Tree::new_node(key.clone(), value.clone(),
                        left_rot, Rc::clone(right));
                    Self::rotate_right(&nn)
                }
                _ => node,
            }
        } else if bf == -2 {
            match node.as_ref() {
                Tree::Node { right, .. } if right.balance_factor() <= 0 => {
                    Self::rotate_left(&node)
                }
                Tree::Node { key, value, left, right, .. } => {
                    let right_rot = Self::rotate_right(right);
                    let nn = Tree::new_node(key.clone(), value.clone(),
                        Rc::clone(left), right_rot);
                    Self::rotate_left(&nn)
                }
                _ => node,
            }
        } else {
            node
        }
    }

    fn balance_factor(&self) -> i8 {
        match self {
            Tree::Nil => 0,
            Tree::Node { left, right, .. } => left.height() as i8 - right.height() as i8,
        }
    }

    fn rotate_left(node: &Rc<Self>) -> Rc<Self> {
        if let Tree::Node { key, value, left, right, .. } = node.as_ref() {
            if let Tree::Node { key: rk, value: rv, left: rl, right: rr, .. } = right.as_ref() {
                let nl = Tree::new_node(key.clone(), value.clone(),
                    Rc::clone(left), Rc::clone(rl));
                return Tree::new_node(rk.clone(), rv.clone(), nl, Rc::clone(rr));
            }
        }
        Rc::clone(node)
    }

    fn rotate_right(node: &Rc<Self>) -> Rc<Self> {
        if let Tree::Node { key, value, left, right, .. } = node.as_ref() {
            if let Tree::Node { key: lk, value: lv, left: ll, right: lr, .. } = left.as_ref() {
                let nr = Tree::new_node(key.clone(), value.clone(),
                    Rc::clone(lr), Rc::clone(right));
                return Tree::new_node(lk.clone(), lv.clone(), Rc::clone(ll), nr);
            }
        }
        Rc::clone(node)
    }
}
