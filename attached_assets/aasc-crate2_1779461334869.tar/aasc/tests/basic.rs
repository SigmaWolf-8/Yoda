use aasc::*;

// ── Trit core ──────────────────────────────────────────────────────

#[test]
fn trit_from_char_ascii() {
    let t = TritSeq::from_char('A');  // 65 = 2*27 + 1*9 + 0*3 + 2
    assert_eq!(t.to_hash_string(), "2102");
}

#[test]
fn trit_from_char_zero() {
    let t = TritSeq::from_char('\0');
    assert_eq!(t.to_hash_string(), "0");
}

#[test]
fn trit_add_simple() {
    let one = TritSeq(Box::new([Trit::One]));
    let two = TritSeq(Box::new([Trit::Two]));
    let sum = TritSeq::add(&one, &two);
    assert_eq!(sum.to_hash_string(), "10");  // 1+2=3=10₃
}

#[test]
fn trit_add_carry() {
    let two = TritSeq(Box::new([Trit::Two]));
    let sum = TritSeq::add(&two, &two);
    assert_eq!(sum.to_hash_string(), "11");  // 2+2=4=11₃
}

#[test]
fn trit_ordering() {
    let a = TritSeq::from_char('A');
    let b = TritSeq::from_char('B');
    assert!(a < b);
}

#[test]
fn trit_base27_digits() {
    // 'A' = 65 = 2*27 + 11 → base-27 digits [2, 11]
    let t = TritSeq::from_char('A');
    let d = t.to_base27_digits();
    assert_eq!(d.len(), 2);
    assert_eq!(d[0], 2);
    assert_eq!(d[1], 11);
}

// ── Tree ───────────────────────────────────────────────────────────

#[test]
fn tree_insert_find() {
    use std::rc::Rc;
    let empty: Rc<Tree<IndexedTritSeq, IndexedTritSeq>> = Rc::new(Tree::Nil);
    let ka = IndexedTritSeq::from_char('a');
    let va = IndexedTritSeq::from_char('x');
    let tree = empty.insert(ka.clone(), va.clone());
    assert_eq!(tree.find(&ka).unwrap(), &va);
}

#[test]
fn tree_multiple_inserts() {
    use std::rc::Rc;
    let empty: Rc<Tree<IndexedTritSeq, IndexedTritSeq>> = Rc::new(Tree::Nil);
    let pairs: Vec<(char, char)> = vec![('a','x'), ('b','y'), ('c','z'), ('d','w')];
    let mut tree = empty;
    for &(k, v) in &pairs {
        tree = tree.insert(IndexedTritSeq::from_char(k), IndexedTritSeq::from_char(v));
    }
    for &(k, v) in &pairs {
        let found = tree.find(&IndexedTritSeq::from_char(k)).unwrap();
        assert_eq!(found, &IndexedTritSeq::from_char(v));
    }
}

// ── Isomorphic ─────────────────────────────────────────────────────

#[test]
fn isomorphic_true() {
    assert!(is_isomorphic_immutable("egg", "add"));
}

#[test]
fn isomorphic_false() {
    assert!(!is_isomorphic_immutable("foo", "bar"));
}

#[test]
fn isomorphic_unicode() {
    assert!(is_isomorphic_immutable("αβα", "γδγ"));
}

#[test]
fn isomorphic_empty() {
    assert!(is_isomorphic_immutable("", ""));
}

#[test]
fn isomorphic_length_mismatch() {
    assert!(!is_isomorphic_immutable("ab", "abc"));
}

// ── Layer 1: Lexicographic ─────────────────────────────────────────

#[test]
fn layer1_lexicographic() {
    let idx = IndexedTritSeq::from_char('A');
    assert_eq!(idx.lexicographic(), "2102");
}

// ── Layer 2: Geometrical ──────────────────────────────────────────

#[test]
fn layer2_geometrical_bmp() {
    let idx = IndexedTritSeq::from_char('A');  // U+0041, Plane 0, Row 0, Col 65
    let geo = idx.geometrical().unwrap();
    assert_eq!(geo.len(), 3);
    // Plane 0
    assert_eq!(geo[0].to_hash_string(), "0");
    // Row 0
    assert_eq!(geo[1].to_hash_string(), "0");
    // Col 65 = 2102₃
    assert_eq!(geo[2].to_hash_string(), "2102");
}

#[test]
fn layer2_geometrical_supplementary() {
    let idx = IndexedTritSeq::from_char('𐀀');  // U+10000, Plane 1, Row 0, Col 0
    let geo = idx.geometrical().unwrap();
    assert_eq!(geo[0].to_hash_string(), "1");  // Plane 1
    assert_eq!(geo[1].to_hash_string(), "0");  // Row 0
    assert_eq!(geo[2].to_hash_string(), "0");  // Col 0
}

// ── Layer 3: Algebraic ────────────────────────────────────────────

#[test]
fn layer3_algebraic() {
    let idx = IndexedTritSeq::from_char('B');  // 66
    assert_eq!(idx.algebraic().to_hash_string(), "2110");  // 66 in base 3
}

// ── Layer 4: Milesian ─────────────────────────────────────────────

#[test]
fn layer4_milesian() {
    let idx = IndexedTritSeq::from_char('A');  // trits "2102"
    // digits: 2,1,0,2 → values: 3,2,1,3 → sum=9 = 100₃
    assert_eq!(idx.milesian_value().to_hash_string(), "100");
}

// ── Layer 5: Historical Figures (enrichment) ──────────────────────

#[test]
fn layer5_historical_none_by_default() {
    let idx = IndexedTritSeq::from_char('A');
    assert!(idx.historical_figure().is_none());
}

#[test]
fn layer5_historical_enriched() {
    let idx = IndexedTritSeq::from_char('Σ')
        .with_historical_figure(3, 1);  // Philosopher group 3, position 1
    let (gen, pos) = idx.historical_figure().unwrap();
    assert_eq!(gen.to_hash_string(), "10");  // 3 = 10₃
    assert_eq!(pos.to_hash_string(), "1");   // 1
}

// ── Layer 6: Chemical Element (enrichment) ────────────────────────

#[test]
fn layer6_element_none_by_default() {
    let idx = IndexedTritSeq::from_char('A');
    assert!(idx.chemical_element().is_none());
}

#[test]
fn layer6_element_enriched() {
    let idx = IndexedTritSeq::from_char('O')
        .with_element(8);  // Oxygen Z=8
    assert_eq!(idx.chemical_element().unwrap().to_hash_string(), "22");  // 8 = 22₃
}

// ── Layer 7: Marker Record ────────────────────────────────────────

#[test]
fn layer7_marker_record() {
    let idx = IndexedTritSeq::from_char('A');
    assert_eq!(idx.marker_record(), "U+0041");
}

#[test]
fn layer7_marker_supplementary() {
    let idx = IndexedTritSeq::from_char('𐀀');
    assert_eq!(idx.marker_record(), "U+010000");
}

// ── Layer 8: Greek Tier ───────────────────────────────────────────

#[test]
fn layer8_greek_tier_units() {
    // '\x01' = U+0001 = 1₁₀, base-27 digit [1], register 0 (units) → Alpha = 1
    let idx = IndexedTritSeq::from_char('\u{0001}');
    assert_eq!(idx.greek_tier().to_hash_string(), "1");  // Alpha
}

#[test]
fn layer8_greek_tier_tens() {
    // 'A' = 65, base-27 digits [2, 11]. First digit = 2, register = (2-1)/9 = 0 → Alpha
    let idx = IndexedTritSeq::from_char('A');
    assert_eq!(idx.greek_tier().to_hash_string(), "1");  // Alpha (first digit 2 is in units)
}

#[test]
fn layer8_greek_tier_higher() {
    // Find a char whose first base-27 digit is in tens register (10-18)
    // 270 = 10*27, first base-27 digit = 10, register = (10-1)/9 = 1 → Beta = 2
    let idx = IndexedTritSeq::from_char(char::from_u32(270).unwrap());
    assert_eq!(idx.greek_tier().to_hash_string(), "2");  // Beta
}

// ── Layer 9: Alphabetical Oracle ──────────────────────────────────

#[test]
fn layer9_oracle() {
    let idx = IndexedTritSeq::from_char('A');  // U+0041 = Plane 0, Row 0, Col 65
    assert_eq!(idx.alphabetical_oracle(), "P0R0C65");
}

// ── Layer 10: Manifold Coordinates (enrichment) ───────────────────

#[test]
fn layer10_manifold_empty_by_default() {
    let idx = IndexedTritSeq::from_char('A');
    assert!(idx.manifold_coords().is_empty());
}

#[test]
fn layer10_manifold_forge_gem() {
    // Forge Gem 855,888: coordinate 124 on Arch-182, residue 33 mod 1001
    let idx = IndexedTritSeq::from_char('A')
        .with_manifold_u32(&[124, 33]);
    let coords = idx.manifold_coords();
    assert_eq!(coords.len(), 2);
    assert_eq!(coords[0].to_hash_string(), "11121");  // 124 in base 3
    assert_eq!(coords[1].to_hash_string(), "1020");   // 33 in base 3
}

// ── Full cascade ordering ──────────────────────────────────────────

#[test]
fn cascade_ordering_respects_lex_first() {
    let a = IndexedTritSeq::from_char('A');
    let b = IndexedTritSeq::from_char('B');
    assert!(a < b);  // lex "2102" < "2110"
}

#[test]
fn enrichment_affects_ordering() {
    // Two identical chars, but one enriched with manifold coords
    let a = IndexedTritSeq::from_char('A');
    let b = IndexedTritSeq::from_char('A')
        .with_manifold_u32(&[1]);
    // All layers 1-9 equal, layer 10: [] < [1] → a < b
    assert!(a < b);
}
