use aasc::*;

// ── Trit core ──────────────────────────────────────────────────────

#[test]
fn trit_from_char_ascii() {
    let t = TritSeq::from_char('A');
    assert_eq!(t.to_hash_string(), "2102");
}

#[test]
fn trit_from_char_zero() {
    let t = TritSeq::from_char('\0');
    assert_eq!(t.to_hash_string(), "0");
}

#[test]
fn trit_add_simple() {
    let one = TritSeq(Box::new([Trit::One]));
    let two = TritSeq(Box::new([Trit::Two]));
    assert_eq!(TritSeq::add(&one, &two).to_hash_string(), "10");
}

#[test]
fn trit_add_carry() {
    let two = TritSeq(Box::new([Trit::Two]));
    assert_eq!(TritSeq::add(&two, &two).to_hash_string(), "11");
}

#[test]
fn trit_ordering() {
    assert!(TritSeq::from_char('A') < TritSeq::from_char('B'));
}

#[test]
fn trit_base27_digits() {
    let d = TritSeq::from_char('A').to_base27_digits();
    assert_eq!(d, vec![2, 11]);
}

// ── Tree ───────────────────────────────────────────────────────────

#[test]
fn tree_insert_find() {
    use std::rc::Rc;
    let empty: Rc<Tree<IndexedTritSeq, IndexedTritSeq>> = Rc::new(Tree::Nil);
    let k = IndexedTritSeq::from_char('a');
    let v = IndexedTritSeq::from_char('x');
    let tree = empty.insert(k.clone(), v.clone());
    assert_eq!(tree.find(&k).unwrap(), &v);
}

#[test]
fn tree_multiple_inserts() {
    use std::rc::Rc;
    let pairs = vec![('a','x'), ('b','y'), ('c','z'), ('d','w')];
    let mut tree: Rc<Tree<IndexedTritSeq, IndexedTritSeq>> = Rc::new(Tree::Nil);
    for &(k, v) in &pairs {
        tree = tree.insert(IndexedTritSeq::from_char(k), IndexedTritSeq::from_char(v));
    }
    for &(k, v) in &pairs {
        assert_eq!(
            tree.find(&IndexedTritSeq::from_char(k)).unwrap(),
            &IndexedTritSeq::from_char(v)
        );
    }
}

// ── Isomorphic ─────────────────────────────────────────────────────

#[test]
fn isomorphic_true()  { assert!(is_isomorphic_immutable("egg", "add")); }
#[test]
fn isomorphic_false() { assert!(!is_isomorphic_immutable("foo", "bar")); }
#[test]
fn isomorphic_unicode() { assert!(is_isomorphic_immutable("αβα", "γδγ")); }
#[test]
fn isomorphic_empty() { assert!(is_isomorphic_immutable("", "")); }
#[test]
fn isomorphic_mismatch() { assert!(!is_isomorphic_immutable("ab", "abc")); }

// ── Layer 1: Lexicographic ─────────────────────────────────────────

#[test]
fn layer1_lex() {
    assert_eq!(IndexedTritSeq::from_char('A').lexicographic(), "2102");
}

// ── Layer 2: Geometrical ──────────────────────────────────────────

#[test]
fn layer2_geo_bmp() {
    let idx = IndexedTritSeq::from_char('A');
    let geo = idx.geometrical().unwrap();
    assert_eq!(geo[0].to_hash_string(), "0");     // Plane 0
    assert_eq!(geo[1].to_hash_string(), "0");     // Row 0
    assert_eq!(geo[2].to_hash_string(), "2102");  // Col 65
}

#[test]
fn layer2_geo_supplementary() {
    let idx = IndexedTritSeq::from_char('𐀀');
    let geo = idx.geometrical().unwrap(); // U+10000
    assert_eq!(geo[0].to_hash_string(), "1");  // Plane 1
    assert_eq!(geo[1].to_hash_string(), "0");  // Row 0
    assert_eq!(geo[2].to_hash_string(), "0");  // Col 0
}

// ── Layer 3: Algebraic ────────────────────────────────────────────

#[test]
fn layer3_algebraic() {
    assert_eq!(IndexedTritSeq::from_char('B').algebraic().to_hash_string(), "2110");
}

// ── Layer 4: Milesian ─────────────────────────────────────────────

#[test]
fn layer4_milesian() {
    // 'A' trits "2102" → digits 2,1,0,2 → weights 3,2,1,3 → sum 9 = 100₃
    assert_eq!(IndexedTritSeq::from_char('A').milesian_value().to_hash_string(), "100");
}

// ── Layer 5: Historical Figures ───────────────────────────────────

#[test]
fn layer5_hist_plenum_from_char() {
    let idx = IndexedTritSeq::from_char('A');
    let (g, p) = idx.historical_figure().unwrap();
    assert_eq!(g.to_hash_string(), "0");  // plenum
    assert_eq!(p.to_hash_string(), "0");  // plenum
}

#[test]
fn layer5_hist_via_new() {
    let trits = TritSeq::from_char('Σ');
    let geo = vec![
        TritSeq(Box::new([Trit::Zero])),
        TritSeq(Box::new([Trit::Zero])),
        TritSeq(Box::new([Trit::Zero])),
    ];
    let milesian = TritSeq(Box::new([Trit::One]));
    let group = TritSeq(Box::new([Trit::One, Trit::Zero]));    // 3 = philosophers
    let position = TritSeq(Box::new([Trit::One]));              // 1 = first
    let element = TritSeq(Box::new([Trit::Zero]));
    let tier = TritSeq(Box::new([Trit::One]));
    let idx = IndexedTritSeq::new(
        trits, geo, milesian,
        group.clone(), position.clone(),
        element,
        "SOCR-001".to_string(),
        tier,
        "philosophy,ethics,ancient".to_string(),
        Vec::new(),
    );
    let (g, p) = idx.historical_figure().unwrap();
    assert_eq!(g.to_hash_string(), "10");  // 3
    assert_eq!(p.to_hash_string(), "1");   // 1
    assert_eq!(idx.marker_record(), "SOCR-001");
    assert_eq!(idx.alphabetical_oracle(), "philosophy,ethics,ancient");
}

// ── Layer 6: Chemical Element ─────────────────────────────────────

#[test]
fn layer6_element_plenum_from_char() {
    assert_eq!(
        IndexedTritSeq::from_char('A').chemical_element().unwrap().to_hash_string(),
        "0"  // plenum
    );
}

// ── Layer 7: Marker Record ────────────────────────────────────────

#[test]
fn layer7_marker_bmp() {
    assert_eq!(IndexedTritSeq::from_char('A').marker_record(), "U+0041");
}

#[test]
fn layer7_marker_supplementary() {
    assert_eq!(IndexedTritSeq::from_char('𐀀').marker_record(), "U+010000");
}

// ── Layer 8: Greek Tier ───────────────────────────────────────────

#[test]
fn layer8_tier_units() {
    // U+0001 → base-27 digit [1], register 0 → Alpha = 1
    assert_eq!(IndexedTritSeq::from_char('\u{0001}').greek_tier().to_hash_string(), "1");
}

#[test]
fn layer8_tier_tens() {
    // 270 → first base-27 digit 10, register 1 → Beta = 2
    let idx = IndexedTritSeq::from_char(char::from_u32(270).unwrap());
    assert_eq!(idx.greek_tier().to_hash_string(), "2");
}

// ── Layer 9: Alphabetical Oracle ──────────────────────────────────

#[test]
fn layer9_oracle() {
    assert_eq!(IndexedTritSeq::from_char('A').alphabetical_oracle(), "P0R0C65");
}

// ── Layer 10: Manifold Coordinates ────────────────────────────────

#[test]
fn layer10_manifold_neutral() {
    assert!(IndexedTritSeq::from_char('A').manifold_coords().is_empty());
}

#[test]
fn layer10_manifold_via_new() {
    let trits = TritSeq::from_char('A');
    let geo = vec![
        TritSeq(Box::new([Trit::Zero])),
        TritSeq(Box::new([Trit::Zero])),
        TritSeq(Box::new([Trit::Zero])),
    ];
    let coord_124 = TritSeq(Box::new([Trit::One, Trit::One, Trit::One, Trit::Two, Trit::One]));
    let coord_33  = TritSeq(Box::new([Trit::One, Trit::Zero, Trit::Two, Trit::Zero]));
    let idx = IndexedTritSeq::new(
        trits,
        geo,
        TritSeq(Box::new([Trit::One])),
        TritSeq(Box::new([Trit::Zero])),
        TritSeq(Box::new([Trit::Zero])),
        TritSeq(Box::new([Trit::Zero])),
        "FORGE-855888".to_string(),
        TritSeq(Box::new([Trit::One])),
        "arch182,coordinate124".to_string(),
        vec![coord_124.clone(), coord_33.clone()],
    );
    let coords = idx.manifold_coords();
    assert_eq!(coords.len(), 2);
    assert_eq!(coords[0].to_hash_string(), "11121");  // 124₃
    assert_eq!(coords[1].to_hash_string(), "1020");   // 33₃
    assert_eq!(idx.marker_record(), "FORGE-855888");
}

// ── Full cascade ──────────────────────────────────────────────────

#[test]
fn cascade_lex_ordering() {
    assert!(IndexedTritSeq::from_char('A') < IndexedTritSeq::from_char('B'));
}

#[test]
fn cascade_manifold_tiebreaker() {
    let trits = TritSeq::from_char('A');
    let geo = vec![
        TritSeq(Box::new([Trit::Zero])),
        TritSeq(Box::new([Trit::Zero])),
        TritSeq(Box::new([Trit::Zero])),
    ];
    let z = TritSeq(Box::new([Trit::Zero]));
    let m = TritSeq(Box::new([Trit::One]));
    let t = TritSeq(Box::new([Trit::One]));
    // Identical on layers 1-9, but a has empty manifold, b has [1]
    let a = IndexedTritSeq::new(
        trits.clone(), geo.clone(), m.clone(),
        z.clone(), z.clone(), z.clone(),
        "X".to_string(), t.clone(), "Y".to_string(),
        vec![],
    );
    let b = IndexedTritSeq::new(
        trits, geo, m,
        z.clone(), z.clone(), z,
        "X".to_string(), t, "Y".to_string(),
        vec![TritSeq(Box::new([Trit::One]))],
    );
    assert!(a < b);
}
