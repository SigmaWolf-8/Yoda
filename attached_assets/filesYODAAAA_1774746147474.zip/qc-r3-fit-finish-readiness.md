# QC-R3 — Fit, Finish & Market Readiness (Round 3)

**Document Under Review:** YODA-PATCH-001 production-003 (13 source files, 2 scripts)
**Prior Rounds:** R1 (15 findings, 6 fixed), R2 (7 findings, all fixed in prod-003)
**Revision:** 2026-03-28
**Finding ID Prefix:** R3

---

## Round 1 + Round 2 Response

All R1 and R2 IMPORTANT/MINOR findings have been addressed in production-003. The running findings list shows 15 FIXED, 2 Phase 3 gates (documented), 2 monitor-at-scale (acceptable). No outstanding blockers from prior rounds.

---

## R3 Review: Fit, Finish & Market Readiness

### Finding 1
- **Section:** agent.rs — find_best_match(), tie-breaking with 157 agents
- **Severity:** IMPORTANT
- **Finding:** When two or more agents score identically on competency overlap, `find_best_match()` returns whichever `HashMap::values()` yields first — which is non-deterministic in Rust's `HashMap`. With 157 agents, ties are statistically likely. Example: if a query mentions "security" and both `engineering-security-engineer` and `capomastro-plenumnet-integration` have "security" as a competency tag (each scoring 1/1), the winner varies between server restarts. This produces non-reproducible agent selection, which violates the Salvi Standard of Scrutiny (results must be deterministic and auditable).
- **Recommendation:** Add a deterministic tie-breaker. When scores are equal, prefer: (a) Capomastro division agents over upstream agents (proprietary expertise takes priority), then (b) alphabetical agent_id order as a final stable tiebreaker. Replace the `if score > *best_score` check with:
  ```rust
  if score > *best_score
      || (score == *best_score && is_preferred(config, best_config))
  ```
  Where `is_preferred` checks division priority then lexicographic agent_id.
- **Verification:** With two agents that score identically for a given query, restart the server 10 times and verify the same agent is selected each time. Log the selected agent_id and score in the tracing output to enable audit.

### Finding 2
- **Section:** query.rs — spawn_bg_inference(), max_tokens hardcoded to 1024
- **Severity:** IMPORTANT
- **Finding:** The relay inference request uses `max_tokens: 1024` (line ~104). For complex queries that require multi-page analysis, code generation, or detailed security reviews, 1024 tokens (~750 words) is insufficient. The response will be truncated without warning. The `dispatch.rs` module uses `DEFAULT_MAX_TOKENS = 4096` for direct engine calls, and the browser relay in `QueryInput.tsx` uses `max_tokens: 4096`. The relay path is the only one limited to 1024. This creates an inconsistent user experience: the same query produces a full response via browser relay but a truncated response via PlenumLAN relay.
- **Recommendation:** Change `max_tokens: 1024` to `max_tokens: 4096` in the RelayInferRequest construction inside `spawn_bg_inference()`. Consider making it configurable via env var (`YODA_BG_MAX_TOKENS`) alongside the existing retry config.
- **Verification:** Submit a query that requires a multi-page response (e.g., "Analyze the security implications of migrating from RSA-4096 to TL-DSA"). Verify the relay-routed response is comparable in length to a browser-relay response for the same query.

### Finding 3
- **Section:** query.rs — submit_query(), duplicate competency inference
- **Severity:** MINOR
- **Finding:** The function calls `decomposer::decompose_simple()` (which internally calls `infer_competencies()`) to build the task's competencies JSON, then separately calls `infer_competencies_pub()` to match an agent. Both calls parse the same query text with the same keyword table, producing the same result. This is a redundant computation — the competencies are computed twice for every query.
- **Recommendation:** Compute competencies once, use for both the task row and agent matching:
  ```rust
  let competencies_vec = decomposer::infer_competencies(&req.text);
  let competencies = serde_json::to_value(&competencies_vec).unwrap_or_default();
  // ... later ...
  let (matched_agent_id, matched_agent_prompt) = {
      match state.agents.find_best_match(&competencies_vec) { ... }
  };
  ```
- **Verification:** Add a debug log of the competencies_vec and verify it appears once, not twice, in the server log per query submission.

### Finding 4
- **Section:** routes.rs — add_task_message(), R2-4 fallback chain depth
- **Severity:** MINOR
- **Finding:** The R2-4 fix for follow-up messages creates a 3-level fallback chain: (1) read stored `primary_agent_role` → (2) if role not in registry, re-infer from title → (3) if no match, use `default_yoda_prompt()`. Level 2 includes two nested async DB queries (read title, then match). While correct, this is 4 DB queries in the worst case (read role, role not found → read title, match, then the existing message fetch). For the common case (stored role found in registry), it's 1 DB query — efficient.
- **Recommendation:** Acceptable as-is. The fallback chain handles registry reload scenarios (agent compiled, server restarted with different agents) gracefully. The warn-level log at the fallback to level 2 ("Stored agent role not found in registry") ensures visibility.
- **Verification:** N/A — informational. The common path is efficient.

### Finding 5
- **Section:** cube_relay.rs — relay_ack scoped handler, requestId extraction
- **Severity:** MINOR
- **Finding:** The scoped relay_ack fix attempts to parse `env.payload` as JSON to extract `requestId`. However, the `RelayEnvelope` struct already deserializes `payload` as `Option<String>` — the payload is a **stringified JSON** inside the envelope, not a nested object. The code correctly handles this: `serde_json::from_str::<serde_json::Value>(payload_str)`. But the CRS relay implementation may wrap the ack differently — the relay may return the original envelope's metadata in the ack (including `requestId` at the top level of the ack message, not inside `payload`). Without testing against the live CRS relay, the extraction path is UNVERIFIED.
- **Recommendation:** Add a fallback: if `requestId` is not found in `payload`, also check the top-level envelope fields. The relay may include `requestId` or `originalRequestId` at the envelope level. Log the raw ack text at debug level to enable field-level debugging.
- **Verification:** Send a relay inference request, force it to fail (disconnect the target daemon), and inspect the relay_ack message format. Verify requestId extraction succeeds.

### Finding 6
- **Section:** scripts/bootstrap-agents.sh — division directory list
- **Severity:** MINOR
- **Finding:** The script hardcodes a list of division directories to copy: `engineering design marketing testing support specialized game-development product management academic paid-media`. If The Agency adds new divisions (which it has — the repo shows active PR activity adding agents), they won't be copied. The script also lists `product management` with a space, which would fail as a directory name (should be `product-management` or handled with globbing).
- **Recommendation:** Replace the hardcoded list with a glob: copy all top-level directories that contain `.md` files, excluding `scripts`, `integrations`, `examples`, and `.github`:
  ```bash
  for div in "$TMPDIR/agency-agents"/*/; do
      dirname=$(basename "$div")
      case "$dirname" in scripts|integrations|examples|.github) continue;; esac
      if ls "$div"/*.md &>/dev/null; then
          cp -r "$div" "agents/upstream/"
          echo "  Copied division: $dirname"
      fi
  done
  ```
- **Verification:** After cloning, verify that all division directories containing .md files are present in `agents/upstream/`. Check that no script or integration directories were copied.

### Finding 7
- **Section:** Overall — default YODA prompt used in 3 places
- **Severity:** MINOR
- **Finding:** The default YODA system prompt ("You are YODA — a senior engineering intelligence system...") is defined in 3 places: (1) query.rs `submit_query()` inline string, (2) routes.rs `default_yoda_prompt()` function, and (3) QueryInput.tsx `SYSTEM_PROMPT` constant. If the prompt needs to change, it must be updated in 3 locations. The routes.rs version is extracted into a function (good), but query.rs still has it inline.
- **Recommendation:** Move the default prompt to a constant in a shared location. Options: (a) `const DEFAULT_SYSTEM_PROMPT: &str = "..."` in `query.rs` and import in `routes.rs`, or (b) define in `state.rs` as part of AppState configuration. The frontend prompt is separate (browser-side fallback) and can remain independent.
- **Verification:** Grep for "senior engineering intelligence" across the codebase and verify only one authoritative definition exists server-side.

### Finding 8
- **Section:** Overall — environment variable documentation
- **Severity:** MINOR
- **Finding:** Production-003 introduces 3 new environment variables (`YODA_BG_MAX_ATTEMPTS`, `YODA_BG_RETRY_WAIT_SECS`, `PLENUMLAN_PUBLIC_KEY`) plus references an existing one (`AGENTS_COMPILED_PATH`). The DEPLOY.md documents these, but the `docker-compose.yml` in the repo root does not include them. An operator deploying via Docker would not know these variables exist.
- **Recommendation:** Add the new environment variables to `docker-compose.yml` with comments and default values. Also add to any `.env.example` file if one exists.
- **Verification:** Run `docker-compose up` and verify the server starts with the defaults logged.

---

## R3 Summary Verdict

**PASS WITH CONDITIONS**

Production-003 is deployable. All R1 and R2 findings are resolved. The code is clean, well-commented, and the QC finding references (R1-A1-1, R2-4, etc.) throughout the codebase provide excellent traceability. Two IMPORTANT findings remain:

1. **R3-1 (agent tie-breaking):** Non-deterministic agent selection with 157 agents when competency scores tie. With Salvi's actual roster of 157 agents, this WILL happen. Needs a deterministic tiebreaker before production use with the full roster.

2. **R3-2 (max_tokens 1024):** Relay inference capped at 1024 tokens while browser relay uses 4096. Users will see truncated responses via PlenumLAN relay. Should be 4096 to match.

The remaining MINOR findings (R3-3 through R3-8) are polish items that can be addressed iteratively. None block deployment.

**Market Readiness Assessment:**
- The system handles the core use case (submit query → get specialized AI response) correctly.
- Agent matching now uses 106 keywords and selects from 157 agents with competency scoring.
- Background inference is cancellable, status-guarded, and doesn't leak resources.
- The relay transport is resilient to individual failures without cascading.
- The QC review trail (R1 → R2 → R3) provides audit evidence of engineering rigor.
- Phase 3 gaps (TL-DSA relay auth, Rep C identity) are documented and gated.

---

## Updated Running Findings List

### NEW from R3

| # | ID | Section | Severity | Finding | Status |
|---|-----|---------|----------|---------|--------|
| 23 | R3-1 | agent.rs — find_best_match() | IMPORTANT | Non-deterministic tie-breaking with 157 agents; HashMap iteration order varies | OPEN |
| 24 | R3-2 | query.rs — spawn_bg_inference() | IMPORTANT | max_tokens hardcoded to 1024; browser relay uses 4096; truncated responses | OPEN |
| 25 | R3-3 | query.rs — submit_query() | MINOR | Duplicate competency inference (called twice for same query) | OPEN |
| 26 | R3-4 | routes.rs — add_task_message() | MINOR | 3-level fallback chain — acceptable, informational | CLOSED |
| 27 | R3-5 | cube_relay.rs — relay_ack | MINOR | requestId extraction path UNVERIFIED against live CRS relay | OPEN |
| 28 | R3-6 | scripts/bootstrap-agents.sh | MINOR | Hardcoded division list; space in "product management"; no glob | OPEN |
| 29 | R3-7 | Overall — default prompt | MINOR | Same default prompt defined in 3 places | OPEN |
| 30 | R3-8 | Overall — docker-compose.yml | MINOR | New env vars not added to Docker config | OPEN |

---

## Cumulative Score (R1 + R2 + R3)

| Metric | R1 | R2 | R3 | Total |
|--------|-----|-----|-----|-------|
| CRITICAL | 0 | 0 | 0 | **0** |
| IMPORTANT | 6 | 4 | 2 | **12** |
| MINOR | 9 | 3 | 6 | **18** |
| Total | 15 | 7 | 8 | **30** |
| FIXED | 6 | — | — | **22** (incl. R2 fixes in prod-003) |
| OPEN — actionable | — | — | — | **2** (R3-1, R3-2) |
| OPEN — polish | — | — | — | **4** |
| Phase 3 gate | — | — | — | **2** |
| Monitor | — | — | — | **2** |
| CLOSED | — | — | — | **2** |

---

*QC-R3 Review Complete — 2026-03-28*
*Capomastro Holdings Ltd. — Applied Physics Division*
