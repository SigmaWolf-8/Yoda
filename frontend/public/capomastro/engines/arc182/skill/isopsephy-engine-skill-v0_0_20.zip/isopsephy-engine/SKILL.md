---
name: isopsephy-engine
description: >
  Full-document isopsephy engine with Arc182 Markdown Document (AMD) output AND a
  self-computing HTML runtime report, integrated with synthesis-framework (fold
  certificate §9) and upiid-framework (Value Metabolism §10). Converts ANY text to
  Greek via scholarly transliteration, computes Milesian isopsephy for every word,
  runs automatic framework analysis, bilingual (source vs English gloss) with all
  deltas, and draws four charts at open-time (DR distribution, Arc182 quadratic
  parabolic metric, 364-degree polar register, Vesica Piscis 153 full fish with
  tail). Trigger on: isopsephy, gematria, isopsephic value, transliterate to Greek,
  digital root, Milesian value, θ-family, Bézout seed, Arc182, AMD, fold
  certificate, vesica, 153, Crystal Ladder, or any request to convert text and sum
  letter values. Handles entire documents not just single words. ALWAYS use this
  skill instead of computing isopsephy manually. The HTML report recomputes every
  value in browser BigInt from a Forma Codex pipe-glyph registry | zero JSON, zero
  pre-baked figures, rejection-based live assertions.
---

# Isopsephy Document Analysis Engine | v0.0.20

## §1 | Purpose

This skill processes **entire documents** through a five-stage pipeline
governed by the UPIID V1.1 Value Metabolism Cycle:

| Pipeline Stage | UPIID Phase | Action |
|---------------|-------------|--------|
| **Ingest** | Critical Ingestion | Extract words, strip LaTeX commands, filter non-alpha |
| **Transliterate** | Critical Ingestion | Latin-script → Greek via scholarly mapping (bilingual: source + English gloss) |
| **Compute** | Analytical Digestion | Milesian isopsephy + digital roots + factorization + all deltas |
| **Analyze** | Creative Synthesis | Framework hits + Λ-lattice jewels + θ-catch + structural signatures + fold metrics |
| **Emit** | Asset Excretion | Forma Codex AMD (.md) + self-computing HTML runtime report |

Words already in Greek pass through directly. Mixed-script words are handled.

## §2 | How to Use

The engine lives at:

```
/mnt/skills/user/isopsephy-engine/scripts/isopsephy_engine.py
```

Copy it (with its gloss lexicon) to the working directory before running:

```bash
cp /mnt/skills/user/isopsephy-engine/scripts/isopsephy_engine.py /home/claude/
cp /mnt/skills/user/isopsephy-engine/scripts/gloss.py /home/claude/   # IT→EN seed lexicon (optional; identity fallback)
```

### §2.1 | Command-Line Modes

```bash
# Single words or phrases (console report)
python3 isopsephy_engine.py "Σάλβι"

# Entire file → full report bundle (AMD .md + runtime .html) into outdir
python3 isopsephy_engine.py --file /path/to/document.txt --amd /path/to/outdir
python3 isopsephy_engine.py document.txt outdir          # positional shorthand

# Pipe from stdin
echo "The Master Builder" | python3 isopsephy_engine.py --stdin outdir

# Summary only (no files)
python3 isopsephy_engine.py --file doc.md --summary-only

# Interactive mode
python3 isopsephy_engine.py --interactive
```

### §2.2 | HTML Runtime Report (primary deliverable)

`isopsephy_amd.html` is a guaranteed-computation artifact. It carries only a
Forma Codex pipe-glyph registry (`word|gloss|count` | zero JSON). On open, the
browser's BigInt layer re-derives the entire axiom chain, every word value,
every delta, and draws all four charts on canvas at runtime:

1. §3 Digital-Root Distribution | bilingual bars, X/Y axes, θ marker
2. §3b Arc 182 Quadratic Parabolic Metric | M(x) = x(182−x)/91, vertex (Λ,Λ), fold of C = 364, Λ-jewels ringed
3. §3b′ 364° Polar Register | spokes at kΛ, ticks every 28 = C/r
4. §3c Vesica Piscis 153 | full fish, lens r√c ≈ 265, tail sweep C/r = 28°, θ-catch counted, mod-17 words ringed

§0 runs fourteen rejection-based axiom assertions (C = δΛ, δ-torsion C−360 = δ,
ring closure of 547, Ĉ-eigenvalues 37/271/331/397/547 all prime, ς² bridge to
777, Fish crosswalk 777 = 153 + δ²cr, Archimedes deficit c·153² − 265² = β,
θ-transparency dr(Σ+k·153) = dr(Σ)). Any failure fires a red rejection banner.
KaTeX renders the mathematics. PlenumNET brand: BG #0F0C0A, accent #4A9EF5,
readable text pure white #FFFFFF with solid grays only.

## §3 | Transliteration Rules

Scholarly Latin-to-Greek transliteration:

### Digraphs (matched first)

| th→θ | ph→φ | ch→χ | ps→ψ | ks→ξ | rh→ρ | ou→ου |

### Single Letters

| a→α | b→β | c→κ* | d→δ | e→ε | f→φ | g→γ | h→η | i→ι |
| j→ι | k→κ | l→λ | m→μ | n→ν | o→ο | p→π | q→κ | r→ρ |
| s→σ/ς | t→τ | u→υ | v→β | w→ω | x→ξ | y→υ | z→ζ |

*c before e/i → γ (soft c). Final sigma rule: word-final σ → ς.

## §4 | AMD Document Structure

| Section | Content | Source Skill |
|---------|---------|-------------|
| Header | Engine, source, timestamp, governance | — |
| §0 (HTML) | Live axiom assertions, rejection-based | academic-formal-derivation |
| §1 | Bilingual Transliteration Ledger (Σ_IT, Σ_EN, ΔΣ, Δdr per word) | — |
| §2 | Document Aggregate both registers (Σ, factorization, dr, Δ_doc, mod Fish, mod 17) | — |
| §3 | Digital-Root Distribution | unweighted, bilingual, runtime chart | — |
| §3b | Arc 182 Quadratic Parabolic Metric + 364° polar | Λ-lattice jewels | — |
| §3c | Vesica Piscis 153 | full fish with tail | θ-catch | — |
| §4 | Framework Hits with epistemic labels (both registers) | upiid-framework (Letter E) |
| §5 | Structural Signatures (palindromes, Bézout, prime powers) | — |
| §6 | Isopsephic Twins (same-language and cross-language) | — |
| §7 | Leaderboard (top 10 by value) | — |
| §8 | Boxed Identities incl. the Sealed Web (ς² bridge, Fish crosswalk) | — |
| §9 | **Fold Certificate** (Φ, 𝒞, ℛ, 𝒢 quartet) | synthesis-framework (§1.1) |
| §10 | **UPIID V1.1 Value Metabolism Trace** | upiid-framework |
| Colophon | Authorship, timestamp, motto | — |

## §5 | Synthesis-Framework Integration (§9 Fold Certificate)

| Condition | Symbol | What is computed |
|-----------|:------:|-----------------|
| **Fold** | Φ | Shared invariant: Milesian bijective base-27 register (both languages, one map) |
| **Compression** | 𝒞 | Ratio: total words / framework signals (exact + structural + θ) |
| **Relational Inertia** | ℛ | Forge-prime relations surviving across words (p+r=π, p×r=Λ, Λ-jewels, cross-script twins) |
| **Geometry** | 𝒢 | θ-attractor cone, θ-dominant fiber, θ-threaded lattice, or dispersed |

The Witness-Derivability Test (§1.2) passes when at least one relation is
re-derivable from inside Σ without importing source elements.

## §6 | UPIID Integration (§10 Value Metabolism Trace)

| Phase | Cycle | Pipeline stage |
|:-----:|-------|---------------|
| 1 | Critical Ingestion | Word extraction + bilingual transliteration |
| 2 | Analytical Digestion | Isopsephy computation + factorization + deltas |
| 3 | Creative Synthesis | Framework hits + jewels + catch + signatures |
| 4 | Asset Excretion | AMD + runtime HTML report emission |

Epistemic labels (UPIID Letter E):
- **Exact** | isopsephy value = framework integer (e.g., 243 = 3⁵)
- **Structural** | factorization carries Forge primes, or palindromic digits
- **Observed** | digital root matches framework label (dr=9 = θ)

Governing A-Z Letters: A (Authority), E (Epistemology), R (Reproducibility), V (Verification)

Salvi Standard of Scrutiny: impeachable and impenetrable.

## §7 | Cross-Skill Integration

| Skill | How to connect |
|-------|---------------|
| **greek-atomic-invariant** | After isopsephy, use GAIT for letter-level delta analysis |
| **synthesis-framework** | Feed AMD results as θᵢ elements into a synthesis white paper |
| **upiid-framework** | AMD §10 already implements the metabolism trace |
| **plenumnet-repo-guide** | Cross-reference framework constants against architecture |
| **compression-geometry-uv** | Connect isopsephic values to UV spectral predictions |

## §8 | Known Verified Values

| Word | Isopsephy | Factorization | dr | Note |
|------|-----------|---------------|:--:|------|
| Σάλβι | 243 | 3⁵ | 9 | Palindromic DR (2,1,3,2,1) | Bézout seed |
| θε ("the") | 14 | 2×7 | 5 | = π_geom = βp = r+α (NOTE: p+r = 20 = βι, a prior corruption repaired in v0.0.20) |
| Salvalaggio | 351 | 3³ × 13 | 9 | = b³ × r |
| ParaCalculi | 693 | 3² × 7 × 11 | 9 | = θ × pq |
| Capomastro | 882 | 2 × 3² × 7² | 9 | carries p² and b² |
| origin | 243 | 3⁵ | 9 | Isopsephic twin of Σάλβι |
| hidden | 81 | 3⁴ | 9 | = b⁴ |
| singola | 364 | 2² × 7 × 13 | 4 | = C = 4Λ (lattice jewel) |
| completa | 546 | 2 × 3 × 7 × 13 | 6 | = ςΛ = 547 − α (lattice jewel) |
| Mersenne | 455 | 5 × 7 × 13 | 5 | = 5Λ, sits at vertex (Λ,Λ) of Arc 182 |
| uguaglianze | 910 | 2 × 5 × 7 × 13 | 1 | = ιΛ (lattice jewel) |

## §9 | Version History

- v0.0.20 | 2026-07-03 | Engine restored to spec (scripts were absent from the skill), then extended: bilingual ledger with all deltas, unweighted-default DR, Arc 182 quadratic parabolic metric, 364° polar register, Vesica Piscis 153 with full tail, self-computing HTML runtime report (Forma Codex pipe-glyph, BigInt, rejection-based, KaTeX, four runtime canvases), CLI modes per §2.1. The HTML runtime report supersedes the formerly referenced JSX viewer.
