// ── Shared script generators for YODA self-hosted engine install / reconnect ──
// Imported by both ModelInstallModal (reconnect modal) and EngineSlot (direct
// install download).  Keep this file free of React imports.

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Detect broad OS category from navigator.userAgent. */
export function detectOS(): 'windows' | 'mac' | 'linux' {
  const ua = navigator.userAgent;
  if (/Win/i.test(ua)) return 'windows';
  if (/Mac/i.test(ua) && !/iPhone|iPad/i.test(ua)) return 'mac';
  return 'linux';
}

/** Trigger a browser file download. */
export function triggerDownload(content: string, filename: string, mime = 'text/plain'): void {
  const blob = new Blob([content], { type: mime });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/**
 * Wrap a PowerShell script in a self-executing Windows batch file.
 *
 * Preferred path: encode the entire PS1 as UTF-16LE base64 and pass it
 * directly via -EncodedCommand — no temp files, no decode step, no race.
 * Falls back to the temp-file approach (with a single %RANDOM% captured
 * once into %RND%) only when the script exceeds the ~30 KB command-line limit.
 */
export function makeBatWrapper(psScript: string, _modelName: string): string {
  // Convert PS1 to UTF-16LE bytes (what -EncodedCommand expects)
  const utf16leBytes: number[] = [];
  for (const char of psScript) {
    const code = char.charCodeAt(0);
    utf16leBytes.push(code & 0xFF, (code >> 8) & 0xFF);
  }
  const encodedScript = btoa(String.fromCharCode(...utf16leBytes));

  // Simple inline path — no temp files at all
  if (encodedScript.length < 30000) {
    return [
      '@echo off',
      'title YODA Installer',
      'powershell.exe -NoProfile -ExecutionPolicy Bypass -EncodedCommand ' + encodedScript,
      'pause',
    ].join('\r\n') + '\r\n';
  }

  // Fallback: temp-file approach. Capture %RANDOM% once into %RND% so BF and
  // PF share the same suffix — the original %RANDOM%%RANDOM% bug caused them
  // to get different values, breaking the decode→execute hand-off.
  const bytes  = new TextEncoder().encode(psScript);
  const binary = Array.from(bytes, (b) => String.fromCharCode(b)).join('');
  const b64    = btoa(binary);
  const echos  = (b64.match(/.{1,76}/g) ?? []).map((l) => `echo ${l}`).join('\r\n');

  return [
    '@echo off',
    'title YODA Installer',
    'setlocal',
    'set "RND=%RANDOM%%RANDOM%"',
    'set "BF=%TEMP%\\yoda_%RND%.b64"',
    'set "PF=%TEMP%\\yoda_%RND%.ps1"',
    '(',
    echos,
    ') > "%BF%"',
    'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "' +
      '$b=([IO.File]::ReadAllText($env:BF) -replace \'[^A-Za-z0-9+/=]\',\'\');' +
      '[IO.File]::WriteAllBytes($env:PF,[Convert]::FromBase64String($b))"',
    'del "%BF%" 2>nul',
    'if not exist "%PF%" ( echo ERROR: Failed to decode installer script. & pause & exit /b 1 )',
    'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PF%"',
    'del "%PF%" 2>nul',
    'pause',
  ].join('\r\n') + '\r\n';
}

// ── Shared bash helpers (embedded verbatim in every bash script) ───────────────

const BASH_FIND_LLAMA = `
# Find llama-server in known locations
_find_llama_server() {
  local candidates=(
    "$(command -v llama-server 2>/dev/null || true)"
    "$HOME/.local/bin/llama-server"
    "/usr/local/bin/llama-server"
    "/opt/homebrew/bin/llama-server"
    "$(find "$HOME/llama.cpp" -name "llama-server" -type f 2>/dev/null | head -1 || true)"
  )
  for c in "\${candidates[@]}"; do
    [[ -n "$c" && -x "$c" ]] && { echo "$c"; return 0; }
  done
  return 1
}`.trim();

// ── Install scripts (full: llama-server + PlenumNET + model download) ─────────

export function makeBashInstallScript(
  modelName : string,
  ggufRepo  : string,
  ggufFile  : string,
  port      : number,
  token     : string,
  crsUrl    : string,
): string {
  return `#!/usr/bin/env bash
# YODA Self-Host Installer
# Model: ${modelName}  |  Port: ${port}  |  Token: ${token}
set -euo pipefail

SESSION_TOKEN="${token}"
CRS_URL="${crsUrl}"
GGUF_REPO="${ggufRepo}"
GGUF_FILE="${ggufFile}"
SERVER_PORT="${port}"
PLENUMNET_DIR="\$HOME/PlenumNET"
MODELS_DIR="\$HOME/yoda-models"
MODEL_PATH="\$MODELS_DIR/\$GGUF_FILE"
LOG_DIR="\$HOME/yoda-models/logs"
IDENTITY_DIR="\$HOME/.plenumnet/identity"

echo "=== YODA Self-Host Installer ==="
echo "Model  : ${modelName}"
echo "Port   : \$SERVER_PORT"
echo ""

# ── 1. Detect local IP ────────────────────────────────────────────────
OS=\$(uname -s)
if [[ "\$OS" == "Darwin" ]]; then
  LOCAL_IP=\$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "")
else
  LOCAL_IP=\$(ip route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if(\$i=="src") print \$(i+1)}' | head -1)
  [[ -z "\$LOCAL_IP" ]] && LOCAL_IP=\$(hostname -I 2>/dev/null | awk '{print \$1}')
fi
LOCAL_IP=\${LOCAL_IP:-"0.0.0.0"}
CUBE_ENDPOINT="\${LOCAL_IP}:51820"
echo "Local endpoint : \$CUBE_ENDPOINT"
[[ "\$LOCAL_IP" == "0.0.0.0" ]] && echo "  ⚠ Could not detect local IP — routing may not work."

# ── 2. Check / install Rust ───────────────────────────────────────────
echo ""
echo "Checking Rust/Cargo..."
if ! command -v cargo &>/dev/null && [[ ! -f "\$HOME/.cargo/bin/cargo" ]]; then
  echo "  → Rust not found — installing via rustup..."
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --no-modify-path
  echo "  ✓ Rust installed"
else
  echo "  → Cargo already present"
fi
# Always ensure cargo is on PATH for this session
[[ -f "\$HOME/.cargo/env" ]] && source "\$HOME/.cargo/env"
export PATH="\$HOME/.cargo/bin:\$PATH"
if ! command -v cargo &>/dev/null; then
  echo "  ✗ cargo still not found after install — check rustup completed cleanly."
  exit 1
fi

# ── 3. Check Git ──────────────────────────────────────────────────────
if ! command -v git &>/dev/null; then
  echo "  ✗ Git is not installed."
  if [[ "\$OS" == "Darwin" ]]; then
    echo "  → Run: brew install git"
  else
    echo "  → Run: sudo apt install git  (or equivalent for your distro)"
  fi
  exit 1
fi

# ── 4. Clone/update PlenumNET and build daemon ────────────────────────
echo ""
echo "Installing PlenumNET (inter-cube)..."
_clone_plenumnet() {
  echo "  → Cloning PlenumNET..."
  git clone --depth 1 https://github.com/SigmaWolf-8/Ternary "\$PLENUMNET_DIR"
}
if [[ -d "\$PLENUMNET_DIR/.git" ]]; then
  echo "  → Repository exists, updating..."
  git -C "\$PLENUMNET_DIR" pull --ff-only 2>/dev/null || true
  # If key files are still missing the previous clone was a broken sparse clone — re-clone fresh
  if [[ ! -f "\$PLENUMNET_DIR/services/inter-cube/Cargo.toml" ]]; then
    echo "  → Existing checkout is incomplete — re-cloning..."
    rm -rf "\$PLENUMNET_DIR"
    _clone_plenumnet
  fi
else
  _clone_plenumnet
fi
# Hard stop if source is still missing after clone
for member in "services/inter-cube/Cargo.toml" "ternary-math/Cargo.toml"; do
  [[ -f "\$PLENUMNET_DIR/\$member" ]] || { echo "  ✗ \$member missing after clone — check network and try again."; exit 1; }
done

echo "  → Building inter-cube daemon (first build takes a few minutes)..."
mkdir -p "\$LOG_DIR"
(cd "\$PLENUMNET_DIR" && cargo build --release --package inter-cube)
DAEMON=\$(find "\$PLENUMNET_DIR/target/release" -maxdepth 1 -name "inter-cube*" ! -name "*.d" -type f 2>/dev/null | head -1)
[[ -n "\$DAEMON" && -x "\$DAEMON" ]] || { echo "  ✗ Build completed but no inter-cube binary found in \$PLENUMNET_DIR/target/release"; exit 1; }
echo "  ✓ Daemon built: \$DAEMON"

# ── 5. Identity passphrase + PT26-DSA keygen ─────────────────────────
echo ""
echo "Setting up PlenumNET identity..."
mkdir -p "\$IDENTITY_DIR"
chmod 700 "\$IDENTITY_DIR"
PASSPHRASE_FILE="\$IDENTITY_DIR/.passphrase"

if [[ -f "\$PASSPHRASE_FILE" ]]; then
  CUBE_PASSPHRASE=\$(cat "\$PASSPHRASE_FILE")
  echo "  → Loaded existing identity passphrase"
else
  # openssl preferred; python fallbacks avoid tr|head SIGPIPE under set -o pipefail
  CUBE_PASSPHRASE=\$(openssl rand -hex 24 2>/dev/null \
    || python3 -c "import os,sys; sys.stdout.write(os.urandom(24).hex())" 2>/dev/null \
    || python  -c "import os,binascii,sys; sys.stdout.write(binascii.hexlify(os.urandom(24)).decode())" 2>/dev/null \
    || echo "")
  printf '%s' "\$CUBE_PASSPHRASE" > "\$PASSPHRASE_FILE"
  chmod 600 "\$PASSPHRASE_FILE"
  echo "  ✓ Generated and saved identity passphrase"
fi
export CUBE_IDENTITY_PASSPHRASE="\$CUBE_PASSPHRASE"

echo "  → Generating PT26-DSA identity keypair..."
_keygen_raw=\$(CUBE_MODE=keygen "\$DAEMON" 2>"\$LOG_DIR/keygen.log")
PUB_KEY=\$(echo "\$_keygen_raw" | grep "PT26-DSA Public Key" | grep -o '[0-9a-fA-F]*\$' | tr -d '[:space:]')
if [[ -z "\$PUB_KEY" ]]; then
  echo "  Keygen output:"
  echo "\$_keygen_raw" | while IFS= read -r _line; do echo "    \$_line"; done
  echo "  ✗ keygen produced no public key -- check \$LOG_DIR/keygen.log"
  exit 1
fi
echo "  ✓ Public key: \${PUB_KEY:0:32}..."

# ── 6. Install llama.cpp (llama-server) ──────────────────────────────
echo ""
echo "Installing llama.cpp..."
${BASH_FIND_LLAMA}

LLAMA_SERVER=\$(_find_llama_server || true)
if [[ -n "\$LLAMA_SERVER" ]]; then
  echo "  → llama-server already installed: \$LLAMA_SERVER"
else
  if [[ "\$OS" == "Darwin" ]]; then
    brew install llama.cpp
    LLAMA_SERVER=\$(command -v llama-server)
  else
    LLAMA_VER=\$(curl -sf "https://api.github.com/repos/ggerganov/llama.cpp/releases/latest" | grep '"tag_name"' | cut -d'"' -f4)
    [[ -z "\$LLAMA_VER" ]] && { echo "  ✗ Could not fetch llama.cpp release info."; exit 1; }
    LLAMA_URL="https://github.com/ggerganov/llama.cpp/releases/download/\${LLAMA_VER}/llama-\${LLAMA_VER}-bin-ubuntu-x64.zip"
    echo "  → Downloading llama.cpp \$LLAMA_VER..."
    curl -fL "\$LLAMA_URL" -o /tmp/llamacpp.zip
    mkdir -p "\$HOME/llama.cpp"
    unzip -o /tmp/llamacpp.zip -d "\$HOME/llama.cpp" >/dev/null
    rm -f /tmp/llamacpp.zip
    LLAMA_BIN=\$(find "\$HOME/llama.cpp" -name "llama-server" -type f | head -1)
    [[ -z "\$LLAMA_BIN" ]] && { echo "  ✗ llama-server binary not found after extraction."; exit 1; }
    mkdir -p "\$HOME/.local/bin"
    cp "\$LLAMA_BIN" "\$HOME/.local/bin/llama-server"
    chmod +x "\$HOME/.local/bin/llama-server"
    LLAMA_SERVER="\$HOME/.local/bin/llama-server"
    export PATH="\$HOME/.local/bin:\$PATH"
  fi
fi
echo "  ✓ llama-server: \$LLAMA_SERVER"

# ── 7. Register with YODA CRS (with retry) ────────────────────────────
echo ""
echo "Registering with YODA CRS..."
REG_OK=0
for attempt in 1 2 3; do
  HTTP=\$(curl -s -o /dev/null -w "%{http_code}" -X POST "\${CRS_URL}/api/salvi/inter-cube/crs/register" \\
    -H "Content-Type: application/json" \\
    -d '{"endpoint":"'\$CUBE_ENDPOINT'","publicKey":"'\$PUB_KEY'","sessionToken":"'\$SESSION_TOKEN'"}' || echo "000")
  if [[ "\$HTTP" == "200" || "\$HTTP" == "201" ]]; then
    REG_OK=1; break
  fi
  echo "  Attempt \$attempt failed (HTTP \$HTTP) — retrying in 3s..."
  sleep 3
done
[[ "\$REG_OK" == "1" ]] || { echo "  ✗ CRS registration failed after 3 attempts."; exit 1; }
echo "  ✓ Registered with YODA CRS"

# ── 8. Download GGUF model ───────────────────────────────────────────
echo ""
echo "Downloading model: \$GGUF_FILE"
echo "  Source : https://huggingface.co/\$GGUF_REPO"
echo "  Dest   : \$MODEL_PATH"
mkdir -p "\$MODELS_DIR"
if [[ -f "\$MODEL_PATH" && -s "\$MODEL_PATH" ]]; then
  echo "  → Already downloaded (\$(du -sh "\$MODEL_PATH" | cut -f1)), skipping"
else
  echo "  (This may be several GB — download resumes automatically if interrupted)"
  # -C - resumes an interrupted download; exits 0 if already complete
  curl -fL --progress-bar -C - \\
    "https://huggingface.co/\${GGUF_REPO}/resolve/main/\${GGUF_FILE}" \\
    -o "\$MODEL_PATH" || {
      echo "  ✗ Download failed."
      [[ -f "\$MODEL_PATH" && ! -s "\$MODEL_PATH" ]] && rm -f "\$MODEL_PATH"
      exit 1
    }
fi
[[ -s "\$MODEL_PATH" ]] || { echo "  ✗ Model file is empty after download."; exit 1; }
echo "  ✓ Model ready (\$(du -sh "\$MODEL_PATH" | cut -f1))"

# ── 9. Start llama-server ─────────────────────────────────────────────
echo ""
echo "Starting llama-server on port \$SERVER_PORT..."
pkill -f "llama-server.*\$SERVER_PORT" 2>/dev/null || true
sleep 1
nohup "\$LLAMA_SERVER" \\
  --model "\$MODEL_PATH" \\
  --port "\$SERVER_PORT" \\
  --host 0.0.0.0 \\
  -c 4096 \\
  --parallel 4 \\
  -ngl 99 \\
  --log-disable \\
  >> "\$LOG_DIR/llama-server-\${SERVER_PORT}.log" 2>&1 &
SERVER_PID=\$!
echo "  ✓ llama-server started (PID \$SERVER_PID) — log: \$LOG_DIR/llama-server-\${SERVER_PORT}.log"
sleep 2

# ── 10. Start PlenumNET tunnel daemon ─────────────────────────────────
echo ""
echo "Starting PlenumNET tunnel daemon..."
pkill -f "inter-cube-daemon" 2>/dev/null || true
sleep 1
export CUBE_MODE=cube
export CUBE_API_PORT=$((SERVER_PORT - 1))
export CUBE_CRS_URL="\$CRS_URL"
export CUBE_ENDPOINT="\$CUBE_ENDPOINT"
export CUBE_SESSION_TOKEN="\$SESSION_TOKEN"
export CUBE_ROLE=inference
nohup "\$DAEMON" >> "\$LOG_DIR/intercube.log" 2>&1 &
DAEMON_PID=\$!
echo "  ✓ Daemon started (PID \$DAEMON_PID) — log: \$LOG_DIR/intercube.log"

echo ""
echo "=============================="
echo "  Setup complete!"
echo "  Model  : ${modelName}"
echo "  Server : http://localhost:\$SERVER_PORT  (OpenAI-compatible)"
echo "  Tunnel : \$CUBE_ENDPOINT → YODA CRS"
echo "=============================="
echo ""
echo "Both processes run in the background — they survive terminal close."
echo "Logs : \$LOG_DIR/"
echo "Use the [Sync Node] button in YODA Settings to reconnect after reboot."
`;
}

export function makePsInstallScript(
  modelName : string,
  ggufRepo  : string,
  ggufFile  : string,
  port      : number,
  token     : string,
  crsUrl    : string,
): string {
  return `# YODA Self-Host Installer (Windows)
# Model: ${modelName}  |  Port: ${port}  |  Token: ${token}
$ErrorActionPreference = "Stop"
trap {
  Write-Host ""
  Write-Host "=== INSTALLER ERROR ===" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host ""
  Read-Host "Press Enter to close"
  break
}

$SESSION_TOKEN = "${token}"
$CRS_URL       = "${crsUrl}"
$GGUF_REPO     = "${ggufRepo}"
$GGUF_FILE     = "${ggufFile}"
$SERVER_PORT   = ${port}
$MODELS_DIR    = Join-Path $env:USERPROFILE "yoda-models"
$MODEL_PATH    = Join-Path $MODELS_DIR $GGUF_FILE
$LOG_DIR       = Join-Path $MODELS_DIR "logs"
$LLAMA_DIR     = Join-Path $env:USERPROFILE "llama.cpp"
$PLENUMNET_DIR = Join-Path $env:USERPROFILE "PlenumNET"
$IDENTITY_DIR  = Join-Path (Join-Path $env:USERPROFILE ".plenumnet") "identity"

Write-Host "=== YODA Self-Host Installer ===" -ForegroundColor Cyan
Write-Host "Model  : ${modelName}"
Write-Host "Port   : $SERVER_PORT"
Write-Host ""

# -- 1. Detect local IP ---------------------------------------------------
$ip = (Get-NetIPAddress -AddressFamily IPv4 |
  Where-Object { $_.IPAddress -notmatch '^127\\.' -and $_.IPAddress -notmatch '^169\\.254' -and $_.PrefixOrigin -ne 'WellKnown' } |
  Sort-Object @{ Expression = { switch -Wildcard ($_.InterfaceAlias) { 'Wi-Fi*' { 0 } 'Ethernet*' { 1 } default { 2 } } } } |
  Select-Object -First 1).IPAddress
if (-not $ip) { $ip = "0.0.0.0" }
$CUBE_ENDPOINT = "$ip\`:51820"
Write-Host "Local endpoint : $CUBE_ENDPOINT"
if ($ip -eq "0.0.0.0") {
  Write-Host "  WARN Could not detect local IP -- routing may fail." -ForegroundColor Yellow
}

# -- 2. Check / install Rust ----------------------------------------------
Write-Host ""
Write-Host "Checking Rust/Cargo..."
if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) {
  Write-Host "  -> Rust not found -- installing rustup..."
  $rustupExe = Join-Path $env:TEMP "rustup-init.exe"
  Invoke-WebRequest -Uri "https://win.rustup.rs/x86_64" -OutFile $rustupExe -UseBasicParsing
  Start-Process -FilePath $rustupExe -ArgumentList "-y" -Wait -NoNewWindow
  Remove-Item $rustupExe -Force -ErrorAction SilentlyContinue
  $cargoBin = Join-Path (Join-Path $env:USERPROFILE ".cargo") "bin"
  $env:PATH += ";$cargoBin"
  Write-Host "  OK Rust installed"
} else {
  Write-Host "  OK Cargo already installed: $(cargo --version 2>$null)"
}
if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) {
  throw "cargo not found after install -- restart this script in a new terminal so PATH is refreshed."
}

# -- 3. Check Git ---------------------------------------------------------
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  throw "Git is not installed. Install it from https://git-scm.com/download/win then re-run this installer."
}

# -- 3b. Activate MSVC environment + ensure clang is available -----------
# The ring crate on aarch64-pc-windows-msvc needs BOTH:
#   1. VCINSTALLDIR set (from vcvarsarm64.bat) for the MSVC linker
#   2. clang.exe on PATH for ARM64 assembly compilation
Write-Host ""
Write-Host "Setting up build environment for the ring crypto crate..."
$cpuArch = $env:PROCESSOR_ARCHITECTURE
Write-Host "  -> Architecture: $cpuArch"

# Step A -- find and activate MSVC via vswhere (sets VCINSTALLDIR etc.)
$vswhereX86 = "C:\\Program Files (x86)\\Microsoft Visual Studio\\Installer\\vswhere.exe"
$vswhereNat = "C:\\Program Files\\Microsoft Visual Studio\\Installer\\vswhere.exe"
$vswhere = if (Test-Path -LiteralPath $vswhereX86) { $vswhereX86 } elseif (Test-Path -LiteralPath $vswhereNat) { $vswhereNat } else { "" }
if ($vswhere) {
  $vsInstallPath = (& $vswhere -latest -products * -property installationPath 2>$null) |
                    Where-Object { $_ -ne '' } | Select-Object -First 1
  if ($vsInstallPath) { $vsInstallPath = $vsInstallPath.Trim() }
  if ($vsInstallPath) {
    $vcvarsName = if ($cpuArch -eq "ARM64") { "vcvarsarm64.bat" } else { "vcvars64.bat" }
    $vcvars = Join-Path (Join-Path $vsInstallPath "VC\Auxiliary\Build") $vcvarsName
    if (Test-Path -LiteralPath $vcvars) {
      Write-Host "  -> Activating MSVC environment ($vcvarsName)..."
      $envLines = cmd.exe /c ('"' + $vcvars + '" > nul 2>&1 && set')
      foreach ($line in $envLines) {
        if ($line -match '^([^=\r\n]+)=(.*)$') {
          [System.Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], "Process")
        }
      }
      Write-Host "  OK MSVC environment activated (VCINSTALLDIR = $env:VCINSTALLDIR)"
    } else {
      Write-Host "  WARN $vcvarsName not found in $vsInstallPath -- MSVC ARM64 tools may not be installed." -ForegroundColor Yellow
    }
  } else {
    Write-Host "  WARN No VS installation found via vswhere." -ForegroundColor Yellow
  }
} else {
  Write-Host "  WARN vswhere.exe not found -- cannot activate MSVC environment." -ForegroundColor Yellow
}

# Step B -- ensure clang is on PATH (ring needs it for ARM64 assembly)
$hasClang = Get-Command clang -ErrorAction SilentlyContinue
if (-not $hasClang) {
  $llvmBin = "C:\\Program Files\\LLVM\\bin"
  if (Test-Path -LiteralPath (Join-Path $llvmBin "clang.exe")) {
    $env:PATH += ";$llvmBin"
    $hasClang = Get-Command clang -ErrorAction SilentlyContinue
  }
}
if ($hasClang) {
  Write-Host "  OK clang: $($hasClang.Source)"
} else {
  Write-Host "  -> clang not found -- installing LLVM via winget (~300 MB)..." -ForegroundColor Yellow
  $hasWinget = Get-Command winget -ErrorAction SilentlyContinue
  if ($hasWinget) {
    winget install --id LLVM.LLVM --silent --accept-package-agreements --accept-source-agreements
  } else {
    Write-Host "  -> winget not available -- downloading LLVM installer directly..."
    $llvmRelease = (Invoke-RestMethod "https://api.github.com/repos/llvm/llvm-project/releases/latest").tag_name
    $llvmVer = $llvmRelease -replace "llvmorg-",""
    $llvmUrl = "https://github.com/llvm/llvm-project/releases/download/$llvmRelease/LLVM-$llvmVer-win64.exe"
    $llvmInstaller = Join-Path $env:TEMP "llvm-installer.exe"
    Write-Host "  -> Downloading LLVM $llvmVer..."
    if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
      curl.exe -fL "$llvmUrl" -o "$llvmInstaller"
    } else {
      Invoke-WebRequest -Uri $llvmUrl -OutFile $llvmInstaller -UseBasicParsing
    }
    Start-Process -FilePath $llvmInstaller -ArgumentList "/S" -Wait -NoNewWindow
    Remove-Item $llvmInstaller -Force -ErrorAction SilentlyContinue
  }
  $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH","User")
  $llvmBin = "C:\\Program Files\\LLVM\\bin"
  if (Test-Path -LiteralPath (Join-Path $llvmBin "clang.exe")) { $env:PATH += ";$llvmBin" }
  if (Get-Command clang -ErrorAction SilentlyContinue) {
    Write-Host "  OK clang installed"
  } else {
    throw "clang not found after LLVM install -- please restart this script in a new terminal."
  }
}

# -- 4. Clone/update PlenumNET and build daemon ----------------------------
Write-Host ""
Write-Host "Installing PlenumNET (inter-cube)..."
New-Item -ItemType Directory -Force -Path $LOG_DIR | Out-Null
function Invoke-ClonePlenumNET {
  Write-Host "  -> Cloning PlenumNET..."
  git clone --depth 1 https://github.com/SigmaWolf-8/Ternary $PLENUMNET_DIR
}
if (Test-Path (Join-Path $PLENUMNET_DIR ".git")) {
  Write-Host "  -> Repository exists, updating..."
  try {
    $pullOutput = git -C $PLENUMNET_DIR pull --ff-only 2>&1
    Write-Host "  -> $pullOutput"
  } catch {
    Write-Host "  -> git pull failed (network issue?) -- continuing with existing checkout" -ForegroundColor Yellow
  }
  $icToml = Join-Path (Join-Path (Join-Path $PLENUMNET_DIR "services") "inter-cube") "Cargo.toml"
  if (-not (Test-Path $icToml)) {
    Write-Host "  -> Existing checkout is incomplete -- re-cloning..."
    Remove-Item -Recurse -Force $PLENUMNET_DIR
    Invoke-ClonePlenumNET
  }
} else {
  Invoke-ClonePlenumNET
}
foreach ($member in @((Join-Path (Join-Path "services" "inter-cube") "Cargo.toml"), (Join-Path "ternary-math" "Cargo.toml"))) {
  $full = Join-Path $PLENUMNET_DIR $member
  if (-not (Test-Path $full)) {
    throw "$member missing after clone -- check network and try again."
  }
}
Write-Host "  -> Building inter-cube daemon (first build takes a few minutes)..."
Write-Host "  Cargo warnings are normal -- only errors matter." -ForegroundColor Gray
Push-Location $PLENUMNET_DIR
$ErrorActionPreference = "Continue"
cargo build --release --package inter-cube 2>&1 | ForEach-Object { Write-Host $_ }
$cargoBuildExit = $LASTEXITCODE
$ErrorActionPreference = "Stop"
Pop-Location
if ($cargoBuildExit -ne 0) {
  throw "cargo build failed with exit code $cargoBuildExit -- check the output above for errors."
}
$relDir = Join-Path (Join-Path $PLENUMNET_DIR "target") "release"
$daemonBin = Get-ChildItem -Path $relDir -Filter "inter-cube*.exe" -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -notlike "*.d" } | Select-Object -First 1
if (-not $daemonBin) {
  throw "Build completed but no inter-cube binary found in $relDir -- check cargo output above for errors."
}
$DAEMON_PATH = $daemonBin.FullName
Write-Host "  OK Daemon built: $DAEMON_PATH"

# -- 5. Identity passphrase + PT26-DSA keygen -----------------------------
Write-Host ""
Write-Host "Setting up PlenumNET identity..."
New-Item -ItemType Directory -Force -Path $IDENTITY_DIR | Out-Null
$PASSPHRASE_FILE = Join-Path $IDENTITY_DIR ".passphrase"

if (Test-Path $PASSPHRASE_FILE) {
  $CUBE_PASSPHRASE = (Get-Content $PASSPHRASE_FILE -Raw).Trim()
  Write-Host "  -> Loaded existing identity passphrase"
} else {
  $rng   = [System.Security.Cryptography.RNGCryptoServiceProvider]::new()
  $bytes = [byte[]]::new(24)
  $rng.GetBytes($bytes)
  $CUBE_PASSPHRASE = ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
  $rng.Dispose()
  $CUBE_PASSPHRASE | Set-Content -Path $PASSPHRASE_FILE -NoNewline
  $acl = Get-Acl $PASSPHRASE_FILE
  $acl.SetAccessRuleProtection($true, $false)
  $userRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,
    "FullControl", "Allow"
  )
  $acl.SetAccessRule($userRule)
  Set-Acl $PASSPHRASE_FILE $acl
  Write-Host "  OK Generated and saved identity passphrase"
}
$env:CUBE_IDENTITY_PASSPHRASE = $CUBE_PASSPHRASE

Write-Host "  -> Generating PT26-DSA identity keypair..."
$env:CUBE_MODE = "keygen"
$keygenLog = Join-Path $LOG_DIR "keygen.log"
$ErrorActionPreference = "Continue"
cmd.exe /c ('"' + $DAEMON_PATH + '" > "' + $keygenLog + '" 2>&1')
$ErrorActionPreference = "Stop"
$env:CUBE_MODE = $null
$keygenOutput = if (Test-Path $keygenLog) { Get-Content $keygenLog } else { @() }
$PUB_KEY = ""
foreach ($line in $keygenOutput) {
  if ($line -match '([0-9a-fA-F]{32,})') {
    $PUB_KEY = $matches[1]
    break
  }
}
if (-not $PUB_KEY) {
  Write-Host "  Keygen output:" -ForegroundColor Yellow
  $keygenOutput | ForEach-Object { Write-Host "    $_" }
  throw "Daemon keygen produced no public key -- check $keygenLog for details."
}
Write-Host "  OK Public key: $($PUB_KEY.Substring(0, [Math]::Min(32, $PUB_KEY.Length)))..."

# -- 6. Install llama.cpp -------------------------------------------------
Write-Host ""
Write-Host "Installing llama.cpp..."
$llamaServer = Get-ChildItem -Path $LLAMA_DIR -Recurse -Filter "llama-server.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($llamaServer) {
  $ErrorActionPreference = "Continue"
  & $llamaServer.FullName --version 2>$null | Out-Null
  $llamaExitCode = $LASTEXITCODE
  $ErrorActionPreference = "Stop"
  if ($llamaExitCode -lt 0 -or $llamaExitCode -gt 200) {
    Write-Host "  WARN Existing llama-server.exe failed (exit $llamaExitCode -- likely wrong CPU arch) -- re-downloading..."
    Remove-Item -Path $LLAMA_DIR -Recurse -Force -ErrorAction SilentlyContinue
    $llamaServer = $null
  } else {
    Write-Host "  OK llama-server.exe: $($llamaServer.FullName)"
  }
}
if (-not $llamaServer) {
  New-Item -ItemType Directory -Force -Path $LLAMA_DIR | Out-Null
  $release = (Invoke-RestMethod "https://api.github.com/repos/ggerganov/llama.cpp/releases/latest").tag_name
  if ($cpuArch -eq "ARM64") {
    $zipName = "llama-$release-bin-win-arm64.zip"
    $zipUrl  = "https://github.com/ggerganov/llama.cpp/releases/download/$release/$zipName"
    Write-Host "  -> ARM64 detected -- checking for native build..."
    try {
      Invoke-WebRequest -Uri $zipUrl -Method Head -UseBasicParsing -ErrorAction Stop | Out-Null
      Write-Host "  -> Using ARM64 native llama.cpp build"
    } catch {
      $zipName = "llama-$release-bin-win-noavx-x64.zip"
      $zipUrl  = "https://github.com/ggerganov/llama.cpp/releases/download/$release/$zipName"
      Write-Host "  -> ARM64 native not available, falling back to noavx-x64 (runs under emulation)"
    }
  } else {
    $zipUrl = "https://github.com/ggerganov/llama.cpp/releases/download/$release/llama-$release-bin-win-avx2-x64.zip"
  }
  Write-Host "  -> Downloading llama.cpp $release..."
  $zipPath = Join-Path $env:TEMP "llamacpp.zip"
  if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
    curl.exe -fL "$zipUrl" -o "$zipPath"
  } else {
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing
  }
  Expand-Archive -Path $zipPath -DestinationPath $LLAMA_DIR -Force
  Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
  $llamaServer = Get-ChildItem -Path $LLAMA_DIR -Recurse -Filter "llama-server.exe" | Select-Object -First 1
  if (-not $llamaServer) { throw "llama-server.exe not found after extraction." }
}
$LLAMA_SERVER = $llamaServer.FullName

# -- 7. Register with YODA CRS (with retry) -------------------------------
Write-Host ""
Write-Host "Registering with YODA CRS..."
$regBody = ConvertTo-Json @{ endpoint = $CUBE_ENDPOINT; publicKey = $PUB_KEY; sessionToken = $SESSION_TOKEN }
$regOk = $false
for ($attempt = 1; $attempt -le 3; $attempt++) {
  try {
    Invoke-RestMethod -Uri "$CRS_URL/api/salvi/inter-cube/crs/register" -Method Post -ContentType "application/json" -Body $regBody | Out-Null
    $regOk = $true; break
  } catch {
    Write-Host "  Attempt $attempt failed: $_ -- retrying in 3s..."
    Start-Sleep -Seconds 3
  }
}
if (-not $regOk) { throw "CRS registration failed after 3 attempts -- check your internet connection and that the YODA server is reachable." }
Write-Host "  OK Registered with YODA CRS"

# -- 8. Download GGUF model -----------------------------------------------
Write-Host ""
Write-Host "Downloading model: $GGUF_FILE"
Write-Host "  Source : https://huggingface.co/$GGUF_REPO"
Write-Host "  Dest   : $MODEL_PATH"
New-Item -ItemType Directory -Force -Path $MODELS_DIR | Out-Null
if ((Test-Path $MODEL_PATH) -and (Get-Item $MODEL_PATH).Length -gt 0) {
  $sz = [math]::Round((Get-Item $MODEL_PATH).Length / 1GB, 2)
  Write-Host "  OK Already downloaded ($sz GB), skipping"
} else {
  Write-Host "  (This may be several GB -- download resumes if interrupted)"
  $modelUrl = "https://huggingface.co/$GGUF_REPO/resolve/main/$GGUF_FILE"
  if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
    curl.exe -fL -C - --progress-bar "$modelUrl" -o "$MODEL_PATH"
  } else {
    try {
      Start-BitsTransfer -Source $modelUrl -Destination $MODEL_PATH -Priority Normal
    } catch {
      Write-Host "  -> BITS unavailable, falling back to direct download..."
      $wc = New-Object System.Net.WebClient
      $wc.DownloadFile($modelUrl, $MODEL_PATH)
    }
  }
}
if (-not (Test-Path $MODEL_PATH) -or (Get-Item $MODEL_PATH).Length -eq 0) {
  throw "Model file missing or empty after download -- check your internet connection and disk space."
}
$modelSz = [math]::Round((Get-Item $MODEL_PATH).Length / 1GB, 2)
Write-Host "  OK Model ready ($modelSz GB)"

# -- 9. Start llama-server ------------------------------------------------
Write-Host ""
Write-Host "Starting llama-server on port $SERVER_PORT..."
Get-Process -Name "llama-server" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 800
$nglArgs      = if ($cpuArch -eq "ARM64") { "" } else { "-ngl 99" }
$ctxSize      = if ($cpuArch -eq "ARM64") { "2048" } else { "4096" }
$parallelCount= if ($cpuArch -eq "ARM64") { "1"    } else { "2" }
$serverProc = Start-Process -FilePath $LLAMA_SERVER -ArgumentList "--model \`"$MODEL_PATH\`" --port $SERVER_PORT --host 0.0.0.0 -c $ctxSize --parallel $parallelCount $nglArgs --log-disable" -WindowStyle Hidden -PassThru
Write-Host "  OK llama-server started (PID $($serverProc.Id))"
Start-Sleep -Seconds 2

# -- 10. Start PlenumNET tunnel daemon ------------------------------------
Write-Host ""
Write-Host "Starting PlenumNET tunnel daemon..."
Get-Process | Where-Object { $_.Name -like "inter-cube*" } | Stop-Process -Force -ErrorAction SilentlyContinue
$daemonPort = $SERVER_PORT - 1
$portOwner = (Get-NetTCPConnection -LocalPort $daemonPort -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty OwningProcess)
if ($portOwner) { Stop-Process -Id $portOwner -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 800
$env:CUBE_MODE          = "cube"
$env:CUBE_API_PORT      = $daemonPort
$env:CUBE_CRS_URL       = $CRS_URL
$env:CUBE_ENDPOINT      = $CUBE_ENDPOINT
$env:CUBE_SESSION_TOKEN = $SESSION_TOKEN
$env:CUBE_ROLE          = "inference"
$daemonProc = Start-Process -FilePath $DAEMON_PATH -WindowStyle Hidden -PassThru
Write-Host "  OK Daemon started (PID $($daemonProc.Id))"

Write-Host ""
Write-Host "==============================" -ForegroundColor Green
Write-Host "  Setup complete!" -ForegroundColor Green
Write-Host "  Model  : ${modelName}" -ForegroundColor Green
Write-Host "  Server : http://localhost:$SERVER_PORT  (OpenAI-compatible)" -ForegroundColor Green
Write-Host "  Tunnel : $CUBE_ENDPOINT -> YODA CRS" -ForegroundColor Green
Write-Host "==============================" -ForegroundColor Green
Write-Host ""
Write-Host "Both processes run in the background." -ForegroundColor Yellow
Write-Host "Logs: $LOG_DIR" -ForegroundColor Yellow
Write-Host "Use the [Sync Node] button in YODA Settings to reconnect after reboot."
`;
}

// ── Step-1 installer: PlenumNET tunnel only (no model download) ───────────────
// Downloads / builds inter-cube daemon, registers with CRS, starts tunnel.
// The YODA UI polls CRS and advances to "Step 2" when registration lands.

export function makePsStep1Script(
  modelName : string,
  port      : number,
  token     : string,
  crsUrl    : string,
): string {
  return `# YODA Step 1 -- Network Tunnel Setup
# Model: ${modelName}  |  Port: ${port}
# This script installs PlenumNET and establishes the secure tunnel to YODA.
# Step 2 (model download) runs separately once the tunnel is confirmed.
$ErrorActionPreference = "Stop"
trap {
  Write-Host ""
  Write-Host "=== STEP 1 ERROR ===" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host ""
  Read-Host "Press Enter to close"
  break
}

$SESSION_TOKEN = "${token}"
$CRS_URL       = "${crsUrl}"
$LOG_DIR       = Join-Path $env:USERPROFILE "yoda-models\\logs"
$LLAMA_DIR     = Join-Path $env:USERPROFILE "llama.cpp"
$PLENUMNET_DIR = Join-Path $env:USERPROFILE "PlenumNET"
$IDENTITY_DIR  = Join-Path (Join-Path $env:USERPROFILE ".plenumnet") "identity"

New-Item -ItemType Directory -Force -Path $LOG_DIR | Out-Null

Write-Host "=== YODA -- Step 1: Network Tunnel Setup ===" -ForegroundColor Cyan
Write-Host "Model  : ${modelName}"
Write-Host "Port   : ${port}"
Write-Host ""

# -- 1. Detect local IP ---------------------------------------------------
$ip = (Get-NetIPAddress -AddressFamily IPv4 |
  Where-Object { $_.IPAddress -notmatch '^127\\.' -and $_.IPAddress -notmatch '^169\\.254' -and $_.PrefixOrigin -ne 'WellKnown' } |
  Sort-Object @{ Expression = { switch -Wildcard ($_.InterfaceAlias) { 'Wi-Fi*' { 0 } 'Ethernet*' { 1 } default { 2 } } } } |
  Select-Object -First 1).IPAddress
if (-not $ip) { $ip = "0.0.0.0" }
$CUBE_ENDPOINT = "$ip\`:51820"
Write-Host "Local endpoint : $CUBE_ENDPOINT"

# -- 2. Check / install Rust ----------------------------------------------
Write-Host ""
Write-Host "Checking Rust/Cargo..."
if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) {
  Write-Host "  -> Rust not found -- installing rustup..."
  $rustupExe = Join-Path $env:TEMP "rustup-init.exe"
  Invoke-WebRequest -Uri "https://win.rustup.rs/x86_64" -OutFile $rustupExe -UseBasicParsing
  Start-Process -FilePath $rustupExe -ArgumentList "-y" -Wait -NoNewWindow
  Remove-Item $rustupExe -Force -ErrorAction SilentlyContinue
  $cargoBin = Join-Path (Join-Path $env:USERPROFILE ".cargo") "bin"
  $env:PATH += ";$cargoBin"
  Write-Host "  OK Rust installed"
} else {
  Write-Host "  OK Cargo: $(cargo --version 2>$null)"
}
if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) {
  throw "cargo not found after install -- restart this script in a new terminal so PATH is refreshed."
}

# -- 3. Check Git ---------------------------------------------------------
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  throw "Git is not installed. Install from https://git-scm.com/download/win then re-run."
}

# -- 4. MSVC + clang for ARM64 ring crate ---------------------------------
Write-Host ""
Write-Host "Setting up ARM64 build environment..."
$cpuArch = $env:PROCESSOR_ARCHITECTURE
$vswhereX86 = "C:\\Program Files (x86)\\Microsoft Visual Studio\\Installer\\vswhere.exe"
$vswhereNat = "C:\\Program Files\\Microsoft Visual Studio\\Installer\\vswhere.exe"
$vswhere = if (Test-Path -LiteralPath $vswhereX86) { $vswhereX86 } elseif (Test-Path -LiteralPath $vswhereNat) { $vswhereNat } else { "" }
if ($vswhere) {
  $vsInstallPath = & $vswhere -latest -products * -property installationPath 2>$null
  if ($vsInstallPath) {
    $vcvarsName = if ($cpuArch -eq "ARM64") { "vcvarsarm64.bat" } else { "vcvars64.bat" }
    $vcvars = Join-Path (Join-Path (Join-Path $vsInstallPath "VC") "Auxiliary\\Build") $vcvarsName
    if (Test-Path -LiteralPath $vcvars) {
      $envLines = cmd.exe /c ('"' + $vcvars + '" > nul 2>&1 && set')
      foreach ($line in $envLines) {
        if ($line -match '^([^=\\r\\n]+)=(.*)$') { [System.Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], "Process") }
      }
      Write-Host "  OK MSVC environment activated"
    }
  }
}
$hasClang = Get-Command clang -ErrorAction SilentlyContinue
if (-not $hasClang) {
  $llvmBin = "C:\\Program Files\\LLVM\\bin"
  if (Test-Path -LiteralPath (Join-Path $llvmBin "clang.exe")) { $env:PATH += ";$llvmBin"; $hasClang = $true }
}
if (-not $hasClang) {
  Write-Host "  -> clang not found -- installing LLVM via winget..."
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    winget install --id LLVM.LLVM --silent --accept-package-agreements --accept-source-agreements
  }
  $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH","User")
  $llvmBin2 = "C:\\Program Files\\LLVM\\bin"
  if (Test-Path -LiteralPath (Join-Path $llvmBin2 "clang.exe")) { $env:PATH += ";$llvmBin2" }
  if (-not (Get-Command clang -ErrorAction SilentlyContinue)) {
    throw "clang not found after LLVM install -- restart this script in a new terminal."
  }
}
Write-Host "  OK clang available"

# -- 5. Clone/update PlenumNET and build inter-cube daemon ----------------
Write-Host ""
Write-Host "Building PlenumNET inter-cube daemon..."
function Invoke-ClonePlenumNET {
  git clone --depth 1 https://github.com/SigmaWolf-8/Ternary $PLENUMNET_DIR
}
if (Test-Path (Join-Path $PLENUMNET_DIR ".git")) {
  try { git -C $PLENUMNET_DIR pull --ff-only 2>&1 | Out-Null } catch { }
  $icToml = Join-Path (Join-Path (Join-Path $PLENUMNET_DIR "services") "inter-cube") "Cargo.toml"
  if (-not (Test-Path $icToml)) { Remove-Item -Recurse -Force $PLENUMNET_DIR; Invoke-ClonePlenumNET }
} else {
  Invoke-ClonePlenumNET
}
Write-Host "  -> Building (first build: 5-10 min, Cargo warnings are normal)..."
Push-Location $PLENUMNET_DIR
$ErrorActionPreference = "Continue"
cargo build --release --package inter-cube 2>&1 | ForEach-Object { Write-Host $_ }
$buildExit = $LASTEXITCODE
$ErrorActionPreference = "Stop"
Pop-Location
if ($buildExit -ne 0) { throw "cargo build failed -- see output above." }
$relDir    = Join-Path (Join-Path $PLENUMNET_DIR "target") "release"
$daemonBin = Get-ChildItem -Path $relDir -Filter "inter-cube*.exe" -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -notlike "*.d" } | Select-Object -First 1
if (-not $daemonBin) { throw "inter-cube.exe not found after build." }
$DAEMON_PATH = $daemonBin.FullName
Write-Host "  OK Daemon: $DAEMON_PATH"

# -- 6. Identity keypair --------------------------------------------------
Write-Host ""
Write-Host "Setting up PlenumNET identity..."
New-Item -ItemType Directory -Force -Path $IDENTITY_DIR | Out-Null
$PASSPHRASE_FILE = Join-Path $IDENTITY_DIR ".passphrase"
if (Test-Path $PASSPHRASE_FILE) {
  $CUBE_PASSPHRASE = (Get-Content $PASSPHRASE_FILE -Raw).Trim()
  Write-Host "  -> Loaded existing passphrase"
} else {
  $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::new()
  $bytes = [byte[]]::new(24)
  $rng.GetBytes($bytes)
  $CUBE_PASSPHRASE = ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
  $rng.Dispose()
  $CUBE_PASSPHRASE | Set-Content -Path $PASSPHRASE_FILE -NoNewline
  Write-Host "  OK Passphrase saved"
}
$env:CUBE_IDENTITY_PASSPHRASE = $CUBE_PASSPHRASE
$env:CUBE_MODE = "keygen"
$keygenLog = Join-Path $LOG_DIR "keygen.log"
$ErrorActionPreference = "Continue"
$keygenOutput = & $DAEMON_PATH 2>$keygenLog
$ErrorActionPreference = "Stop"
$env:CUBE_MODE = $null
$pkLine = $keygenOutput | Where-Object { $_ -match "PT26-DSA Public Key" } | Select-Object -First 1
if ($pkLine -match ':\\s*([0-9a-fA-F]+)\\s*$') { $PUB_KEY = $matches[1] } else { $PUB_KEY = "" }
if (-not $PUB_KEY) { throw "Keygen produced no public key -- see $keygenLog" }
Write-Host "  OK Key: $($PUB_KEY.Substring(0, [Math]::Min(32, $PUB_KEY.Length)))..."

# -- 7. Download llama-server.exe (needed for Step 2) --------------------
Write-Host ""
Write-Host "Downloading llama-server.exe (pre-built)..."
$llamaServer = Get-ChildItem -Path $LLAMA_DIR -Recurse -Filter "llama-server.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($llamaServer) {
  Write-Host "  OK Already present: $($llamaServer.FullName)"
} else {
  New-Item -ItemType Directory -Force -Path $LLAMA_DIR | Out-Null
  $release = (Invoke-RestMethod "https://api.github.com/repos/ggerganov/llama.cpp/releases/latest").tag_name
  $arch    = $env:PROCESSOR_ARCHITECTURE
  $suffix  = if ($arch -eq "ARM64") { "arm64" } else { "avx2-x64" }
  $zipUrl  = "https://github.com/ggerganov/llama.cpp/releases/download/$release/llama-$release-bin-win-$suffix.zip"
  Write-Host "  -> Downloading $zipUrl..."
  $zipPath = Join-Path $env:TEMP "llamacpp.zip"
  if (Get-Command curl.exe -ErrorAction SilentlyContinue) { curl.exe -fL "$zipUrl" -o "$zipPath" }
  else { Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing }
  Expand-Archive -Path $zipPath -DestinationPath $LLAMA_DIR -Force
  Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
  $llamaServer = Get-ChildItem -Path $LLAMA_DIR -Recurse -Filter "llama-server.exe" | Select-Object -First 1
  if (-not $llamaServer) { throw "llama-server.exe not found after extraction." }
  Write-Host "  OK llama-server.exe: $($llamaServer.FullName)"
}

# -- 8. Register with YODA CRS (triggers UI to advance to Step 2) --------
Write-Host ""
Write-Host "Registering with YODA CRS..."
$regBody = ConvertTo-Json @{ endpoint = $CUBE_ENDPOINT; publicKey = $PUB_KEY; sessionToken = $SESSION_TOKEN }
$regOk = $false
for ($attempt = 1; $attempt -le 3; $attempt++) {
  try {
    Invoke-RestMethod -Uri "$CRS_URL/api/yoda/crs/session/register" -Method Post -ContentType "application/json" -Body $regBody | Out-Null
    $regOk = $true; break
  } catch {
    Write-Host "  Attempt $attempt failed: $_ -- retrying in 3s..."
    Start-Sleep -Seconds 3
  }
}
if (-not $regOk) { throw "CRS registration failed -- check internet and that YODA is reachable." }
Write-Host "  OK Registered with YODA CRS -- tunnel session: $SESSION_TOKEN"

# -- 9. Start PlenumNET tunnel daemon -------------------------------------
Write-Host ""
Write-Host "Starting PlenumNET tunnel daemon..."
Get-Process | Where-Object { $_.Name -like "inter-cube*" } | Stop-Process -Force -ErrorAction SilentlyContinue
$daemonPort = $SERVER_PORT - 1
$portOwner = (Get-NetTCPConnection -LocalPort $daemonPort -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty OwningProcess)
if ($portOwner) { Stop-Process -Id $portOwner -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 800
$env:CUBE_MODE          = "cube"
$env:CUBE_API_PORT      = $daemonPort
$env:CUBE_CRS_URL       = $CRS_URL
$env:CUBE_ENDPOINT      = $CUBE_ENDPOINT
$env:CUBE_SESSION_TOKEN = $SESSION_TOKEN
$env:CUBE_ROLE          = "inference"
$daemonOutLog = Join-Path $LOG_DIR "intercube-out.log"
$daemonErrLog = Join-Path $LOG_DIR "intercube-err.log"
$daemonProc = Start-Process -FilePath $DAEMON_PATH -NoNewWindow -PassThru -RedirectStandardOutput $daemonOutLog -RedirectStandardError $daemonErrLog
Write-Host "  OK Tunnel daemon PID $($daemonProc.Id) -- log: $daemonOutLog"

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Step 1 Complete -- Tunnel Established" -ForegroundColor Green
Write-Host "  Return to YODA -- it will detect the" -ForegroundColor Green
Write-Host "  connection and prompt you for Step 2." -ForegroundColor Green
Write-Host "  (Step 2 downloads the AI model ~4-8 GB)" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Read-Host "Press Enter to close (tunnel keeps running)"
`;
}

// ── Step-2 installer: Model download + llama-server start ─────────────────────
// Assumes Step 1 ran and llama-server.exe is already in ~/llama.cpp.
// Downloads the GGUF and starts the inference server on the correct port.

export function makePsStep2Script(
  modelName : string,
  ggufRepo  : string,
  ggufFile  : string,
  port      : number,
  slot      : string = 'a',
  token     : string = '',
  yodaUrl   : string = '',
): string {
  return `# YODA Step 2 -- Model Installation
# Model: ${modelName}  |  Port: ${port}
# Downloads the AI model and starts the inference server.
$ErrorActionPreference = "Stop"
trap {
  Write-Host ""
  Write-Host "=== STEP 2 ERROR ===" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host ""
  Read-Host "Press Enter to close"
  break
}

$GGUF_REPO   = "${ggufRepo}"
$GGUF_FILE   = "${ggufFile}"
$SERVER_PORT = ${port}
$SLOT        = "${slot}"
$YODA_TOKEN  = "${token}"
$YODA_URL    = "${yodaUrl}"
$MODELS_DIR  = Join-Path $env:USERPROFILE "yoda-models"
$MODEL_PATH  = Join-Path $MODELS_DIR $GGUF_FILE
$LOG_DIR     = Join-Path $MODELS_DIR "logs"
$LLAMA_DIR   = Join-Path $env:USERPROFILE "llama.cpp"
$cpuArch     = $env:PROCESSOR_ARCHITECTURE

New-Item -ItemType Directory -Force -Path $MODELS_DIR | Out-Null
New-Item -ItemType Directory -Force -Path $LOG_DIR    | Out-Null

Write-Host "=== YODA -- Step 2: Model Setup ===" -ForegroundColor Cyan
Write-Host "Model : ${modelName}"
Write-Host "Port  : $SERVER_PORT"
Write-Host ""

# -- 1. Find llama-server.exe (Step 1 install dir, Downloads, or PATH) ----
function Find-LlamaServer {
  $hit = Get-ChildItem -Path $LLAMA_DIR -Recurse -Filter "llama-server.exe" -EA SilentlyContinue | Select-Object -First 1
  if ($hit) { return $hit.FullName }
  $dl = Join-Path $env:USERPROFILE "Downloads"
  $hit = Get-ChildItem -Path $dl -Recurse -Filter "llama-server.exe" -EA SilentlyContinue | Select-Object -First 1
  if ($hit) { return $hit.FullName }
  $cmd = Get-Command "llama-server" -EA SilentlyContinue
  if ($cmd) { return $cmd.Source }
  return $null
}
$LLAMA_SERVER = Find-LlamaServer
if (-not $LLAMA_SERVER) {
  throw "llama-server.exe not found in $LLAMA_DIR, Downloads, or PATH -- please run Step 1 first."
}
Write-Host "  OK llama-server: $LLAMA_SERVER"

# -- 2. Download GGUF model -----------------------------------------------
Write-Host ""
Write-Host "Downloading model: $GGUF_FILE"
if ((Test-Path $MODEL_PATH) -and (Get-Item $MODEL_PATH).Length -gt 100MB) {
  $sz = [math]::Round((Get-Item $MODEL_PATH).Length / 1GB, 2)
  Write-Host "  OK Already downloaded ($sz GB) -- skipping"
} else {
  $modelUrl = "https://huggingface.co/$GGUF_REPO/resolve/main/$GGUF_FILE"
  Write-Host "  Source : $modelUrl"
  Write-Host "  Dest   : $MODEL_PATH"
  Write-Host "  (This is 4-8 GB -- download resumes if interrupted)"
  if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
    curl.exe -fL -C - --progress-bar "$modelUrl" -o "$MODEL_PATH"
  } else {
    try {
      Start-BitsTransfer -Source $modelUrl -Destination $MODEL_PATH -Priority Normal
    } catch {
      Write-Host "  -> BITS unavailable, falling back to WebClient..."
      (New-Object System.Net.WebClient).DownloadFile($modelUrl, $MODEL_PATH)
    }
  }
}
if (-not (Test-Path $MODEL_PATH) -or (Get-Item $MODEL_PATH).Length -eq 0) {
  throw "Model file missing or empty -- check internet and disk space."
}
$modelSz = [math]::Round((Get-Item $MODEL_PATH).Length / 1GB, 2)
Write-Host "  OK Model ready ($modelSz GB)"

# -- 3. Kill any existing llama-server on this port -----------------------
$existing = Get-NetTCPConnection -LocalPort $SERVER_PORT -ErrorAction SilentlyContinue
if ($existing) {
  $pids = ($existing | Select-Object -ExpandProperty OwningProcess) | Sort-Object -Unique
  foreach ($p in $pids) { try { Stop-Process -Id $p -Force -ErrorAction SilentlyContinue } catch {} }
  Start-Sleep -Seconds 1
}

# -- 4. Start llama-server ------------------------------------------------
Write-Host ""
Write-Host "Starting llama-server on port $SERVER_PORT..."
$nglArgs = if ($cpuArch -eq "ARM64") { "" } else { "-ngl 99" }
Write-Host "  -> Architecture: $cpuArch  GPU offload: $(if ($nglArgs) { 'yes' } else { 'no (CPU only)' })"
$serverProc = Start-Process -FilePath $LLAMA_SERVER \`
  -ArgumentList "--model \`"$MODEL_PATH\`" --port $SERVER_PORT --host 0.0.0.0 -c 4096 --parallel 2 $nglArgs --log-disable" \`
  -WindowStyle Hidden -PassThru
Write-Host "  OK PID $($serverProc.Id)"
Write-Host ""
Write-Host "Waiting for model to finish loading (can take 1-3 min)..."
$maxWait  = 300
$waited   = 0
$ready    = $false
while ($waited -lt $maxWait) {
  if (-not (Get-Process -Id $serverProc.Id -ErrorAction SilentlyContinue)) {
    Write-Host ""
    Write-Host "  ERROR: llama-server process exited unexpectedly." -ForegroundColor Red
    Write-Host "  Check log for details: $serverOutLog" -ForegroundColor Red
    Write-Host ""
    Read-Host "Press Enter to close"
    exit 1
  }
  try {
    $r = Invoke-WebRequest -Uri "http://localhost:$SERVER_PORT/health" -TimeoutSec 3 -ErrorAction Stop -UseBasicParsing
    if ($r.StatusCode -lt 500) { $ready = $true; break }
  } catch { }
  Start-Sleep -Seconds 3
  $waited += 3
  Write-Host "  ...still loading ($waited s elapsed)"
}

Write-Host ""
if (-not $ready) {
  Write-Host "  WARN: Timed out after $maxWait s -- model may still be loading." -ForegroundColor Yellow
  Write-Host "  Check: $serverOutLog" -ForegroundColor Yellow
} else {
  Write-Host "  OK Model loaded and ready ($waited s)!" -ForegroundColor Green
}

# -- 5. Auto-mark engine online in YODA ------------------------------------
$marked = $false
if ($ready -and $YODA_TOKEN -ne "" -and $YODA_URL -ne "") {
  Write-Host ""
  Write-Host "Marking engine online in YODA..." -NoNewline
  try {
    $markUrl = "$YODA_URL/api/settings/engines/$SLOT/mark-online"
    $hdrs    = @{ Authorization = "Bearer $YODA_TOKEN"; "Content-Type" = "application/json" }
    $resp    = Invoke-WebRequest -Uri $markUrl -Method Post -Headers $hdrs -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop
    if ($resp.StatusCode -lt 300) {
      Write-Host " OK" -ForegroundColor Green
      $marked = $true
    } else {
      Write-Host " HTTP $($resp.StatusCode)" -ForegroundColor Yellow
    }
  } catch {
    Write-Host " failed ($_)" -ForegroundColor Yellow
  }
}

# -- 6. Register watchdog as Scheduled Task -----------------------------------
Write-Host ""
Write-Host "Registering watchdog (auto-restart on crash)..."
$watchdogScript = Join-Path $MODELS_DIR "watchdog-$SERVER_PORT.ps1"
$watchdogContent = @"
\$ErrorActionPreference = 'SilentlyContinue'
\$LLAMA_EXE  = '$($LLAMA_SERVER -replace "'","''")'
\$MODEL_PATH = '$($MODEL_PATH   -replace "'","''")'
\$PORT       = $SERVER_PORT
\$NGL        = '$nglArgs'
while (\$true) {
  Start-Sleep -Seconds 30
  if (-not (Get-NetTCPConnection -LocalPort \$PORT -State Listen -EA SilentlyContinue)) {
    Start-Process -FilePath \$LLAMA_EXE \`
      -ArgumentList "--model \`"\$MODEL_PATH\`" --port \$PORT --host 0.0.0.0 -c $ctxSize --parallel $parallelCount \$NGL --log-disable" \`
      -WindowStyle Hidden
  }
}
"@
Set-Content -Path $watchdogScript -Value $watchdogContent -Encoding UTF8
$taskName  = "YODA-Watchdog-$SERVER_PORT"
$action    = New-ScheduledTaskAction -Execute "powershell.exe" \`
               -Argument "-NonInteractive -WindowStyle Hidden -File \`"$watchdogScript\`""
$trigger1  = New-ScheduledTaskTrigger -AtLogOn
$trigger2  = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) \`
               -RepetitionInterval (New-TimeSpan -Minutes 5) \`
               -RepetitionDuration ([TimeSpan]::MaxValue)
$settings  = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit 0
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger @($trigger1,$trigger2) \`
  -Settings $settings -RunLevel Limited -Force | Out-Null
Start-ScheduledTask -TaskName $taskName -EA SilentlyContinue
Write-Host "  OK Watchdog registered as '$taskName' -- restarts every 5 min if crashed" -ForegroundColor Green

Write-Host ""
Write-Host "======================================" -ForegroundColor Green
Write-Host "  Step 2 Complete!" -ForegroundColor Green
if ($ready -and $marked) {
  Write-Host "  Model loaded. Engine marked ONLINE." -ForegroundColor Green
  Write-Host "  Return to YODA -- you are ready to run queries." -ForegroundColor Green
} elseif ($ready) {
  Write-Host "  Model loaded. Return to YODA and" -ForegroundColor Green
  Write-Host "  click [Sync Node] to confirm." -ForegroundColor Green
} else {
  Write-Host "  Server started but still warming up." -ForegroundColor Yellow
  Write-Host "  Check log: $serverOutLog" -ForegroundColor Yellow
}
Write-Host "======================================" -ForegroundColor Green
Write-Host ""
Read-Host "Press Enter to close (server and watchdog keep running)"
`;
}

// ── Reconnect scripts (skip install — just restart both processes) ─────────────

export function makeBashReconnectScript(
  modelName : string,
  ggufFile  : string,
  port      : number,
  token     : string,
  crsUrl    : string,
): string {
  return `#!/usr/bin/env bash
# YODA Reconnect
# Model: ${modelName}  |  Port: ${port}  |  Token: ${token}
set -euo pipefail

SESSION_TOKEN="${token}"
CRS_URL="${crsUrl}"
GGUF_FILE="${ggufFile}"
SERVER_PORT="${port}"
PLENUMNET_DIR="\$HOME/PlenumNET"
MODELS_DIR="\$HOME/yoda-models"
MODEL_PATH="\$MODELS_DIR/\$GGUF_FILE"
DAEMON="\$PLENUMNET_DIR/target/release/inter-cube-daemon"
LOG_DIR="\$HOME/yoda-models/logs"
IDENTITY_DIR="\$HOME/.plenumnet/identity"

echo "=== YODA Reconnect ==="
echo "Model : ${modelName}"
echo "Port  : \$SERVER_PORT"
echo ""

# ── Preflight checks ──────────────────────────────────────────────────
[[ -x "\$DAEMON" ]] || { echo "  ✗ PlenumNET daemon not found. Run the Install script first."; exit 1; }
[[ -s "\$MODEL_PATH" ]] || { echo "  ✗ Model file not found or empty. Run the Install script first."; exit 1; }

# ── Find llama-server ─────────────────────────────────────────────────
${BASH_FIND_LLAMA}
LLAMA_SERVER=\$(_find_llama_server || true)
if [[ -z "\$LLAMA_SERVER" ]]; then
  echo "  ✗ llama-server not found. Run the Install script first."
  exit 1
fi
echo "  ✓ llama-server: \$LLAMA_SERVER"

# ── Detect IP ─────────────────────────────────────────────────────────
OS=\$(uname -s)
if [[ "\$OS" == "Darwin" ]]; then
  LOCAL_IP=\$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "")
else
  LOCAL_IP=\$(ip route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if(\$i=="src") print \$(i+1)}' | head -1)
  [[ -z "\$LOCAL_IP" ]] && LOCAL_IP=\$(hostname -I 2>/dev/null | awk '{print \$1}')
fi
LOCAL_IP=\${LOCAL_IP:-"0.0.0.0"}
CUBE_ENDPOINT="\${LOCAL_IP}:51820"

# ── Load identity passphrase ──────────────────────────────────────────
PASSPHRASE_FILE="\$IDENTITY_DIR/.passphrase"
if [[ -f "\$PASSPHRASE_FILE" ]]; then
  export CUBE_IDENTITY_PASSPHRASE=\$(cat "\$PASSPHRASE_FILE")
  echo "  ✓ Identity passphrase loaded"
else
  echo "  ⚠ No passphrase file found at \$PASSPHRASE_FILE — daemon will use hostname-derived fallback."
  echo "    If the daemon fails to start, run the Install script again to regenerate identity."
fi

# ── Restart llama-server ──────────────────────────────────────────────
mkdir -p "\$LOG_DIR"
pkill -f "llama-server.*\$SERVER_PORT" 2>/dev/null || true
sleep 1
nohup "\$LLAMA_SERVER" \\
  --model "\$MODEL_PATH" \\
  --port "\$SERVER_PORT" \\
  --host 0.0.0.0 \\
  -c 4096 \\
  --parallel 4 \\
  -ngl 99 \\
  --log-disable \\
  >> "\$LOG_DIR/llama-server-\${SERVER_PORT}.log" 2>&1 &
echo "  ✓ llama-server started (PID \$!)"
sleep 2

# ── Restart PlenumNET daemon ──────────────────────────────────────────
# The daemon self-registers with the CRS on startup using CUBE_CRS_URL +
# CUBE_SESSION_TOKEN, so no explicit registration call is needed here.
pkill -f "inter-cube-daemon" 2>/dev/null || true
sleep 1
export CUBE_MODE=cube
export CUBE_API_PORT=$((SERVER_PORT - 1))
export CUBE_CRS_URL="\$CRS_URL"
export CUBE_ENDPOINT="\$CUBE_ENDPOINT"
export CUBE_SESSION_TOKEN="\$SESSION_TOKEN"
export CUBE_ROLE=inference
nohup "\$DAEMON" >> "\$LOG_DIR/intercube.log" 2>&1 &
echo "  ✓ Daemon started (PID \$!)"

echo ""
echo "  Both processes running in background. YODA will update within 10s."
echo "  Logs : \$LOG_DIR/"
`;
}

export function makePsReconnectScript(
  modelName : string,
  ggufFile  : string,
  port      : number,
  token     : string,
  crsUrl    : string,
): string {
  return `# YODA Reconnect (Windows)
# Model: ${modelName}  |  Port: ${port}  |  Token: ${token}
$ErrorActionPreference = "Stop"
trap {
  Write-Host ""
  Write-Host "=== RECONNECT ERROR ===" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host ""
  Read-Host "Press Enter to close"
  break
}

$SESSION_TOKEN = "${token}"
$CRS_URL       = "${crsUrl}"
$GGUF_FILE     = "${ggufFile}"
$SERVER_PORT   = ${port}
$MODELS_DIR    = Join-Path $env:USERPROFILE "yoda-models"
$MODEL_PATH    = Join-Path $MODELS_DIR $GGUF_FILE
$LOG_DIR       = Join-Path $MODELS_DIR "logs"
$LLAMA_DIR     = Join-Path $env:USERPROFILE "llama.cpp"
$IDENTITY_DIR  = Join-Path (Join-Path $env:USERPROFILE ".plenumnet") "identity"

# Locate PlenumNET daemon (binary may be inter-cube.exe or inter-cube-daemon.exe)
$PLENUMNET_DIR = Join-Path $env:USERPROFILE "PlenumNET"
$relDir = Join-Path (Join-Path $PLENUMNET_DIR "target") "release"
if (-not (Test-Path $relDir)) {
  $altDir = Join-Path (Join-Path (Join-Path "C:" "PlenumNET") "target") "release"
  if (Test-Path $altDir) { $PLENUMNET_DIR = Join-Path "C:" "PlenumNET"; $relDir = $altDir }
}
$daemonBin = Get-ChildItem -Path $relDir -Filter "inter-cube*.exe" -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -notlike "*.d" } | Select-Object -First 1
$DAEMON_PATH = if ($daemonBin) { $daemonBin.FullName } else { "" }

Write-Host "=== YODA Reconnect ===" -ForegroundColor Cyan
Write-Host "Model : ${modelName}"
Write-Host "Port  : $SERVER_PORT"
Write-Host ""

# ── Preflight checks ──────────────────────────────────────────────────
if (-not $DAEMON_PATH -or -not (Test-Path $DAEMON_PATH)) {
  throw "PlenumNET daemon not found in $relDir -- run the Install script first (Settings -> AI Engines -> Install)."
}
if (-not (Test-Path $MODEL_PATH) -or (Get-Item $MODEL_PATH).Length -eq 0) {
  throw "Model not found or empty at $MODEL_PATH -- run the Install script first."
}
function Find-LlamaServer {
  $hit = Get-ChildItem -Path $LLAMA_DIR -Recurse -Filter "llama-server.exe" -EA SilentlyContinue | Select-Object -First 1
  if ($hit) { return $hit.FullName }
  $dl = Join-Path $env:USERPROFILE "Downloads"
  $hit = Get-ChildItem -Path $dl -Recurse -Filter "llama-server.exe" -EA SilentlyContinue | Select-Object -First 1
  if ($hit) { return $hit.FullName }
  $cmd = Get-Command "llama-server" -EA SilentlyContinue
  if ($cmd) { return $cmd.Source }
  return $null
}
$LLAMA_SERVER = Find-LlamaServer
if (-not $LLAMA_SERVER) {
  throw "llama-server.exe not found in $LLAMA_DIR, Downloads, or PATH -- run the Install script first."
}
Write-Host "  OK llama-server: $LLAMA_SERVER"

# ── Detect IP ─────────────────────────────────────────────────────────
$ip = (Get-NetIPAddress -AddressFamily IPv4 |
  Where-Object { $_.IPAddress -notmatch '^127\\.' -and $_.IPAddress -notmatch '^169\\.254' -and $_.PrefixOrigin -ne 'WellKnown' } |
  Sort-Object @{ Expression = { switch -Wildcard ($_.InterfaceAlias) { 'Wi-Fi*' { 0 } 'Ethernet*' { 1 } default { 2 } } } } |
  Select-Object -First 1).IPAddress
if (-not $ip) { $ip = "0.0.0.0" }
$CUBE_ENDPOINT = "$ip\`:51820"
Write-Host "  Local endpoint : $CUBE_ENDPOINT"

# -- Load identity passphrase ---------------------------------------------
$PASSPHRASE_FILE = Join-Path $IDENTITY_DIR ".passphrase"
if (Test-Path $PASSPHRASE_FILE) {
  $env:CUBE_IDENTITY_PASSPHRASE = (Get-Content $PASSPHRASE_FILE -Raw).Trim()
  Write-Host "  OK Identity passphrase loaded"
} else {
  Write-Host "  WARN No passphrase file at $PASSPHRASE_FILE -- daemon will use hostname-derived fallback." -ForegroundColor Yellow
  Write-Host "       If daemon fails, run the Install script to regenerate identity." -ForegroundColor Yellow
}

# -- Restart llama-server -------------------------------------------------
New-Item -ItemType Directory -Force -Path $LOG_DIR | Out-Null
$cpuArch = $env:PROCESSOR_ARCHITECTURE
$nglArgs = if ($cpuArch -eq "ARM64") { "" } else { "-ngl 99" }
Write-Host "  -> Architecture: $cpuArch  GPU offload: $(if ($nglArgs) { 'yes' } else { 'no (CPU only)' })"
# Stop the existing watchdog BEFORE killing llama-server so it cannot
# re-spawn a new process (with old settings) in the gap.
Stop-ScheduledTask -TaskName "YODA-Watchdog-$SERVER_PORT" -EA SilentlyContinue
Start-Sleep -Milliseconds 300
# Kill ALL llama-server processes on this port (port-specific kill catches the primary;
# Get-Process catches any zombie/unlisted instances from a previous watchdog cycle).
$portOwner = (Get-NetTCPConnection -LocalPort $SERVER_PORT -EA SilentlyContinue | Select-Object -First 1 -ExpandProperty OwningProcess)
if ($portOwner) { Stop-Process -Id $portOwner -Force -EA SilentlyContinue }
Get-Process -Name "llama-server" -EA SilentlyContinue |
  Where-Object { -not (Get-NetTCPConnection -LocalPort ($SERVER_PORT - 1) -State Listen -EA SilentlyContinue | Where-Object OwningProcess -eq $_.Id) } |
  Stop-Process -Force -EA SilentlyContinue
Start-Sleep -Milliseconds 800
$LLAMA_LOG = Join-Path $LOG_DIR "llama-server-$SERVER_PORT.log"
try { "" | Out-File -FilePath $LLAMA_LOG -Encoding UTF8 -EA Stop } catch { }  # clear old log (ignore if locked)
# Use llama-server's built-in --log-file so no I/O redirect needed (avoids WindowStyle conflict)
# ARM64: use smaller context to save KV-cache RAM; GPU layer count is always 0 on ARM64
$ctxSize      = if ($cpuArch -eq "ARM64") { "2048" } else { "4096" }
$parallelCount= if ($cpuArch -eq "ARM64") { "1"    } else { "2" }
$serverProc = Start-Process -FilePath $LLAMA_SERVER \`
  -ArgumentList "--model \`"$MODEL_PATH\`" --port $SERVER_PORT --host 0.0.0.0 -c $ctxSize --parallel $parallelCount $nglArgs --log-file \`"$LLAMA_LOG\`"" \`
  -WindowStyle Hidden -PassThru
Write-Host "  OK llama-server started (PID $($serverProc.Id))  context=$ctxSize"
Write-Host "     Log: $LLAMA_LOG"
# Wait 8 seconds and verify it is still alive
Start-Sleep -Seconds 8
if ($serverProc.HasExited) {
  Write-Host ""
  Write-Host "=== LLAMA-SERVER CRASHED ===" -ForegroundColor Red
  Write-Host "  Exit code: $($serverProc.ExitCode)" -ForegroundColor Red
  if (Test-Path $LLAMA_LOG) {
    Write-Host "  Last log lines:" -ForegroundColor Yellow
    Get-Content $LLAMA_LOG -Tail 20 | ForEach-Object { Write-Host "    $_" -ForegroundColor Yellow }
  }
  Write-Host ""
  if ($cpuArch -eq "ARM64") {
    Write-Host "  ARM64 diagnosis:" -ForegroundColor Cyan
    Write-Host "    Recent llama.cpp loads Q4_K_M models twice on ARM64:" -ForegroundColor White
    Write-Host "      - ~4 GB  memory-mapped model weights" -ForegroundColor White
    Write-Host "      - ~4 GB  NEON-optimised repack buffer" -ForegroundColor White
    Write-Host "    Total needed: ~8 GB free RAM simultaneously." -ForegroundColor White
    Write-Host ""
    Write-Host "  To fix (try in order):" -ForegroundColor Yellow
    Write-Host "    1. Close Chrome/Edge tabs, Teams, other heavy apps then try again" -ForegroundColor White
    Write-Host "    2. Run only ONE engine at a time (A or B, not both)" -ForegroundColor White
    Write-Host "    3. If your machine has 8 GB RAM total, use Engine C with a smaller model" -ForegroundColor White
  } else {
    Write-Host "  Common causes:" -ForegroundColor White
    Write-Host "    - Not enough free RAM (needs ~5 GB free)" -ForegroundColor White
    Write-Host "    - Wrong CPU arch binary (re-run the Install script)" -ForegroundColor White
  }
  Read-Host "Press Enter to exit"
  exit 1
}
Write-Host "  OK llama-server still running after 8s"

# -- Restart PlenumNET daemon ---------------------------------------------
# The daemon self-registers with the CRS on startup using CUBE_CRS_URL +
# CUBE_SESSION_TOKEN, so no explicit registration call is needed here.
$daemonPort = $SERVER_PORT - 1
$portOwner = (Get-NetTCPConnection -LocalPort $daemonPort -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty OwningProcess)
if ($portOwner) { Stop-Process -Id $portOwner -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 800
$env:CUBE_MODE          = "cube"
$env:CUBE_API_PORT      = $daemonPort
$env:CUBE_CRS_URL       = $CRS_URL
$env:CUBE_ENDPOINT      = $CUBE_ENDPOINT
$env:CUBE_SESSION_TOKEN = $SESSION_TOKEN
$env:CUBE_ROLE          = "inference"
$daemonProc = Start-Process -FilePath $DAEMON_PATH -WindowStyle Hidden -PassThru
Write-Host "  OK Daemon started (PID $($daemonProc.Id))"

# -- Register full dual watchdog (llama-server + daemon) ----------------------
Write-Host ""
Write-Host "Registering watchdog (auto-restart on crash)..."
$watchdogScript = Join-Path $MODELS_DIR "watchdog-$SERVER_PORT.ps1"
$watchdogContent = @"
\$ErrorActionPreference = 'SilentlyContinue'
\$LLAMA_EXE   = '$($LLAMA_SERVER  -replace "'","''")'
\$MODEL_PATH  = '$($MODEL_PATH    -replace "'","''")'
\$DAEMON_EXE  = '$($DAEMON_PATH   -replace "'","''")'
\$SERVER_PORT = $SERVER_PORT
\$DAEMON_PORT = $daemonPort
\$NGL         = '$nglArgs'
\$CUBE_ENDPOINT_VAL     = '$CUBE_ENDPOINT'
\$CUBE_CRS_URL_VAL      = '$CRS_URL'
\$CUBE_SESSION_TOKEN_VAL= '$SESSION_TOKEN'
\$PASSPHRASE  = if (Test-Path '$PASSPHRASE_FILE') { (Get-Content '$PASSPHRASE_FILE' -Raw).Trim() } else { '' }

while (\$true) {
  Start-Sleep -Seconds 30
  # Watchdog: llama-server
  if (-not (Get-NetTCPConnection -LocalPort \$SERVER_PORT -State Listen -EA SilentlyContinue)) {
    Start-Process -FilePath \$LLAMA_EXE \`
      -ArgumentList "--model \`"\$MODEL_PATH\`" --port \$SERVER_PORT --host 0.0.0.0 -c $ctxSize --parallel $parallelCount \$NGL --log-disable" \`
      -WindowStyle Hidden
    Start-Sleep -Seconds 3
  }
  # Watchdog: PlenumNET daemon
  if (-not (Get-NetTCPConnection -LocalPort \$DAEMON_PORT -State Listen -EA SilentlyContinue)) {
    \$env:CUBE_MODE          = 'cube'
    \$env:CUBE_API_PORT      = \$DAEMON_PORT
    \$env:CUBE_CRS_URL       = \$CUBE_CRS_URL_VAL
    \$env:CUBE_ENDPOINT      = \$CUBE_ENDPOINT_VAL
    \$env:CUBE_SESSION_TOKEN = \$CUBE_SESSION_TOKEN_VAL
    \$env:CUBE_ROLE          = 'inference'
    \$env:CUBE_IDENTITY_PASSPHRASE = \$PASSPHRASE
    Start-Process -FilePath \$DAEMON_EXE -WindowStyle Hidden
    Start-Sleep -Seconds 3
  }
}
"@
Set-Content -Path $watchdogScript -Value $watchdogContent -Encoding UTF8
$taskName  = "YODA-Watchdog-$SERVER_PORT"
$action    = New-ScheduledTaskAction -Execute "powershell.exe" \`
               -Argument "-NonInteractive -WindowStyle Hidden -File \`"$watchdogScript\`""
$trigger1  = New-ScheduledTaskTrigger -AtLogOn
$trigger2  = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) \`
               -RepetitionInterval (New-TimeSpan -Minutes 5) \`
               -RepetitionDuration ([TimeSpan]::MaxValue)
$settings  = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit 0
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger @($trigger1,$trigger2) \`
  -Settings $settings -RunLevel Limited -Force | Out-Null
Start-ScheduledTask -TaskName $taskName -EA SilentlyContinue
Write-Host "  OK Watchdog registered as '$taskName' -- restarts every 5 min if crashed" -ForegroundColor Green

Write-Host ""
Write-Host "  Both processes running + watchdog active. YODA will update within 10s." -ForegroundColor Green
`;
}
